class DataState {
  dictDataState = {};

  setDictDataState = (key: string, value: any) => {
    if (key) {
      this.dictDataState[key] = value;
    }
  };

  getDictDataState = (key: string) => {
    if (key && this.dictDataState[key]) {
      return this.dictDataState[key];
    }
  };
}

export default new DataState();
