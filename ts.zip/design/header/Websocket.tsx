import React, { useEffect, useRef, useState } from 'react';
import { Badge } from 'antd';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import cerdoWS from '../__utils/InitWebSocket';

const WebSocket = () => {
  const [wsStatus, setWsStatus] = useState<'close' | 'open'>('close');
  const wsStatusToken = useRef(null);

  /** 设置 websocket 连接状态 */
  const setWebsocketStatus = (type: string, data) => {
    setWsStatus(data.status);
  };

  /** 重连 */
  const handleReconnect = () => {
    if (wsStatus === 'close') {
      cerdoWS.reconnect();
    }
  };

  useEffect(() => {
    wsStatusToken.current = eventCenter.subscribe('websocket-status', setWebsocketStatus);

    return () => {
      if (wsStatusToken.current) {
        eventCenter.unsubscribe(wsStatusToken.current);
      }
    };
  }, []);

  if (!process.env.WEBSOCKET) return null;

  return (
    <div
      onClick={handleReconnect}
      title={wsStatus === 'open' ? '' : '点击重连'}
      style={{ display: 'flex', justifyContent: 'center' }}
    >
      <Badge status={wsStatus === 'open' ? 'success' : 'error'} text="通讯状态" />
    </div>
  );
};

export default WebSocket;
