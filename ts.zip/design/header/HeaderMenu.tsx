import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Tabs, Menu, Tooltip } from 'antd';
import { withRouter } from 'react-router-dom';
import type { RouteComponentProps } from 'react-router-dom';
import { isArray } from 'lodash';
import { dropByCacheKey } from 'react-router-cache-route';
import { treeToArray } from '@cerdo/cerdo-utils/es/array';
import DraggableTabs from '@cerdo/cerdo-design/es/tabs/DraggableTabs';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import proxyWindow from '@cerdo/cerdo-utils/es/proxyWindow';
import { pageMap } from '../__utils';
import ThemeProvider from '../context/ThemeContext';

const { TabPane } = Tabs;

interface tabsProps {
  key?: string;
  title?: string;
  pathname?: string;
  search?: string;
  path?: string;
}
export interface IHeaderMenuProps extends RouteComponentProps {
  menus?: any[];
  tabsData?: tabsProps[];
  flattenMenus?: any[];
}

export interface IHeaderMenuState {
  tabActiveKey: string;
  tabsData: tabsProps[];
  rightMenuConfig: { key: string; name: string }[];
}

class HeaderMenu extends Component<IHeaderMenuProps, IHeaderMenuState> {
  private hashChangeToken: any;
  private closeTabToken: any;
  private timer: any;
  private params: { menusArr: any[] };
  private container: any;
  private toolTip: React.ReactElement;

  constructor(props) {
    super(props);
    this.state = {
      tabActiveKey: '',
      tabsData: [],
      rightMenuConfig: [
        {
          key: 'reload',
          name: '重新加载',
        },
        {
          key: 'closeOther',
          name: '关闭其他',
        },
        {
          key: 'closeAll',
          name: '关闭所有',
        },
      ],
    };

    this.params = { menusArr: [] };
    this.toolTip = null;
    this.container = null;
    this.hashChangeToken = null;
  }

  componentDidMount() {
    const { menus } = this.props;
    this.hashChangeToken = eventCenter.subscribe('hashChange', (type, data) => {
      this.generateTabs(this.props.history.location, menus);
    });
    this.closeTabToken = eventCenter.subscribe('closeTab', (type, data) => {
      this.handleCloseTab(data);
    });
    this.generateTabs(this.props.history.location, menus);
  }

  shouldComponentUpdate(nextProps) {
    const { menus } = this.props;
    if (menus.length !== nextProps.menus.length) {
      this.generateTabs(nextProps.history.location, nextProps.menus);
      return true;
    }
    return true;
  }

  componentWillUnmount() {
    if (this.timer) clearTimeout(this.timer);
    if (this.hashChangeToken) eventCenter.unsubscribe(this.hashChangeToken);
    if (this.closeTabToken) eventCenter.unsubscribe(this.closeTabToken);
  }

  getTitle = (router) => {
    return this.params.menusArr.find((a) => a.perLink === router.pathname);
  };

  /**
   * 批量删除所有 tabs 同时清除cache缓存
   * @param {*} tabData  tab标签页数据源
   */
  removeAllTabs = (tabData) => {
    const { flattenMenus } = this.props;
    tabData.forEach((item) => {
      let currentMenuItem = flattenMenus.find((menuItem) => menuItem.perLink === item.path);
      if (currentMenuItem) {
        dropByCacheKey(`${currentMenuItem.perLink}${currentMenuItem.suffixKey || ''}`);
      }
    });
  };

  /**
   * 批量删除多个 tabs 同时清除cache缓存
   * @param {*} tabData  tab标签页数据源
   * @param {*} currentData 当前选中标签页
   */
  removeTabs = (tabData, currentData) => {
    const { flattenMenus } = this.props;
    const currentPath = currentData.key;
    tabData.forEach((item) => {
      let currentMenuItem = flattenMenus.find((menuItem) => menuItem.perLink === item.path);
      if (item.perLink !== currentPath && currentMenuItem) {
        dropByCacheKey(`${currentMenuItem.perLink}${currentMenuItem.suffixKey || ''}`);
      }
    });
  };

  /**
   * 删除单个 tabs 同时清除cache缓存
   * @param {*} currentData 当前选中标签页
   */
  removeSingleTab = (currentPath) => {
    const { flattenMenus } = this.props;
    let currentMenuItem = flattenMenus.find((menuItem) => menuItem.perLink === currentPath);
    if (currentMenuItem) {
      dropByCacheKey(`${currentMenuItem.perLink}${currentMenuItem.suffixKey || ''}`);
    }
  };

  generateTabs = async (router, menus) => {
    const { tabsData } = this.state;
    if (this.params.menusArr.length < 1 && isArray(menus)) {
      this.params.menusArr = treeToArray([...menus, ...pageMap]);
    }
    const menuItem = this.getTitle(router);
    const title = menuItem?.perName || '';
    let item = tabsData.find((a) => a.key === router.pathname);

    if (!title) return;

    if (!item) {
      item = {
        key: router.pathname,
        title: title || '首页',
        path: router.pathname + (router.search || ''),
      };
      tabsData.push(item);
    } else {
      item.path = router.pathname + (router.search || '');
      item.title = title;
    }
    document.title = item.title;
    this.setState(
      {
        tabActiveKey: item.key,
        tabsData,
      },
      () => {
        eventCenter.publish('tabsChange', {
          key: item.key,
        });
      },
    );
  };

  handleTabsChange = (activeKey) => {
    const { history } = this.props;
    const { tabActiveKey, tabsData } = this.state;
    if (activeKey !== tabActiveKey) {
      this.setState({ tabActiveKey: activeKey }, () => {
        eventCenter.publish('tabsChange', {
          key: activeKey,
        });
        const item = tabsData.find((a) => a.key === activeKey);
        if (item) {
          document.title = item.title;
          history.push(item.path);
        } else {
          history.push(activeKey);
        }
      });
    }
  };

  handleTabsEdit = (targetKey) => {
    const { tabsData, tabActiveKey } = this.state;
    const index = tabsData.findIndex((a) => a.key === targetKey);
    let tabItem = tabsData[index > 0 ? index - 1 : index + 1];
    const path = tabItem?.path;
    const title = tabItem?.title;
    const newTabsData = tabsData.filter((a) => a.key !== targetKey);

    this.timer = setTimeout(() => {
      // tips: 页签增加了 刷新功能，会导致当前taggetKey发生变化，需要通过当前targetkey找到对应 menuItem
      // dropByCacheKey(targetKey);
      this.removeSingleTab(targetKey);
      clearTimeout(this.timer);
    }, 500);

    this.setState(
      {
        tabsData: newTabsData,
      },
      () => {
        eventCenter.publish('tabClose', { key: targetKey });

        if (newTabsData && newTabsData.length === 0) {
          const { history } = this.props;
          if (process.env.PROJECT_NAME) {
            document.title = process.env.PROJECT_NAME;
          }
          // setSessionItem('curPage', null);
          history.push(proxyWindow['env'].DEFAULT_PAGE || '/app');
        } else if (targetKey === tabActiveKey) {
          const { history } = this.props;
          document.title = title;
          history.push(path);
        }
      },
    );
  };

  /**
   * 右键按钮 关闭所有tab页
   * @param {} data 当前右键选中 tab 数据
   */
  handleCloseAllTabs = (data) => {
    const { history } = this.props;
    const { tabsData } = this.state;
    // 清空 tabsData 数据源 同时跳转到 入口页面
    this.setState(
      {
        tabsData: [],
      },
      () => {
        this.removeAllTabs(tabsData);
        history.push(proxyWindow['env'].DEFAULT_PAGE || '/app');
        eventCenter.publish('tabsChange', {
          key: proxyWindow['env'].DEFAULT_PAGE || '/app',
        });
      },
    );
  };

  /**
   * 右键按钮 关闭其他
   * @param {} data 当前右键选中 tab 数据
   */
  handleCloseOther = (data) => {
    const { history } = this.props;
    const { tabsData } = this.state;
    const currentKey = data.key;
    const currentPath = data.path;
    let reTabsData = tabsData.filter((item) => {
      return item.key === currentKey;
    });
    this.setState(
      {
        tabsData: reTabsData,
      },
      () => {
        this.removeTabs(tabsData, data);
        history.push(currentPath);
        eventCenter.publish('tabsChange', {
          key: currentPath,
        });
      },
    );
  };

  /**
   * 关闭指定tab，并打开新的tab
   * @param {object} path 需要关闭的tabs的url
   * @param {object} currentPath 需要打开的tabs的url
   */
  handleCloseTab = ({ path, currentPath }) => {
    const { tabsData } = this.state;
    let reTabsData = tabsData.filter((item) => {
      return item.key !== path;
    });
    this.setState(
      {
        tabsData: reTabsData,
      },
      () => {
        this.removeSingleTab(path);
        const current = currentPath
          ? currentPath
          : reTabsData?.length
          ? reTabsData[reTabsData.length - 1]?.key
          : '/app';
        this.handleTabsChange(current);
      },
    );
  };

  /**
   * 右键按钮 menu 菜单点击事件
   * @param {} node 当前右键选中 tab 节点数据
   */
  handleMenuItemClick = (node) => {
    const data = JSON.parse(node.item.props['data-tab-id']);
    const { key } = node;
    switch (key) {
      case 'reload':
        // 重新加载
        eventCenter.publish('tabReload', data);
        break;
      case 'closeOther':
        // 关闭其它
        this.handleCloseOther(data);
        eventCenter.publish('tabCloseOther', data);
        break;
      case 'closeAll':
        // 关闭所有
        this.handleCloseAllTabs(data);
        eventCenter.publish('tabCloseAll', data);
        break;
      default:
      // 无操作
    }
    setTimeout(() => {
      this.container && ReactDOM.unmountComponentAtNode(this.container);
      this.toolTip = null;
    }, 0);
  };

  // 创建右键菜单容器节点
  createContainer = () => {
    if (!this.container) {
      this.container = document.createElement('div');
      document.body.appendChild(this.container);
    }
    return this.container;
  };

  /**
   * 鼠标右键选中 tabs 页签时展示渲染内容
   * @param {} event
   * @param {} tab 当前选中tab页签
   */
  handleRightMenuRender = (event, tab) => {
    const { rightMenuConfig } = this.state;
    if (this.toolTip) {
      this.container && ReactDOM.unmountComponentAtNode(this.container);
      this.toolTip = null;
    }
    let contextMenu = (
      <ThemeProvider>
        <Menu
          onClick={this.handleMenuItemClick}
        >
          {rightMenuConfig.map((item) => {
            return (
              <Menu.Item key={item.key} data-tab-id={JSON.stringify(tab)}>
                {item.name}
              </Menu.Item>
            );
          })}
        </Menu>
      </ThemeProvider>
    );
    this.toolTip = (
      <Tooltip
        trigger="click"
        placement="bottomLeft"
        prefixCls="cerdo-tab-contextmenu"
        defaultOpen
        overlay={contextMenu}
      >
        <span />
      </Tooltip>
    );

    let fragContainer = this.createContainer();
    Object.assign(fragContainer?.style, {
      position: 'absolute',
      left: `${event.pageX}px`,
      top: `${event.pageY}px`,
      'z-index': 10,
    });
    ReactDOM.render(this.toolTip, fragContainer);
  };

  // 鼠标右键点击事件
  handleRightMenuClick = (event, tab) => {
    event.preventDefault();
    event.stopPropagation();
    this.handleRightMenuRender(event, tab);
  };

  // 对tab页签渲染作自定义操作，支持右键选中功能
  tabRender = (tabsData) => {
    if (isArray(tabsData)) {
      return tabsData.map((item) => {
        let title = (
          <span
            onContextMenu={(event) => {
              this.handleRightMenuClick(event, item);
            }}
          >
            {item.title}
          </span>
        );
        return <TabPane tab={title} key={item.key} />;
      });
    }
    return null;
  };

  render() {
    const { tabActiveKey, tabsData } = this.state;

    return tabsData.length ? (
      <div key="header-menu" id="header-menu" style={{ position: 'relative' }}>
        <DraggableTabs
          key="tabs"
          hideAdd
          onChange={this.handleTabsChange}
          onEdit={this.handleTabsEdit}
          activeKey={tabActiveKey}
          type="editable-card"
        >
          {this.tabRender(tabsData)}
        </DraggableTabs>
      </div>
    ) : (
      // eslint-disable-next-line react/jsx-no-useless-fragment
      <></>
    );
  }
}

export default withRouter(HeaderMenu);
