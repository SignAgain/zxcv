import React, { useState, useMemo } from 'react';
import { Menu, Spin } from 'antd';
import {
  UserOutlined,
  SkinOutlined,
  ClearOutlined,
  LoadingOutlined,
  LoginOutlined,
} from '@ant-design/icons';
import classnames from 'classnames';
import { isFunction } from 'lodash';
import { getUserInfo, setToken, setUserInfo } from '@cerdo/cerdo-utils/es/storage';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import { goAuthPath } from '@cerdo/cerdo-utils/es/auth';
import layouts from 'layouts';
import { type LayoutType } from '../layout/LayoutComponent';

const { SubMenu } = Menu;

const { top, bottom } = layouts.header.usermenuitem.reduce(
  (acc, curr) => {
    if (curr.position === 'top') {
      acc.top.push(curr);
    } else {
      acc.bottom.push(curr);
    }
    return acc;
  },
  { top: [], bottom: [] },
);

interface IProps {
  layout: LayoutType;
  handleThemeClick: () => void;
  loginOut?: () => void;
}

const index: React.FC<IProps> = (props) => {
  const { layout, handleThemeClick, loginOut } = props;
  const [logoutStatus, setLogoutStatus] = useState(false);

  const userInfo = useMemo(() => getUserInfo(), [logoutStatus]);

  const logout = () => {
    if (isFunction(loginOut)) {
      loginOut();
      return;
    }

    setToken(null);
    setUserInfo(null);
    goAuthPath();
    setLogoutStatus((prev) => !prev);
  };

  return (
    <SubMenu
      style={{ padding: 0, background: 'none' }}
      key="headerSubMenu"
      title={
        userInfo ? (
          <div className="user-logo">
            {userInfo.userAvatar ? (
              <img
                src={userInfo.userAvatar}
                className={classnames({ avatar: layout === 'avatar' })}
              />
            ) : (
              <UserOutlined style={{ fontSize: 20 }} />
            )}
            {layout !== 'avatar' && <strong>{userInfo?.name}</strong>}
          </div>
        ) : (
          <Spin indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />} />
        )
      }
    >
      {top.map((item, index) => {
        let comp = null;
        if (typeof item.component === 'string') {
          comp = <Menu.Item key={index}>{item.component}</Menu.Item>;
        } else {
          comp = (
            <Menu.Item key={index}>
              <item.component />
            </Menu.Item>
          );
        }
        return comp;
      })}
      <Menu.Item key="theme" icon={<SkinOutlined />} onClick={() => handleThemeClick()}>
        主题切换
      </Menu.Item>
      <Menu.Item
        key="refresh.cache"
        icon={<ClearOutlined />}
        onClick={() => eventCenter.publish('refresh.cache')}
      >
        刷新缓存
      </Menu.Item>
      <Menu.Item key="loginOut" icon={<LoginOutlined />} onClick={logout}>
        退出登录
      </Menu.Item>
      {bottom.map((item, index) => {
        let comp = null;
        if (typeof item.component === 'string') {
          comp = <Menu.Item key={index}>{item.component}</Menu.Item>;
        } else {
          comp = (
            <Menu.Item key={index}>
              <item.component />
            </Menu.Item>
          );
        }
        return comp;
      })}
    </SubMenu>
  );
};

export default React.memo(index);
