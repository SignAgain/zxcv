import React, { useState, useEffect } from 'react';
import { Select, Modal, Input, message, Popover } from 'antd';
import { SwapOutlined } from '@ant-design/icons';
import { findProxyUserList } from '@cerdo/cerdo-utils/es/api';
import { changeCurrentUser } from '@cerdo/cerdo-utils/es/auth';
import { getUserInfo, getSourceUserInfo } from '@cerdo/cerdo-utils/es/storage';

const sourceUser = getSourceUserInfo() || getUserInfo();
const ChangeUser = () => {
  const [proxyUserList, setProxyUserList] = useState([]);
  const [originUserList, setOriginUserList] = useState([]);
  const [proxyUser, setProxyUser] = useState<Record<string, any>>({});
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [changeReason, setChangeReason] = useState('');
  const [messageApi, contextHolder] = message.useMessage();

  // 代理用户自定义搜索事件
  const handleSearch = (value) => {
    let proxyUserList = [];
    if (value) {
      // 过滤 userName / account 是否满足搜索条件
      proxyUserList = originUserList.filter((item) => {
        return item.userName?.indexOf(value) !== -1 || item.account?.indexOf(value) !== -1;
      });
      setProxyUserList(proxyUserList);
      return;
    }

    setProxyUserList(originUserList);
  };

  // 查询可切换的用户列表
  const fetchProxyUserList = () => {
    findProxyUserList().then((res) => {
      if (res?.data) {
        setProxyUserList(res.data);
        setOriginUserList(res.data);
      }
    });
  };

  // 切换登录
  const handleChange = (value) => {
    const proxyUser = proxyUserList.find((i) => i.id === value);
    setProxyUser(proxyUser);
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setChangeReason('');
    setIsModalVisible(false);
  };

  const handleOk = () => {
    if (!changeReason) {
      messageApi.warning('请先输入切换用户原因');
      return;
    }
    handleCancel();
    changeCurrentUser({ value: proxyUser.userId, reason: changeReason }, () => {
      // 用户切换成功之后，需要默认跳转到首页，重新刷新页面 执行 sso 登录
      (window as any).appHistory.replace(process.env.DEFAULT_PAGE || '/app');
      window.location.reload();
    });
  };

  useEffect(() => {
    fetchProxyUserList();
  }, []);

  return (
    <>
      {contextHolder}
      <Popover
        placement="right"
        trigger="click"
        overlayClassName="changeUserPopover"
        title={null}
        content={
          <Select
            open
            showSearch
            onSearch={handleSearch}
            optionFilterProp="children"
            filterOption={false}
            placeholder="切换用户"
            style={{ width: 200 }}
            onSelect={handleChange}
            getPopupContainer={() =>
              document.querySelector('.changeUserPopover .ant-popover-inner-content')
            }
          >
            {Array.isArray(proxyUserList) &&
              proxyUserList.map((item) => {
                return (
                  <Select.Option account={item.account} key={item.id} value={item.id}>
                    {item.userName}
                  </Select.Option>
                );
              })}
          </Select>
        }
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            top: 32,
            right: 12,
            zIndex: 999,
            width: 20,
            height: 20,
            cursor: 'pointer',
            borderRadius: '50%',
            backgroundColor: 'var(--popover-bg)',
          }}
        >
          <SwapOutlined style={{ color: 'var(--btn-link-color)' }} />
        </div>
      </Popover>
      <Modal
        title={`当前为【${sourceUser?.userName}】模拟【${proxyUser?.userName}】登录，所有操作已记录。`}
        open={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <Input.TextArea
          placeholder="切换用户原因"
          value={changeReason}
          rows={4}
          autoFocus
          onChange={(e) => {
            setChangeReason(e.target.value);
          }}
        />
      </Modal>
    </>
  );
};

export default ChangeUser;
