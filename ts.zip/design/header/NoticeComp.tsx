import React, { useState, useMemo } from 'react';
import { getAppNoticeInfo } from '@cerdo/cerdo-utils/es/api';
import { getAppId } from '@cerdo/cerdo-utils/es/storage';
import { checkResponse } from '@cerdo/cerdo-utils/es/fn';
import { Alert } from 'antd';
import { NotificationOutlined } from '@ant-design/icons';
import Marquee from 'react-fast-marquee';
import moment from 'moment';

enum NoticeType {
  Success = 'success',
  Info = 'info',
  Warning = 'warning',
  Error = 'error',
}

// 通知公告
const NoticeComp: React.FC = (_) => {
  const [noticeInfo, setNoticeInfo] = useState(null);

  useMemo(() => {
    // 根据appId获取通知
    getAppNoticeInfo({ appId: getAppId() }).then((res) => {
      if (
        checkResponse(res) &&
        res?.data?.startDate &&
        res?.data?.endDate &&
        moment().isBetween(res.data?.startDate, res.data?.endDate)
      ) {
        setNoticeInfo(res.data);
      }
    });
  }, []);

  return noticeInfo ? (
    <Alert
      banner
      closable
      icon={<NotificationOutlined />}
      type={
        [
          NoticeType.Success,
          NoticeType.Info,
          NoticeType.Warning,
          NoticeType.Error,
        ].includes(noticeInfo.type)
          ? noticeInfo.type
          : 'warning'
      }
      message={
        <Marquee pauseOnHover gradient={false}>
          {noticeInfo.content}
        </Marquee>
      }
      style={{ padding: '4px 16px' }}
    />
  ) : (
    // eslint-disable-next-line react/jsx-no-useless-fragment
    <></>
  );
};

export default NoticeComp;
