import React, { Component, createRef, ReactElement } from 'react';
import screenfull from 'screenfull';
import { Menu, Layout, Select, Modal, Input } from 'antd';
import { FullscreenOutlined, FullscreenExitOutlined } from '@ant-design/icons';
import { isFunction, debounce } from 'lodash';
import QueueAnim from 'rc-queue-anim';
import moment from 'moment';
import {
  getUserInfo,
  setToken,
  setUserInfo,
  getSourceUserInfo,
} from '@cerdo/cerdo-utils/es/storage';
import waterMark from '@cerdo/cerdo-utils/es/waterMark';
import { findProxyUserList } from '@cerdo/cerdo-utils/es/api';
import { changeCurrentUser, goAuthPath } from '@cerdo/cerdo-utils/es/auth';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import layouts from 'layouts';
import proxyWindow from '@cerdo/cerdo-utils/es/proxyWindow';
import NoticeComp from './NoticeComp';
import Avatar from './Avatar';
import WebSocket from './Websocket';
import { type LayoutType } from '../layout/LayoutComponent';

interface IHeaderCustomProps {
  collapsed: boolean;
  extra: string | ReactElement;
  layout: LayoutType;
  flattenMenus: any[];
  onCollapsedChange: Function;
  handleMenuTreeChange: Function;
  onThemeChange: Function;
}

interface IHeaderCustomState<T = any> {
  /* 是否全屏 */
  isScreenfull: boolean;
  /* 是否展开 */
  collapsed: boolean;
  /* 用户信息 */
  userInfo: any;
  /* 代理用户列表 */
  proxyUserList: T[];
  /* 原始用户列表 */
  originUserList: T[];
  /* 模态框显示 */
  isModalVisible: boolean;
  /* 切换用户原因 */
  changeReason: string;
  /* 代理用户 */
  proxyUser: T;
  /* 默认布局 */
  defaultLayouts: any;
  /* 顶部菜单 */
  topMenu: any;
}

const { Header } = Layout;
const { Option } = Select;
const { TextArea } = Input;

class HeaderCustom extends Component<Partial<IHeaderCustomProps>, IHeaderCustomState> {
  private token: any;
  private textRef: React.RefObject<any>;
  private timer: any;
  // private menuClick: (e: React.MouseEvent<HTMLButtonElement>) => void;
  constructor(props: Partial<IHeaderCustomProps>) {
    super(props);
    this.state = {
      isScreenfull: false,
      collapsed: props.collapsed,
      userInfo: null,
      proxyUserList: null,
      originUserList: [], // 代理用户源数据
      isModalVisible: false,
      changeReason: '',
      proxyUser: null,
      defaultLayouts: layouts.main.layoutInit() || {},
      topMenu: layouts.main.topMenu,
    };
    this.handleSearch = debounce(this.handleSearch, 300); // 自定义搜索使用防抖动
    this.textRef = createRef(); // 切换用户原因 输入框
  }

  componentDidMount() {
    this.getUserInfoData();
    this.findProxyUserList();
    // 监听路由变化方式 初始化布局
    this.token = eventCenter.subscribe('hashChange', this.layoutInit);
  }

  componentWillUnmount() {
    if (this.timer) clearInterval(this.timer);
    if (this.token) eventCenter.unsubscribe(this.token);
  }

  layoutInit = () => {
    this.setState({
      defaultLayouts: layouts.main.layoutInit() || {},
    });
  };

  getUserInfoData = () => {
    this.timer = setInterval(() => {
      const userInfo = getUserInfo();
      if (userInfo) {
        clearInterval(this.timer);
        this.setState({ userInfo }, () => {
          waterMark({
            content: `${userInfo.name} ${moment().format('YYYY-MM-DD HH:mm')}`,
            width: '300px',
            height: '300px',
            rotate: '-24',
          });
        });
      }
    }, 500);
  };

  screenFull = () => {
    screenfull.toggle();
    const { isScreenfull } = this.state;
    this.setState({ isScreenfull: !isScreenfull });
  };

  toggle = () => {
    const { collapsed } = this.state;
    this.setState(
      {
        collapsed: !collapsed,
      },
      () => {
        const { onCollapsedChange } = this.props;
        if (isFunction(onCollapsedChange)) onCollapsedChange(!collapsed);
      },
    );
  };

  handleThemeClick = () => {
    const { onThemeChange } = this.props;
    if (isFunction(onThemeChange)) {
      onThemeChange();
    }
  };

  // 退出登录
  loginOut = () => {
    setToken(null);
    setUserInfo(null);
    this.setState({
      userInfo: null,
      proxyUserList: null,
    });
    goAuthPath();
  };
  // 查询可切换的用户列表
  findProxyUserList = () => {
    findProxyUserList().then((res) => {
      if (res?.data) {
        this.setState({
          proxyUserList: res.data,
          originUserList: res.data,
        });
      }
    });
  };
  // 切换登录
  handleChange = (value) => {
    const { proxyUserList } = this.state;
    const proxyUser = proxyUserList.find((i) => i.id === value);
    this.setState(
      {
        proxyUser: proxyUser,
        isModalVisible: true,
      },
      () => {
        // 切换用户登录时 默认聚焦
        // 使用微任务优先级别高的任务，等Dom节点加载完成之后，聚焦节点
        Promise.resolve().then(() => {
          this.textRef.current.focus({
            cursor: 'end',
          });
        });
      },
    );
  };
  handleOk = () => {
    const { changeReason, proxyUser } = this.state;
    if (!changeReason) {
      window.messageApi.warning('请先输入切换用户原因');
      return;
    }
    this.handleCancel();
    changeCurrentUser({ value: proxyUser.userId, reason: changeReason }, () => {
      // 用户切换成功之后，需要默认跳转到首页，重新刷新页面 执行 sso 登录
      (window as any).appHistory.replace(process.env.DEFAULT_PAGE || '/app');
      window.location.reload();
    });
  };

  handleCancel = () => {
    this.setState({
      isModalVisible: false,
      changeReason: '',
    });
  };

  // tip: 顶部菜单渲染 对flattenMenus做过滤，只展示 levelNum === 2 的系统菜单数据
  handleHeaderMenusRender = () => {
    const { flattenMenus } = this.props;
    if (Array.isArray(flattenMenus)) {
      let MenusComp = [];
      flattenMenus.forEach((item) => {
        if (item.levelNum === 2) {
          MenusComp.push(<Menu.Item key={item.id}>{item.perName}</Menu.Item>);
        }
      });
      // 如果只有一个系统级菜单，默认不展示
      return MenusComp.length > 1 ? MenusComp : [];
    }
    return [];
  };

  // 顶部菜单点击事件
  handleLeftMenuClick = (node) => {
    const {
      item: { props },
    } = node;
    // 如果不是菜单点击事件，不执行
    if (props.type !== 'menu') return;
    const key = node.key;
    this.props.handleMenuTreeChange(key);
  };

  // 代理用户自定义搜索事件
  handleSearch = (value) => {
    const { originUserList } = this.state;
    let proxyUserList = [];
    if (value) {
      // 过滤 userName / account 是否满足搜索条件
      proxyUserList = originUserList.filter((item) => {
        return item.userName?.indexOf(value) !== -1 || item.account?.indexOf(value) !== -1;
      });
      this.setState({
        proxyUserList,
      });
      return;
    }
    this.setState({
      proxyUserList: [...originUserList],
    });
  };

  render() {
    const {
      isScreenfull,
      // userInfo,
      proxyUserList,
      originUserList,
      isModalVisible,
      changeReason,
      proxyUser,
      defaultLayouts,
      topMenu,
    } = this.state;
    const { layout } = this.props;
    const sourceUser = getSourceUserInfo() || getUserInfo();
    // 通过框架默认配置 是否展示 顶部菜单，以框架配置为准
    // 头部菜单加载
    const headerMenusRender = topMenu ? this.handleHeaderMenusRender() : [];
    // 通过布局判断是否加载 headerMenus
    const isShowHeaderMenusRender =
      (headerMenusRender.length && layout !== 'top') ||
      (defaultLayouts.layout && defaultLayouts.layout !== 'top');
    return (
      <QueueAnim type="top">
        <div key="header">
          <NoticeComp />
          <Header>
            <Layout className="layout-header-menu" style={{ flexDirection: 'row' }}>
              <a
                href={
                  proxyWindow['env'].LOGO_LINK || `#${proxyWindow['env'].DEFAULT_PAGE}` || '#/app'
                }
                target="_blank"
              >
                <div key="logo" className="logo" style={{ marginLeft: '0' }} />
              </a>
              <Menu
                mode="horizontal"
                // theme="dark"
                style={{ flex: 1, background: 'transparent', border: 'none' }}
                onClick={this.handleLeftMenuClick}
              >
                {/* tip: 顶部菜单渲染  layouts = top 不展示顶部菜单 */}
                {!!isShowHeaderMenusRender && headerMenusRender}
                {/* 自定义layouts menusitem 存在才展示自定义 组件 */}
                {layouts.header.menuitem
                  .filter((item) => item.position === 'left')
                  .map((item, index) => {
                    let comp = null;
                    if (typeof item.component === 'string') {
                      comp = <Menu.Item key={index}>{item.component}</Menu.Item>;
                    } else {
                      comp = (
                        <Menu.Item key={index}>
                          <item.component />
                        </Menu.Item>
                      );
                    }
                    return comp;
                  })}
              </Menu>

              <Menu
                mode="horizontal"
                selectable={false}
                style={{
                  flex: 1,
                  justifyContent: 'flex-end',
                  background: 'transparent',
                  border: 'none',
                }}
              >
                {(process.env.layoutConfig as any)?.MARKETSALE && (
                  <Menu.Item key="MarketSale">{this.props.extra}</Menu.Item>
                )}
                {/* 框架支持自定义 Header => menuItem  */}
                {layouts.header.menuitem
                  .filter((item) => item.position === 'right')
                  .map((item, index) => {
                    let comp = null;
                    if (typeof item.component === 'string') {
                      comp = <Menu.Item key={index}>{item.component}</Menu.Item>;
                    } else {
                      comp = (
                        <Menu.Item key={index}>
                          <item.component />
                        </Menu.Item>
                      );
                    }
                    return comp;
                  })}
                {/* 通过框架配置是否开启 websocket */}
                <Menu.Item key="websocket">
                  <WebSocket />
                </Menu.Item>
                <Menu.Item key="full" onClick={this.screenFull}>
                  {!isScreenfull ? <FullscreenOutlined /> : <FullscreenExitOutlined />}
                </Menu.Item>
                <Menu.Item key="avatar">
                  <Avatar
                    layout={layout}
                    loginOut={this.loginOut}
                    handleThemeClick={this.handleThemeClick}
                  />
                </Menu.Item>
                <Menu.Item key="changeUser">
                  {Array.isArray(originUserList) && originUserList.length > 0 ? (
                    <Select
                      showSearch
                      onSearch={this.handleSearch}
                      optionFilterProp="children"
                      filterOption={false}
                      placeholder="切换用户"
                      style={{ width: 100 }}
                      onSelect={this.handleChange}
                    >
                      {Array.isArray(proxyUserList) &&
                        proxyUserList.map((item) => {
                          return (
                            <Option account={item.account} key={item.id} value={item.id}>
                              {item.userName}
                            </Option>
                          );
                        })}
                    </Select>
                  ) : (
                    ''
                  )}
                </Menu.Item>
              </Menu>
            </Layout>
          </Header>
          <Modal
            title={`当前为【${sourceUser?.userName}】模拟【${proxyUser?.userName}】登录，所有操作已记录。`}
            open={isModalVisible}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
          >
            <TextArea
              placeholder="切换用户原因"
              value={changeReason}
              rows={4}
              ref={this.textRef}
              autoFocus
              onChange={(e) => {
                this.setState({
                  changeReason: e.target.value,
                });
              }}
            />
          </Modal>
        </div>
      </QueueAnim>
    );
  }
}

export default HeaderCustom;
