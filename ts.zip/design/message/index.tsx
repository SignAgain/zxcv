import React, { useEffect } from 'react';
import { message, Modal, notification } from 'antd';
import type { HookAPI } from 'antd/es/modal/useModal';
import type { MessageInstance } from 'antd/es/message/interface';
import type { NotificationInstance } from 'antd/es/notification/interface';

const App: React.FC = () => {
  const [messageApi, messageHolder] = message.useMessage();
  const [modalApi, modalHolder] = Modal.useModal();
  const [notificationApi, notificationHolder] = notification.useNotification();

  useEffect(() => {
    if (messageApi) {
      setMessageInstance(messageApi);
    }
  }, [messageApi]);

  useEffect(() => {
    if (modalApi) {
      setModalInstance(modalApi);
    }
  }, [modalApi]);

  useEffect(() => {
    if (notificationApi) {
      setNotificationInstance(notificationApi);
    }
  }, [notificationApi]);

  return (
    <>
      {messageHolder}
      {modalHolder}
      {notificationHolder}
    </>
  );
};

const setMessageInstance = (instance: MessageInstance) => {
  window.messageApi = instance;
};

const setModalInstance = (instance: HookAPI) => {
  window.modalApi = instance;
};

const setNotificationInstance = (instance: NotificationInstance) => {
  window.notificationApi = instance;
};

export default App;
