import React, { useEffect } from 'react';
import proxyWindow from '@cerdo/cerdo-utils/es/proxyWindow';
import { getUserInfo } from '@cerdo/cerdo-utils/es/storage';
import moment from 'moment';
import EventReport from '@cerdo/cerdo-utils/es/EventReport';

const withGlobalEvents = (WrappedComponent) => {
  return (props) => {
    useEffect(() => {
      const createClickData = (event, element) => ({
        elementType: element.tagName.toLowerCase(),
        elementPositionX: event.clientX,
        elementPositionY: event.clientY,
        elementPositionW: element.offsetWidth,
        elementPositionH: element.offsetHeight,
        elementContent: element?.innerText,
        clickTime: moment().format('YYYY-MM-DD HH:mm:ss'),
        clickUser: getUserInfo()?.account,
        clickEventId: element.getAttribute('data-event-id') || 'UNKNOWN_EVENT',
        pageRoute: window.location.hash,
        pageTitle: document.title,
        eventType: event.type,
        appId: proxyWindow['env']?.APP_ID,
      });

      const handleGlobalClick = (event) => {
        if (process.env?.IS_EVENT_REPORT) {
          const target = event.target.closest('[data-event-id], .ant-btn');
          if (target) {
            const clickData = createClickData(event, target);
            EventReport.sendEvent(clickData);
          }
        }
      };

      // 监听全局点击事件
      document.addEventListener('click', handleGlobalClick);

      // 移除监听器，当组件卸载时
      return () => {
        document.removeEventListener('click', handleGlobalClick);
      };
    }, []);

    // 渲染包装的组件
    return <WrappedComponent {...props} />;
  };
};

export default withGlobalEvents;
