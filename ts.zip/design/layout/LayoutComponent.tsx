import React, { PureComponent, useEffect } from 'react';
import { Route } from 'react-router-dom';
import HeaderCustom from '../header/HeaderCustom';
import SilderCustom from '../silder/SilderCustom';
import MarketSale from '@cerdo/cerdo-design/es/marketsale/MarketSale';
import HeaderMenu from '../header/HeaderMenu';
import { FloatButton, Layout } from 'antd';
import { setTheme, getTheme } from '@cerdo/cerdo-utils/es/storage';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import { CacheSwitch } from 'react-router-cache-route';
import { renderFlattenRoute } from './permission';
import NotFound from '@cerdo/cerdo-design/es/pages/NotFound';
import NoPermission from '@cerdo/cerdo-design/es/pages/NoPermission';
import SingleLayoutComponent from './SingleLayoutComponent';
import proxyWindow from '@cerdo/cerdo-utils/es/proxyWindow';
import { treeToArray, generateHash } from '../__utils/index';
import ErrorBoundary from '@cerdo/cerdo-design/es/layout/ErrorBoundary';
import uniqueId from 'lodash/uniqueId';
import layouts from 'layouts';

const LoadDefaultCom = (props: { history?: any; menus?: any; location?: any }) => {
  const { menus } = props;
  const pathArr = ['/', proxyWindow['env'].DEFAULT_PAGE, '/app', '/app/404', '/app/Permission'];
  const newRoutemenus = treeToArray(menus);
  useEffect(() => {
    const {
      location: { pathname },
    } = props;
    const isExactRoute = newRoutemenus.length
      ? newRoutemenus.some((item: { perLink: any }) => {
          return item.perLink === pathname;
        })
      : true;
    if (pathArr.includes(pathname) || isExactRoute) {
      return;
    } else {
      props.history.push('/app/Permission');
    }
  });
  return null;
};

const { Content } = Layout;

export type LayoutType = 'sub' | 'top' | 'mix' | 'avatar';

export interface ILayoutComponentProps {
  layout?: LayoutType;
  className: string;
  style: React.CSSProperties;
  appInfos: object[];
  menus: any[];
}

export interface ILayoutComponentState {
  collapsed: boolean;
  appInfos: object[];
  menus: any[];
  layout: LayoutType;
  hiddenMenuTab: boolean;
  showheadcustom: boolean;
  parentTreeId: string;
  flattenMenus: any;
}

class LayoutComponent extends PureComponent<ILayoutComponentProps, ILayoutComponentState> {
  static getDerivedStateFromProps(props, state) {
    let flattenMenus = [];
    let parentTreeId = state.parentTreeId;
    const resetMenuData = (arr: any) => {
      // 对数组每一项增加 key 字段
      return treeToArray(arr || []);
    };
    if (state.flattenMenus.length) {
      flattenMenus = state.flattenMenus;
    } else {
      flattenMenus = resetMenuData(props.menus || []);
    }
    // 初始化 parentTreeId 是否存在，不存在设置默认值
    if (!state.parentTreeId && props.menus?.length) {
      parentTreeId = props.menus[0].id;
    }
    return {
      menus: props.menus || [],
      flattenMenus,
      parentTreeId,
      appInfos: props.appInfos || [],
      ...props,
    };
  }

  constructor(props: ILayoutComponentProps | Readonly<ILayoutComponentProps>) {
    super(props);
    this.state = {
      // 可配置 左侧菜单是否默认收起状态
      collapsed: layouts.silde.menu.collapsed || false,
      menus: [],
      showheadcustom: true,
      layout: 'sub',
      appInfos: [],
      hiddenMenuTab: false,
      flattenMenus: [],
      parentTreeId: null, // 顶部菜单选中的菜单ID
    };
    this.changeTheme = this.changeTheme.bind(this);
    this.onChangeLayout = this.onChangeLayout.bind(this);
  }

  componentDidMount() {
    this.layoutInit();
    // 接受 tab页签刷新事件
    eventCenter.subscribe('tabReload', this.handleTabReload);
    // 接受 tab页签刷新事件
    eventCenter.subscribe('hashChange', this.layoutInit);
  }

  layoutInit = () => {
    // 加载项目应用 layoutInit 方法
    let value = 'mix';
    if (this.props.layout) {
      value = this.props.layout;
    }

    // 加载项目应用 layoutInit 方法
    const { layout: initLayout, ...other } = layouts.main.layoutInit() || {};
    // 如果存在 layout: initLayout 重新替换 layoutValue
    if (initLayout) {
      value = initLayout;
    }

    const { layout } = (window as any).getUrlParams();
    if (layout) {
      value = layout;
    }

    this.onChangeLayout({ layout: value, ...other });
  };

  handleTabReload = (type: any, data: { path: any }) => {
    const { flattenMenus } = this.state;
    let { path } = data;
    if (path && path.indexOf('?') >= 0) {
      path = path.split('?')[0];
    }
    // 从数据源中找到与当前 path 对应的 menuItem
    let newFlattenMenus = flattenMenus.map((item: { perLink: any }) => {
      if (item.perLink === path) {
        return { ...item, suffixKey: `-${generateHash(uniqueId())}` };
      }
      return { ...item };
    });
    this.setState({
      flattenMenus: newFlattenMenus,
    });
  };

  // 修改主题
  changeTheme(value: any) {
    let currentTheme = getTheme();
    if (!value) {
      currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    } else {
      currentTheme = value;
    }
    setTheme(currentTheme);
    // eventCenter.publish('changeTheme', { theme: currentTheme });
    (window as any).postMessageToIframe('changeTheme', { theme: currentTheme });
  }
  // 切换layout布局 (side,top,mix,sub)
  onChangeLayout({ layout, ...other }) {
    this.setState({
      layout,
      ...other,
    });
    eventCenter.publish('changeLayout', { layout });
  }

  // 加载微应用容器
  handleMicroContainerRender = () => {
    // 如果是主应用 并且 layouts 里边配置 microApp 才加载对应的容器列表
    if (process.env.IS_MAIN) {
      const { appInfos } = this.state;
      const microApp = Array.isArray(layouts.main.microApp) ? layouts.main.microApp : [];
      const microAppContainer = [];
      appInfos.forEach((item: { id: React.Key }) => {
        if (microApp.includes(item.id)) {
          microAppContainer.push(<div id={String(item.id)} key={item.id} />);
        }
      });
      return microAppContainer;
    }
    return [];
  };

  // 通过头部菜单点击，切换左侧菜单树
  handleMenuTreeChange = (key: any) => {
    // 如果当前选中菜单id和选中的key是相同的，则不设置
    const { parentTreeId } = this.state;
    if (key === parentTreeId) return;
    this.setState({
      parentTreeId: key,
    });
  };

  render() {
    const { menus, layout, hiddenMenuTab, flattenMenus, parentTreeId } = this.state;
    const { style = {}, className = '' } = this.props;

    if (layout === 'sub') {
      return <SingleLayoutComponent className={className} style={style} menus={menus} />;
    }

    return (
      <Layout style={{ height: '100vh' }}>
        {layout && (layout === 'top' || layout === 'mix') && (
          <HeaderCustom
            key="HeaderCustom"
            layout={layout}
            flattenMenus={flattenMenus}
            onThemeChange={(value: any) => this.changeTheme(value)}
            handleMenuTreeChange={this.handleMenuTreeChange}
            extra={<MarketSale />}
          />
        )}
        <Layout className="ant-layout-has-sider">
          {layout !== 'top' && (
            <SilderCustom
              key="SilderCustom"
              parentTreeId={parentTreeId}
              menus={menus}
              layout={layout}
              flattenMenus={flattenMenus}
              onThemeChange={this.changeTheme}
            />
          )}
          <Layout>
            {!hiddenMenuTab && layout !== 'top' && (
              <HeaderMenu menus={menus} flattenMenus={flattenMenus} />
            )}
            <Content className={className} style={{ ...style }}>
              <ErrorBoundary>
                <CacheSwitch>
                  {this.props.children}
                  {renderFlattenRoute(flattenMenus)}
                  <Route path="/app/404" key="/app/404" component={NotFound} />
                  <Route path="/app/Permission" key="/app/Permission" component={NoPermission} />
                  <Route
                    render={(props) => {
                      return <LoadDefaultCom {...props} menus={menus} />;
                    }}
                  />
                </CacheSwitch>
              </ErrorBoundary>
              {this.handleMicroContainerRender()}
            </Content>
            {layouts.main.backTop && !(window as any).__POWERED_BY_QIANKUN__ && (
              <FloatButton.BackTop target={() => document.getElementsByTagName('main')[0]} />
            )}
          </Layout>
        </Layout>
      </Layout>
    );
  }
}
export default LayoutComponent;
