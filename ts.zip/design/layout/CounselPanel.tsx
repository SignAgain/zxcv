import React, { useState } from 'react';
import { Popover, Divider } from 'antd';
import Icon from '@cerdo/cerdo-design/es/icon/Icon';
import layouts from 'layouts';

const counselPanels = layouts.main?.counselPanels;

const CounselPanel: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);

  return counselPanels?.length ? (
    <div className="counsel-panel">
      <div className="panel-content">
        <div className="panel-content-icon" onClick={() => setIsOpen(!isOpen)}>
          <Icon type="counsel-fill" />
        </div>
        {isOpen && (
          <div className="panel-content-list">
            {counselPanels.map((item, index) => {
              return (
                <Popover content={item?.content} title={item?.title} key={index} placement="left">
                  {index !== 0 && <Divider dashed style={{ margin: 0 }} />}
                  <div className="item" key={index}>
                    <Icon type={item?.icon} />
                  </div>
                </Popover>
              );
            })}
          </div>
        )}
      </div>
    </div>
  ) : null;
};

export default CounselPanel;
