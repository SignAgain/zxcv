import React, { Suspense } from 'react';
import NotFound from '@cerdo/cerdo-design/es/pages/NotFound';
import WebView from '@cerdo/cerdo-design/es/pages/WebView';
import { Route } from 'react-router-dom';
import { CacheRoute } from 'react-router-cache-route';
import { getAllComponents } from '@cerdo/cerdo-utils/es/auth';
import { setQueryString } from '@cerdo/cerdo-utils/es/url';
import proxyWindow from '@cerdo/cerdo-utils/es/proxyWindow';
import layouts from 'layouts';
import ErrorBoundary from '@cerdo/cerdo-design/es/layout/ErrorBoundary';

interface IRenderRoute {
  route: object[];
  preKeyUrl?: string;
}

export const renderRoute: React.FC<IRenderRoute> = (route, preKeyUrl = '') =>
  renderRouteTree(route, preKeyUrl);
export const renderFlattenRoute: React.FC<IRenderRoute> = (route, preKeyUrl = '') =>
  renderRouteTree(route, preKeyUrl, false);

// 如果菜单数据已经扁平化之后，不需要渲染 children
const renderRouteTree = (route, preKeyUrl = '', isRenderChildren = true) =>
  route?.map((r) => {
    r.perLink = preKeyUrl + r.perLink;
    if (r.children && r.children.length > 0) {
      return isRenderChildren ? renderRoute(r.children, preKeyUrl) : null;
    } else {
      if (proxyWindow['env'].APP_ID !== r.appId) {
        return null;
      }
      const MyRoute = r.nocatch === '1' || process.env.NO_CACHE_ROUTE ? Route : CacheRoute;

      // 是否是通过iframe嵌入的
      if (r.dynamicPath?.startsWith('http')) {
        return (
          <MyRoute
            key={r.perLink}
            cacheKey={r.perLink}
            exact
            className="cerdo-iframe-container"
            path={r.perLink}
            render={() => {
              if (!layouts.silde.menu.loadRoute(r)) {
                return null;
              }
              return <WebView webUrl={r.dynamicPath} />;
            }}
          />
        );
      }

      // 带？参数的路由地址
      let routePath;
      const pIndex = r.perLink?.indexOf('?');
      const startHttp = r.perLink?.startsWith('http');
      if (pIndex > -1 && !startHttp) {
        routePath = r.perLink.substring(0, pIndex);
      }

      // 路由匹配
      let AllComponents = getAllComponents();
      const Component = AllComponents[r.compName];
      if (!Component) {
        if (!proxyWindow['env'].isMain) {
          return (
            <Route
              // cacheKey={r.perLink}
              key={r.perLink}
              path={r.perLink}
              component={NotFound}
            />
          ); // 判断 该组件是否存在 不存在返回null 否则路由跳转找不到组件 会报错
        }
        return null;
      }

      let uniqueIdKey = `${r.perLink}${r.suffixKey || ''}`;

      return (
        <MyRoute
          key={uniqueIdKey}
          cacheKey={uniqueIdKey}
          exact
          className="cerdo-page-container"
          path={r.dynamicPath || routePath || r.perLink}
          render={(props) => {
            const reg = /\?\S*/g;
            // 匹配?及其以后字符串
            const queryParams = r.perLink.match(reg);
            if (!layouts.silde.menu.loadRoute(r)) {
              return null;
            }
            // 去除?的参数
            const params = props.match?.params || null;
            if (params) {
              Object.keys(params).forEach((key) => {
                params[key] = params[key]?.replace(reg, '');
              });
              props.match.params = { ...params };
            } else {
              props.match.params = {};
            }

            const merge = {
              ...props,
              query: {
                ...(queryParams ? setQueryString(queryParams[0]) : {}),
                weburl: r.weburl,
              },
              title: r.perName
            };
            // 重新包装组件
            const wrappedComponent = (
              <Suspense fallback={<layouts.components.loading />}>
                <ErrorBoundary>
                  <div key={uniqueIdKey} id={r.perLink} style={{ height: '100%' }}>
                    <Component key={uniqueIdKey} {...merge} />
                  </div>
                </ErrorBoundary>
              </Suspense>
            );
            return wrappedComponent;
          }}
        />
      );
    }
  });
