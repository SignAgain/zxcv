import React, { useState, useMemo } from 'react';
import cs from 'classnames';
import { Drawer, Tooltip, Divider } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { CloseOutlined, SettingOutlined } from '@ant-design/icons';
import { getLayout, getTheme } from '@cerdo/cerdo-utils/es/storage';

export interface IBlockCheckboxProps {
  prefixCls?: string;
  value?: string;
  configType?: 'theme' | 'layout';
  onChange?: (key: string) => void;
  list?: ILayout[] | ITheme[];
}

const Body: React.FC<React.PropsWithChildren<{ prefixCls: string; title: string }>> = ({
  children,
  prefixCls,
  title,
}) => {
  return (
    <div style={{ marginBottom: 24 }}>
      <h3 className={`${prefixCls}-drawer-title`}>{title}</h3>
      {children}
    </div>
  );
};

const BlockCheckbox: React.FC<IBlockCheckboxProps> = (props) => {
  const { value, configType, onChange, list, prefixCls } = props;
  const baseClassName = `${prefixCls}-drawer-block-checkbox`;
  const dom = useMemo(() => {
    const domList = (list || []).map((item) => (
      <Tooltip title={item.title} key={item.key}>
        <div
          className={cs([
            `${baseClassName}-item`,
            `${baseClassName}-item-${item.key}`,
            `${baseClassName}-${configType}-item`,
          ])}
          onClick={() => onChange(item.key)}
        >
          <CheckOutlined
            className={`${baseClassName}-selectIcon`}
            style={{
              display: value === item.key ? 'block' : 'none',
            }}
          />
        </div>
      </Tooltip>
    ));
    return domList;
  }, [value, list?.length, onChange]);
  return (
    <div
      className={baseClassName}
      style={{
        minHeight: 42,
      }}
    >
      {dom}
    </div>
  );
};

type ThemeType = 'light' | 'dark';

type LayoutType = 'mix' | 'side' | 'top';

interface ITheme {
  key: ThemeType;
  title: string;
}

interface ILayout {
  key: LayoutType;
  title: string;
}

export interface ISettingDrawerProps {
  onChangeTheme?: (v: ThemeType) => void;
  onChangeLayout?: (v: LayoutType) => void;
}

const BASE_CLASS_NAME = 'ant-pro-hb-setting';

const LAYOUT_LIST: ILayout[] = [
  {
    key: 'side',
    title: '侧边菜单布局',
  },
  {
    key: 'top',
    title: '顶部菜单布局',
  },
  {
    key: 'mix',
    title: '混合菜单布局',
  },
];

const THEME_LIST: ITheme[] = [
  {
    key: 'light',
    title: '亮色菜单风格',
  },
  {
    key: 'dark',
    title: '暗色菜单风格',
  },
];

const SettingDrawer: React.FC<ISettingDrawerProps> = (props) => {
  const { onChangeTheme, onChangeLayout } = props;
  const [show, setShow] = useState(false);
  const [theme, setTheme] = useState<ThemeType>(getTheme() || 'light');
  const [layout, setLayout] = useState<LayoutType>(getLayout() || 'mix');

  const showDrawer = () => {
    setShow(!show);
  };

  return (
    <>
      <div className={`${BASE_CLASS_NAME}-drawer-handle`} onClick={showDrawer}>
        {show ? (
          <CloseOutlined
            style={{
              color: '#fff',
              fontSize: 20,
            }}
          />
        ) : (
          <SettingOutlined
            style={{
              color: '#fff',
              fontSize: 20,
            }}
          />
        )}
      </div>
      <Drawer
        open={show}
        width={300}
        closable={false}
        onClose={() => setShow(false)}
        placement="right"
        rootStyle={{
          zIndex: 999,
        }}
      >
        <div className={`${BASE_CLASS_NAME}-drawer-content`}>
          <Body title="整体风格设置" prefixCls={BASE_CLASS_NAME}>
            <BlockCheckbox
              prefixCls={BASE_CLASS_NAME}
              list={THEME_LIST}
              value={theme}
              configType="theme"
              key="theme"
              onChange={(value: ThemeType) => {
                setTheme(value);
                onChangeTheme(value);
              }}
            />
          </Body>
          <Divider />
          <Body title="导航模式" prefixCls={BASE_CLASS_NAME}>
            <BlockCheckbox
              prefixCls={BASE_CLASS_NAME}
              list={LAYOUT_LIST}
              value={layout}
              configType="layout"
              key="layout"
              onChange={(value: LayoutType) => {
                setLayout(value);
                onChangeLayout(value);
              }}
            />
          </Body>
          <Divider />
        </div>
      </Drawer>
    </>
  );
};

export default SettingDrawer;
