import React, { PureComponent } from 'react';
import { FloatButton, Layout } from 'antd';
import { CacheSwitch } from 'react-router-cache-route';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import uniqueId from 'lodash/uniqueId';
import { renderFlattenRoute } from './permission';
import { treeToArray, generateHash } from '../__utils/index';
import ErrorBoundary from '@cerdo/cerdo-design/es/layout/ErrorBoundary';
import layouts from 'layouts';

const { Content } = Layout;

export interface ILayoutComponentProps {
  style: React.CSSProperties;
  className?: string;
  preKeyUrl?: string;
  menus?: any[];
}

export interface ILayoutComponentState {
  preKeyUrl: string;
  menus: any[];
  flattenMenus: any;
}

export class LayoutComponent extends PureComponent<ILayoutComponentProps, ILayoutComponentState> {
  public static getDerivedStateFromProps(props, state) {
    if (!props.menus) return null;
    let flattenMenus = [];
    const resetMenuData = (arr) => {
      // 对数组每一项增加 key 字段
      return treeToArray(arr || []);
    };
    if (state.flattenMenus.length) {
      flattenMenus = state.flattenMenus;
    } else {
      flattenMenus = resetMenuData(props.menus || []);
    }
    return { menus: props.menus, flattenMenus };
  }

  private token: any;

  public constructor(props) {
    super(props);
    this.state = {
      menus: this.props.menus || [],
      preKeyUrl: this.props.preKeyUrl || '',
      flattenMenus: [],
    };
    this.token = null;
  }

  public componentDidMount() {
    this.token = eventCenter.subscribe('tabReload', this.handleTabReload);
  }

  public componentWillUnmount() {
    this.token && eventCenter.unsubscribe(this.token);
  }

  public handleTabReload = (type, data) => {
    const { flattenMenus } = this.state;
    let { path } = data;
    if (path && path.indexOf('?') >= 0) {
      path = path.split('?')[0];
    }
    // 从数据源中找到与当前 path 对应的 menuItem
    let newFlattenMenus = flattenMenus.map((item) => {
      if (item.perLink === path) {
        return { ...item, suffixKey: `-${generateHash(uniqueId())}` };
      }
      return { ...item };
    });
    this.setState({
      flattenMenus: newFlattenMenus,
    });
  };

  public render() {
    const { preKeyUrl, flattenMenus } = this.state;
    const { style = {}, className = '' } = this.props;
    return (
      <Layout
        className="ant-layout-has-sider"
        style={(window as any).__POWERED_BY_QIANKUN__ ? { height: '100%' } : { height: '100vh' }}
      >
        <Content className={className} style={{ overflow: 'auto', flex: '1 1 0px', ...style }}>
          <ErrorBoundary>
            <CacheSwitch>
              {this.props.children}
              {renderFlattenRoute(flattenMenus, preKeyUrl)}
            </CacheSwitch>
          </ErrorBoundary>
        </Content>
        {layouts.main.backTop && !(window as any).__POWERED_BY_QIANKUN__ && (
          <FloatButton.BackTop target={() => document.getElementsByTagName('main')[0]} />
        )}
      </Layout>
    );
  }
}
export default LayoutComponent;
