import { loadMicroApp } from 'qiankun';
import { getItem } from '@cerdo/cerdo-utils/es/storage';

class SingleSpaStore {
  private activeApp = {}; // 正在激活的 微应用
  private loadedMicroApps = []; // 已加载 微应用

  createMicroApp(path) {
    return new Promise<void>((resolve, reject) => {
      if (!this.isMicroApp(path)) {
        // 非微应用直接跳转
        resolve();
        return;
      }

      // 微应用跳转处理
      /**
       * @description 1.判断是否已手动加载，是则直接跳转，否则先手动挂载，再跳转
       */
      const microAppResult = this.findMicroAppByPath(path); // 是否是微应用的跳转
      if (
        Object.prototype.hasOwnProperty.call(
          this.loadedMicroApps,
          microAppResult.name
        )
      ) {
        this.setActiveApp(microAppResult);
        resolve();
        return;
      }
      try {
        loadMicroApp(microAppResult); // 加载微应用
        this.loadedMicroApps[microAppResult.name] = microAppResult;
        this.setActiveApp(microAppResult);
        console.log('挂载后的已挂载的微应用==>', this.loadedMicroApps);
        resolve();
      } catch (err) {
        reject(err);
        console.log(err);
      }
    });
  }

  getLoadedApps() {
    return this.loadedMicroApps;
  }

  getActiveApps() {
    return this.activeApp;
  }

  getAppInfos() {
    return getItem('appInfos') || [];
  }

  getAppInfo() {}

  private isMicroApp(path) {
    const microAppList = getItem('appInfos');
    return !!microAppList.some((item) => {
      if (Array.isArray(item.activeRule)) {
        return !!item.activeRule.some((ruleItem) => {
          return path.startsWith(ruleItem);
        });
      }
      return path.startsWith(item.activeRule);
    });
  }

  private setActiveApp(app) {
    this.activeApp = { ...app };
  }

  private findMicroAppByPath(path) {
    const microAppList = this.getAppInfos();
    return microAppList.find((item) => {
      let activeRule = item.activeRule;
      if (Array.isArray(activeRule)) {
        return !!activeRule.some((ruleItem) => {
          return path.startsWith(ruleItem);
        });
      }
      return path.startsWith(activeRule);
    });
  }
}

export default SingleSpaStore;
