import React, { useEffect, useMemo, useState } from 'react';
import { ConfigProvider } from 'antd';
import { lightTheme } from './lightTheme';
import { darkTheme } from './darkTheme';
import { darkTheme as lineDarkTheme } from './lineDarkTheme';
import { lightTheme as lineLightTheme } from './lineLightTheme';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import { getTheme } from '@cerdo/cerdo-utils/es/storage';
import zhCN from 'antd/locale/zh_CN';

const ThemeProvider = ({ children }) => {
  const [customTheme, setCustomTheme] = useState(getTheme());

  // 事件监听
  useEffect(() => {
    eventCenter.subscribe('changeTheme', (_, { theme }) => {
      setCustomTheme(theme);
    });
  }, []);

  const customDarkTheme = useMemo(() => {
    return process.env.IS_LINE_COMPONENT ? lineDarkTheme : darkTheme;
  }, [darkTheme, lineDarkTheme]);

  const customLightTheme = useMemo(() => {
    return process.env.IS_LINE_COMPONENT ? lineLightTheme : lightTheme;
  }, [lightTheme, lineLightTheme]);

  const customThemeConfig = useMemo(() => {
    return {
      ...(customTheme === 'dark' ? customDarkTheme : customLightTheme),
    };
  }, [customTheme]);

  return (
    <ConfigProvider locale={zhCN} theme={customThemeConfig}>
      {children}
    </ConfigProvider>
  );
};

export default ThemeProvider;
