export interface IDictType {
  [key: string]: any;
}

export type ThemeType = 'dark' | 'light';

export type LayoutType = 'mix' | 'side' | 'top';
