/** 系统配置 */
export interface ISystemConfig {
  /**  dev server 端口 */
  devServerPort?: number;
  /**  私有库命名空间 */
  npmScope?: string;
  /** 是否是主应用 */
  isMain?: boolean;
  /**
   * 接口请求超时时间
   * tips: 放置在这里是否合理
   **/
  timeout?: number;
  /** 自定义属性 */
  [key: string]: any;
}

// dev 开发环境 api 接口请求配置
export interface IApiConfig {
  /** 接口转发配置规则 */
  domain?: {
    /** 自定义属性 */
    [key: string]: any;
  };
  /** 接口请求超时时间 */
  timeout?: number;
  /** 自定义属性 */
  [key: string]: any;
}

/** 系统布局配置 */
export interface ILayoutConfig {
  /** 全市场组件是否展示 */
  MARKETSALE?: boolean;
  /** 自定义属性 */
  [key: string]: any;
}

/** webpack环境配置 */
export interface IDefinePlugin {
  /** 系统应用 ID */
  APP_ID: string;
  /** 与后端服务相对应秘钥 */
  APP_SECRET: string;
  /** 系统应用名 */
  PROJECT_NAME: string;
  /** 生成静态资源访问路径 */
  PUBLIC_PATH: string;
  /**  默认主题配置 */
  DEFAULT_THEME?: string;
  /** 默认访问首页配置 */
  DEFAULT_PAGE?: string;
  /** 请求应用菜单接口时携带 */
  APP_SOURCE?: string;
  /** 路由是否缓存 */
  NO_CACHE_ROUTE?: boolean;
  /** dev开发环境远程模块加载入口地址 */
  DEV_REMOTE_MODULE_ENTRY?: string;
  /** dev开发环境是否开始日志上报功能 */
  DEBUG_SENTRY?: boolean | string;
  /** 是否开启事件上报功能 */
  IS_EVENT_REPORT?: boolean;
  /** 是否开启组件调试模式 */
  IS_COMPONENTS_DEBUG_MODE?: boolean;
  /** 自定义属性 */
  [key: string]: any;
}

export interface config {
  /** 系统配置 */
  systemConfig: ISystemConfig;
  /** Api 请求配置 */
  apiConfig: IApiConfig;
  /** 系统布局配置 */
  layoutConfig?: ILayoutConfig;
  /** webpack环境配置 */
  definePlugin?: IDefinePlugin;
  /** webpack配置 */
  webpackConfig?: {
    chainWebpack?: (webpackConfig: any) => void;
    resolveAlias?: Object;
    copyWebpack?: object[];
  };
}
