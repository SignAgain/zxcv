import React, { useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { Form, Input, Button, theme } from 'antd';
import { FormInstance } from 'antd/es/form';
import { UserOutlined, LockOutlined, EyeInvisibleOutlined, EyeTwoTone } from '@ant-design/icons';
import { RouteComponentProps } from 'react-router-dom';
import Texty from 'rc-texty';
import QueueAnim from 'rc-queue-anim';
import { upmLoginByCaptcha, getSecret, getCaptcha } from '@cerdo/cerdo-utils/es/api';
import {
  removeItem,
  setToken,
  setUserInfo,
  setSourceUserInfo,
} from '@cerdo/cerdo-utils/es/storage';
import { checkResponse } from '@cerdo/cerdo-utils/es/fn';
import { aesEncrypt } from '@cerdo/cerdo-utils/es/aes';

const FormItem = Form.Item;
const { useToken } = theme;

interface LoginState {
  loading: boolean;
  captchaKey?: string;
}

interface AesSecret {
  [key: string]: any;
}

interface VerifyCodeRef {
  queryCaptcha: () => void;
}

interface VerifyCodeProps {
  onRefresh: (captchaKey: string) => void;
}

// 图形验证码
const VerifyCode = forwardRef<VerifyCodeRef, VerifyCodeProps>((props, ref) => {
  const { onRefresh } = props;
  const [imgUrl, setImageUrl] = useState('');
  const { token } = useToken();
  console.log('token', token);

  useImperativeHandle(ref, () => {
    return {
      queryCaptcha,
    };
  });

  useEffect(() => {
    queryCaptcha();
  }, []);

  const queryCaptcha = () => {
    getCaptcha().then((res) => {
      if (checkResponse(res)) {
        setImageUrl(res?.data?.captcha);
        onRefresh(res?.data?.captchaKey);
      }
    });
  };

  return (
    <img
      onClick={queryCaptcha}
      src={imgUrl}
      title="点击刷新验证码"
      style={{ width: '80px', height: '30px', cursor: 'pointer', borderStartEndRadius: token.borderRadius, borderEndEndRadius: token.borderRadius, lineHeight: 0 }}
    />
  );
});

class Login extends React.Component<RouteComponentProps, LoginState> {
  form = React.createRef<FormInstance>();
  aesSecret: AesSecret = {};
  verifyCodeRef = React.createRef<VerifyCodeRef>();

  constructor(props: RouteComponentProps) {
    super(props);
    this.state = {
      loading: false,
      captchaKey: '',
    };
  }

  componentDidMount() {
    removeItem('sessionid');
    removeItem('user');
    removeItem('cerdo_web_token');
    this.querySecret();
  }

  // 获取aes动态秘钥
  querySecret = () => {
    getSecret().then((res) => {
      if (checkResponse(res)) {
        this.aesSecret = res.data;
      }
    });
  };

  handleSubmit = (values) => {
    this.setState({ loading: true });
    const { key_1, key_2, secretId } = this.aesSecret;
    const { captchaKey } = this.state;
    values.authType = 'single';

    values.secretId = secretId;
    values.password = aesEncrypt(values.password, key_1, key_2);
    values.captchaKey = captchaKey;
    upmLoginByCaptcha(values).then((result) => {
      this.setState({ loading: false });
      if (checkResponse(result)) {
        if (result?.data?.token) {
          if (result.data.token) {
            setToken(result.data.token);
          }
          setUserInfo({
            ...result.data,
            userid: result.data.id,
            // account: result.data.userAccount,
            name: result.data.userName,
          });
          setSourceUserInfo(result.data);
        }
        const { history } = this.props;
        const { returnUrl } = window.getUrlParams();
        history.push(returnUrl ? returnUrl : process.env.DEFAULT_PAGE || '/app');
      } else {
        window.messageApi.error(result.message);
        if (result?.code === 'AU0004') {
          // 验证码错误,刷新验证码
          this.verifyCodeRef.current.queryCaptcha();
        }
      }
    });
    // this.form.current.validateFields().then((values) => { });
  };

  onRefresh = (captchaKey) => {
    this.setState({ captchaKey });
  };

  render() {
    const { loading } = this.state;
    return (
      <div className="login">
        <QueueAnim type="bottom">
          <div key="form" className="login-form">
            <div className="login-logo">
              {['test', 'dev'].includes(window.env) ? (
                <Texty>统一登录入口【UPM】</Texty>
              ) : (
                <Texty>统一登录入口</Texty>
              )}
            </div>
            <Form style={{ maxWidth: '300px' }} ref={this.form} onFinish={this.handleSubmit}>
              <QueueAnim type="left">
                <div key="userId">
                  <FormItem name="userId" rules={[{ required: true, message: '请输入用户名' }]}>
                    <Input
                      prefix={<UserOutlined className="site-form-item-icon" />}
                      placeholder="用户名"
                    />
                  </FormItem>
                </div>
                <div key="password">
                  <FormItem name="password" rules={[{ required: true, message: '请输入密码' }]}>
                    <Input.Password
                      prefix={<LockOutlined className="site-form-item-icon" />}
                      placeholder="密码"
                      iconRender={(visible) =>
                        (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />) as React.ReactNode
                      }
                    />
                  </FormItem>
                </div>
                <div key="captcha">
                  <FormItem name="captcha" rules={[{ required: true, message: '请输入验证码' }]}>
                    <Input
                      className="captcha-input"
                      prefix={<LockOutlined className="site-form-item-icon" />}
                      placeholder="验证码"
                      addonAfter={
                        <VerifyCode ref={this.verifyCodeRef} onRefresh={this.onRefresh} />
                      }
                    />
                  </FormItem>
                </div>
                <div key="submit">
                  <FormItem>
                    <Button
                      style={{ marginTop: 20 }}
                      htmlType="submit"
                      type="primary"
                      loading={loading}
                      className="login-form-button"
                    >
                      登录
                    </Button>
                  </FormItem>
                </div>
              </QueueAnim>
            </Form>
          </div>
        </QueueAnim>
      </div>
    );
  }
}

export default Login;
