import uniqueId from 'lodash/uniqueId';

export interface IPageMap {
  perLink: string;
  perName: string;
  key: string;
}

export const pageMap: IPageMap[] = [
  {
    perLink: '/app/404',
    perName: '404',
    key: '404',
  },
  {
    perLink: '/app/Permission',
    perName: '403',
    key: '403',
  },
];

/**
 * 用于生成 input 的值对应的唯一哈希值
 * @param input
 * @return {string}
 */
export const generateHash = (input: string): string => {
  let I64BIT_TABLE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-'.split('');
  let hash = 5381;
  let i = input.length - 1;

  if (typeof input === 'string') {
    for (input.length - 1; i > -1; i--) {
      hash += (hash << 5) + input.charCodeAt(i);
    }
  } else {
    for (; i > -1; i--) {
      hash += (hash << 5) + input[i];
    }
  }

  let value = hash & 0x7fffffff;
  let retValue = '';

  do {
    retValue += I64BIT_TABLE[value & 0x3f];
  } while ((value >>= 6));

  return retValue;
};


/**
 * 用于生成 扁平化数组 同时增加 suffixKey 
 * @param input
 * @return {string}
 */
export const treeToArray = (tree: any[]): any[] => {
  const arr: any[] = [];
  const expanded = (data: any[]) => {
    if (data?.length) {
      data.forEach((item) => {
        arr.push({ ...item, suffixKey: `-${generateHash(uniqueId())}` });
        expanded(item.children);
      });
    }
  };
  expanded(tree);
  return arr;
};

export default {
  pageMap,
	treeToArray,
  generateHash,
};
