import React from 'react';
import LoadComponent from '@cerdo/cerdo-design/es/loading/LoadComponent';

interface DefaultMarket {
  name: string;
  shortName: string;
}

export interface ILayout {
  header: {
    menuitem: any[];
    usermenuitem: any[];
    defaultMarket?: () => DefaultMarket[];
  };
  main: {
    getMenu: () => void;
    layoutInit: () => Object;
    formatMenu: (menus: any[]) => any[];
    microApp: any[];
    backTop: boolean;
    topMenu: boolean;
    counselPanels: any[];
  };
  footer: Object;
  components: Record<string, React.ReactNode>;
  silde: {
    menu: {
      collapsed: boolean;
      hidden: boolean;
      togglehidden: boolean;
      loadRoute: (menuItem: Object) => boolean;
    };
    menuTab: {
      hidden: boolean;
    };
    settingButton: {
      hidden: boolean;
    };
  };
  iframe: {
    paramsInit: (params: string) => string;
  };
  method?: {
    authMethod?: null | (() => void);
    defaultHearders?: () => object;
  };
  ws?: {
    path?: string;
    params?: {
      auth?: boolean;
    };
    ackSend?: boolean;
    onPublish?: () => void;
  };
}

const defaultLayouts: ILayout = {
  header: {
    menuitem: [],
    usermenuitem: [],
    defaultMarket: () => [
      { name: '上交所', shortName: '上' },
      { name: '港交所', shortName: '港' },
      { name: '美交所', shortName: '美' },
    ],
  },
  main: {
    getMenu: async () => {},
    layoutInit: () => {
      return {};
    },
    formatMenu: (menu) => menu,
    microApp: [],
    backTop: false,
    topMenu: false,
    counselPanels: [],
  },
  footer: {},
  components: {
    loading: LoadComponent,
  },
  silde: {
    menu: {
      collapsed: false,
      hidden: false,
      togglehidden: false,
      loadRoute: () => {
        return true;
      },
    },
    menuTab: {
      hidden: false,
    },
    settingButton: {
      hidden: false,
    },
  },
  iframe: {
    paramsInit: (url) => url,
  },
  method: {
    authMethod: null,
    defaultHearders: () => ({}),
  },
  ws: {
    params: {
      auth: true,
    },
    ackSend: false,
  },
};

export default defaultLayouts;
