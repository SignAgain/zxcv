import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import { getToken } from '@cerdo/cerdo-utils/es/storage';
import layouts from 'layouts';

interface IWebSocketParams {
  auth?: boolean;
  [key: string]: any;
}

class InitWebSocket {
  wsTimer: any;
  wsReConnectTimer: any;
  ws?: WebSocket;
  websocketSend?: number;
  maxReconnectAttempts?: number = 5; // 最大重连次数
  currentReconnectAttempts?: number = 0; // 当前重连次数
  wsStatus?: 'close' | 'open' = 'close';

  /**
   * 初始化浏览器端 websocket
   */
  init = () => {
    if (!process.env.WEBSOCKET) {
      return;
    }

    // 如果重连次数超过最大重连次数，不进行自动重新连接
    if (this.currentReconnectAttempts > this.maxReconnectAttempts) {
      return;
    }

    // layouts 存在 websocket 配置时，使用 应用默认配置
    let url = layouts.ws?.path || this.makeURL();
    let params: IWebSocketParams = layouts.ws?.params;
    if (params?.auth) {
      const token = getToken();
      this.ws = new WebSocket(url, [token]);
    } else {
      this.ws = new WebSocket(url);
    }

    this.ws.onmessage = (response: any) => {
      const json = JSON.parse(response.data);

      console.info(`websocket:【 msgType:`, json.msgType, '】', json);

      /**
       * 推送 ack, 告诉服务端已收到推送？
       * 是否需要此功能?
       * 通过 layouts 配置，是否开启此功能
       */
      layouts.ws.ackSend && this.ws?.send(JSON.stringify({ msgType: 'ack', msgId: json?.msgId }));

      // 后端心跳检查
      if (json?.msgType === 'heartbeat') {
        const heartbeatMsg = JSON.stringify({
          msgType: 'heartbeat',
          timestamp: Number(new Date()),
        });
        this.ws?.send(heartbeatMsg);
        return;
      }

      // 发布消息
      eventCenter.publish(json.msgType, json);
      // 如果 layouts 存在 onPublish 执行回调函数，传入推送内容
      if (layouts.ws?.onPublish) {
        layouts.ws?.onPublish(json);
      }
    };

    this.ws.onopen = () => {
      this.setWsStatus('open');
      // 重连成功时也应该重置当前连接次数
      this.currentReconnectAttempts = 0;
      eventCenter.publish('websocket-status', { status: 'open' });
    };

    /**
     * socket 连接 error 或者 close 时都会执行
     * 重连方法应该在 onClose 里边执行
     * onError 方法先于 onClose 方法执行
     */
    this.ws.onclose = () => {
      // console.log('onclose')
      this.setWsStatus('close');
      eventCenter.publish('websocket-status', {
        status: 'close',
      });
      // 配置重连功能时，自动重连
      if (process.env.WEBSOCKET_AUTO_RECONNECT) {
        this.autoReconnect();
      }
    };

    this.ws.onerror = () => {
      // console.log('onerror')
    };
  };

  setWsStatus = (state: 'close' | 'open') => {
    this.wsStatus = state;
  };

  /**
   * 重新构建 ws url
   */
  makeURL = (): string => {
    // 如果是本地开发环境，默认返回开发环境 upm 连接地址
    if (process.env.NODE_ENV === 'development') {
      return 'wss://appdev.fsfund.com/cerdo/upm-api/upm/websocket';
    }

    const { host, protocol } = location;

    let wsUrl =
      protocol === 'http:'
        ? `ws://${host}/cerdo/upm-api/upm/websocket`
        : `wss://${host}/cerdo/upm-api/upm/websocket`;

    return wsUrl;
  };

  // 手动重连 websocket
  reconnect = () => {
    // 手动重连时应重新设置当前最大重连次数
    this.currentReconnectAttempts = 0;
    this.init();
  };

  /**
   * 监听 WebSocket 发送消息
   */
  subscribeWs = () => {
    this.websocketSend = this.subscribe('websocket-send', (type: string, data: any) => {
      if (this.ws && this.wsStatus === 'open') {
        this.ws?.send(JSON.stringify(data));
      }
    });
  };

  subscribe = (type: string, fn: Function) => {
    return eventCenter.subscribe(type, fn);
  };

  // 取消所有订阅事件
  unsubscribeEvent = () => {
    if (!process.env.WEBSOCKET) {
      return;
    }
    this.unsubscribe(this.websocketSend);
  };

  // 取消订阅事件
  unsubscribe = (token: number) => {
    eventCenter.unsubscribe(token);
  };

  // 关闭 websocket
  closeWebsocket = () => {
    if (!process.env.WEBSOCKET) {
      return;
    }
    if (this.ws && this.wsStatus === 'open') {
      // 如果是手动断开的情况下，需要设置当前重连数超过最大重连数，避免自动重连
      this.currentReconnectAttempts = 6;
      this.ws.close();
    }
  };

  autoReconnect = () => {
    this.currentReconnectAttempts++;
    // 断开websocket连接3秒后自动重连
    this.wsReConnectTimer && clearTimeout(this.wsReConnectTimer);
    this.wsReConnectTimer = setTimeout(() => {
      this.init();
    }, 3000);
  };
}

const cerdoWS = window.cerdoWS ? window.cerdoWS : new InitWebSocket();

// window 上已经挂载 cerdoWS 不需要重复挂载
if (!window.cerdoWS) {
  window.cerdoWS = cerdoWS;
}

export default cerdoWS;
