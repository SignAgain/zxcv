import { setTheme, getTheme } from '@cerdo/cerdo-utils/es/storage';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import '@cerdo/cerdo-utils/es/registerPrototype';
import Sentry from '@cerdo/cerdo-utils/es/Sentry';
import type { ThemeType } from '../types/base';
import throttle from 'lodash/throttle';
import DBUtil from '@cerdo/cerdo-utils/es/DBUtil';

const { AgDBUtil } = DBUtil;

const isDev = process.env.NODE_ENV === 'development';

export default function () {
  // console.log(process.env.DEBUG_SENTRY, 'process.env.DEBUG_SENTRY');
  // 子应用不加载 优先级 1
  // 框架 Config 配置文件 DEBUG_SENTRY && 是开发环境 是否加载 优先级 2
  // dev开发环境不加载 优先级 3
  // 不是开发环境 默认加载日志上报功能
  !window.__POWERED_BY_QIANKUN__ && ((process.env.DEBUG_SENTRY && isDev) || !isDev) && Sentry();
  // Sentry();

  // 是否在frame嵌套
  window.isInIframe = window.self !== window.top;

  /**
   * 打开tab页
   * @param {object} { path } path-路由地址
   * */
  window.openTab = (data) => {
    // 判断是否是被嵌套，通知父页面调用
    if (window.isInIframe) {
      window.parent.openTab(data);
      return;
    }
    const { path } = data;
    window.appHistory.push(path);
  };

  /**
   * 关闭tab页
   * @param { object } { path, currentPath } path-关闭的路由地址;currentPath需要打开的路由地址
   * */
  window.closeTab = (data) => {
    // 判断是否是被嵌套，通知父页面调用
    if (window.isInIframe) {
      window.parent.closeTab(data);
      return;
    }
    eventCenter.publish('closeTab', data);
  };

  /**
   * 通知 主应用发送postMessage 事件
   * @param {*} type 事件类型
   * @param {*} data 传递数据
   */
  window.postMessageToParent = (type, data) => {
    window.parent.postMessage(
      {
        type,
        data,
      },
      '*',
    );
  };

  /**
   * 主应用 向所有iframe 发送postMessage 事件
   * @param {*} type 事件类型
   * @param {*} data 传递数据
   */
  window.postMessageApplyIframe = (type, data = {}) => {
    // 如果是子应用， 这里不获取子应用 iframe 发送事件，避免嵌套
    if (window.isInIframe) {
      return;
    }
    const isNoticeToIframe = type === 'noticeToIframe';
    if ((isNoticeToIframe && data._type === 'changeTheme') || type === 'changeTheme') {
      window.changeTheme(data.theme);
    }
    let iframe = Array.from(document.querySelectorAll('iframe'));
    // 判断 content 和 type 是否存在
    if (iframe && type) {
      iframe.forEach((iframeElement) => {
        iframeElement.contentWindow.postMessage(
          {
            type: isNoticeToIframe ? data._type : type,
            data,
          },
          '*',
        );
      });
    }
  };

  /**
   * 通知 主应用 向所有iframe 发送postMessage 事件
   * @param {*} type 事件类型
   * @param {*} data 传递数据
   */
  window.postMessageToIframe = (type, data = {}) => {
    // 判断是否是被嵌套，通知父页面调用
    if (window.isInIframe) {
      window.postMessageToParent('noticeToIframe', { ...data, _type: type });
      return;
    }
    // 如果是主应用 需要手动执行 事件中心推送
    if (type) eventCenter.publish(type, data);
    window.postMessageApplyIframe('noticeToIframe', { ...data, _type: type });
  };

  /**
   * 监听 message 事件
   */
  window.addEventListener(
    'message',
    (event: MessageEvent) => {
      const { data = {} } = event;
      const { type, data: receiveData } = data;
      // 接收到事件之后进行 eventCetner 推送
      if (type)
        eventCenter.publish(type === 'noticeToIframe' ? receiveData._type : type, receiveData);
      if (type && type === 'noticeToIframe') {
        window.postMessageApplyIframe(type, receiveData);
        // return;
      }
      if (type && type === 'changeTheme') {
        window.changeTheme(receiveData.theme || 'light');
      }
    },
    false,
  );

  /**
   * 切换主题 事件
   * @param {*} value 主题色
   */
  window.changeTheme = (value: ThemeType): void => {
    let currentTheme = getTheme();
    if (!value) {
      currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    } else {
      currentTheme = value;
    }
    console.log('changeTheme');
    setTheme(currentTheme);
    // eventCenter.publish('changeTheme', { theme: currentTheme });
  };

  /**
   * 发送 postMessage 事件
   * @param {*} type 事件类型
   * @param {*} data 传递数据
   */
  window.postMessageToCerdo = (type, data = {}) => {
    window.postMessage(
      {
        type,
        data,
      },
      '*',
    );
  };

  // 获取当前页面链接参数对象
  window.getUrlParams = (url) => {
    const searchUrl = decodeURI(url || location.href);
    const search = searchUrl.match(/\?.+/i);
    const params = new URLSearchParams(search ? search[0] : '');
    const result = {};
    params.forEach((value, key) => {
      result[key] = value;
    });
    return result;
  };

  const handleResize = throttle(() => {
    eventCenter.publish('resize');
  }, 100);

  window.addEventListener('resize', handleResize);

  // 初始化AgGrid的indexDB
  AgDBUtil.init();
}
