import React from 'react';
import { Router, Route } from 'react-router-dom';
import { CacheSwitch } from 'react-router-cache-route';
import { createHashHistory } from 'history';
import UpmLogin from '../pages/UpmLogin';
import NotFound from '@cerdo/cerdo-design/es/pages/NotFound';
import { getTheme, getToken, setTheme, setToken, getUserInfo } from '@cerdo/cerdo-utils/es/storage';
import initGlobal from './initGlobal';
import { setLoginInfoByToken } from '@cerdo/cerdo-utils/es/auth';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import proxyWindow from '@cerdo/cerdo-utils/es/proxyWindow';
import getAllAppInfos from '@cerdo/cerdo-utils/es/getAllAppInfos';
import { funcUrlDel } from '@cerdo/cerdo-utils/es/url';
import { menuClick } from '@cerdo/cerdo-utils/es/api';
import '@cerdo/cerdo-design/es/styles/index.less';
import '@cerdo/cerdo-scaffold/es/styles/index.less';
import '@/styles/index.less';
import ErrorBoundary from '@cerdo/cerdo-design/es/layout/ErrorBoundary';
import AppRoute from './App';
import CounselPanel from '../layout/CounselPanel';
import withGlobalEvents from '../layout/withGlobalEvents';
import ThemeProvider from '../context/ThemeContext';

// const history = createBrowserHistory();
window.appHistory = createHashHistory();

// 特殊静态路由不收集菜单统计
const staticRoute = ['', '/', '/app', '/404', '/Permission', '/app/404', '/app/Permission'];

export interface RouteComponentProps {
  singleComponent?: React.ReactNode;
  [key: string]: any;
}

class RouteComponent extends React.Component<RouteComponentProps> {
  private token: string = undefined;

  constructor(props: RouteComponentProps) {
    super(props);
    // 初始化全局事件
    initGlobal();
    // 主应用加载微应用时，需要对子应用的属性进行隔离，防止变量污染
    proxyWindow['env'] = process.env;
    if (getTheme() || process.env.DEFAULT_THEME) {
      setTheme(getTheme() || process.env.DEFAULT_THEME);
    }

    const urlParams = window.getUrlParams();
    if (urlParams.token) {
      // 删除url参数 token 、sessionid
      let urlStr = funcUrlDel(location.href, 'sessionid');
      urlStr = funcUrlDel(urlStr, 'token');
      // location.href 重写，避免用户复制url链接携带用户信息
      location.href = urlStr;
      const token = getToken();
      const user = getUserInfo();
      // token做免登录
      setToken(urlParams.token);
      if (token !== urlParams.token || !user) {
        // 避免重复调用
        setLoginInfoByToken(urlParams.token);
      }
    } else {
      // 不需要对 href 重写的时候，需要手动进行菜单统计
      const hash = this.handleHashRewrite();
      this.statisticsMenu(hash);
    }
  }

  componentDidMount() {
    this.token = eventCenter.subscribe('getToken', getAllAppInfos);
    window.addEventListener('hashchange', () => {
      const hash = this.handleHashRewrite();
      eventCenter.publish('hashChange', { hash });
      this.statisticsMenu(hash);
    });
  }

  // 改变 hash
  // 1. 替换 hash 里边的 #
  // 2. 如果是流程组件页面 在审核过程中需要 替换 audit ，避免 调用接口 查不到对应的 menuName
  handleHashRewrite = () => {
    // 替换掉 hash 的 #
    let hash = location.hash.replace('#', '');
    if (hash.includes('/bpm/process') || hash.includes('/process/open')) {
      hash = hash.replace('/audit', '');
    }
    return hash;
  };

  componentWillUnmount() {
    if (this.token) {
      eventCenter.unsubscribe(this.token);
    }
  }

  // 统计页面路由变化
  statisticsMenu = (route: string) => {
    // 截取掉 search 参数
    if (route && route.indexOf('?') >= 0) {
      route = route.split('?')[0];
    }
    // route 特殊静态路由时 不统计菜单信息
    if (staticRoute.some((routeItem) => routeItem === route)) {
      return;
    }
    menuClick({ path: route });
  };

  render() {
    const { singleComponent, ...otherProps } = this.props;
    return (
      <ThemeProvider>
        <Router history={window.appHistory}>
          <ErrorBoundary>
            <CacheSwitch>
              {/* <Route path="/" exact render={() => <Redirect to="/app" />} /> */}
              <Route path="/login" key="/login" component={UpmLogin} />
              {singleComponent}
              <Route path="/" key="/appRoute" render={() => <AppRoute {...otherProps} />} />
              <Route component={NotFound} />
            </CacheSwitch>
          </ErrorBoundary>
        </Router>
        <CounselPanel />
      </ThemeProvider>
    );
  }
}

const RouteComponentWithGlobalEvents = withGlobalEvents(RouteComponent);

export default RouteComponentWithGlobalEvents;
