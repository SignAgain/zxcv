import { loadMicroApp, addGlobalUncaughtErrorHandler } from 'qiankun';
import { getItem } from '@cerdo/cerdo-utils/es/storage';

class SingleSpaStore {
  public loadedMicroApps = []; // 已加载 微应用
  private activeApp = {}; // 正在激活的 微应用

  addErrorHandler(): void {
    // 捕获微应用加载异常错误提示
    // qiankunjs 没有指出 Event 类型
    addGlobalUncaughtErrorHandler((event: any) => {
        const { reason: { message = '' } = {} } = event;
        if (message?.includes("Failed to fetch")) {
          console.error("微应用加载失败，请检查应用是否可运行");
          // event.preventDefault();
        }
     });
  }

  checkPath(path: string) {
    let outPath = path;
    if(path.indexOf('?') > 0) {
      outPath = path.split('?')[0];
    }
    return outPath;
  }

  isMicroApp (path: string): boolean {
    const microAppList = getItem('appInfos') || [];
    path = this.checkPath(path);
    return !!microAppList.some(item => {
        if (Array.isArray(item.activeRule)) {
          return !!item.activeRule.some(ruleItem => {
            return path === ruleItem;
          })
        }
        return path === item.activeRule;
    })
  }

  createMicroApp(path: string) {
    return new Promise((resolve, reject) => {
        if (!this.isMicroApp(path)) {
            // 非微应用直接跳转
            resolve(null);
            return
        }
  
        // 微应用跳转处理
        /**
         * @description 1.判断是否已手动加载，是则直接跳转，否则先手动挂载，再跳转
         */
        const microAppResult = this.findMicroAppByPath(path) // 是否是微应用的跳转
        if (Object.prototype.hasOwnProperty.call(this.loadedMicroApps, microAppResult.name)) {
            this.setActiveApp(microAppResult);
            resolve(null)
            return
        }
        try {
            // tips: iconsfont 字体不使用fetch方式获取
            loadMicroApp(microAppResult, {
              excludeAssetFilter: (str: string) => {
                return str.includes('iconfont.js');
              }
            }); // 加载微应用
            this.loadedMicroApps[microAppResult.name] = microAppResult;
            this.setActiveApp(microAppResult);
            console.log('挂载后的已挂载的微应用==>', this.loadedMicroApps)
            resolve(null)
        } catch (err) {
            reject(err)
        }
    })
  }

  setActiveApp(app: Object): void {
    this.activeApp = { ...app };
  }

  findMicroAppByPath(path: string) {
    path = this.checkPath(path);
    const microAppList = this.getAppInfos();
    return microAppList.find(item => {
        let activeRule = item.activeRule;
        if (Array.isArray(activeRule)) {
          return !!activeRule.some(ruleItem => {
            return path === ruleItem
          })
        }
        return path === activeRule
    })
  }

  getLoadedApps() {
    return this.loadedMicroApps;
  }

  getActiveApps() {
    return this.activeApp;
  }

  getAppInfos() {
    return getItem('appInfos') || [];
  }

  getAppInfo() {

  }
}

export default SingleSpaStore;
