import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { CacheSwitch } from 'react-router-cache-route';
import LayoutComponent from '../layout/LayoutComponent';
import SingleLayoutComponent from '../layout/SingleLayoutComponent';
import { verifyLogin } from '@cerdo/cerdo-utils/es/auth';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import SingleSpaStore from './singleSpa';
import getMicroApps from '@cerdo/cerdo-utils/es/getMicroApps';
import NotFound from '@cerdo/cerdo-design/es/pages/NotFound';
import NoPermission from '@cerdo/cerdo-design/es/pages/NoPermission';
import { LicenseManager } from 'ag-grid-enterprise';
import cerdoWS from '../__utils/InitWebSocket';

export interface AppRouteProps {
  layoutProps?: Object;
  style?: React.CSSProperties;
  className?: string;
  [key: string]: any;
}

interface AppRouteState {
  menus?: any[];
  appInfos?: any[];
  loading?: boolean;
  [key: string]: any;
}

// 项目初始化之前设置ag-grid的license
LicenseManager.setLicenseKey(
  'Using_this_AG_Grid_Enterprise_key_( AG-043553 )_in_excess_of_the_licence_granted_is_not_permitted___Please_report_misuse_to_( legal@ag-grid.com )___For_help_with_changing_this_key_please_contact_( info@ag-grid.com )___( fsfund )_is_granted_a_( Multiple Applications )_Developer_License_for_( 1 ))_Front-End_JavaScript_developer___All_Front-End_JavaScript_developers_need_to_be_licensed_in_addition_to_the_ones_working_with_AG_Grid_Enterprise___This_key_has_not_been_granted_a_Deployment_License_Add-on___This_key_works_with_AG_Grid_Enterprise_versions_released_before_( 12 June 2024 )____[v2]_MTcxODE0NjgwMDAwMA==0b59f3406839d58b88f5c28d1947b2f9',
);

class AppRoute extends React.PureComponent<AppRouteProps, AppRouteState> {
  constructor(props) {
    super(props);

    this.state = {
      menus: [],
      appInfos: [],
      loading: true,
    };
  }

  componentDidMount() {
    verifyLogin(async (state) => {
      // 认证成功之后调用微应用接口
      this.init();
      const data = await this.getMicroApps();
      this.setState({ ...state, appInfos: data, loading: false });
    });
  }

  /**
   * 用户信息认证成功之后，进行初始化
   */
  init = () => {
    // 开启 框架 内置 websocket 配置
    if (process.env.WEBSOCKET) {
      cerdoWS.init();
      cerdoWS.subscribeWs();
    }
  }

  getMicroApps = async () => {
    let data = [];
    if (process.env.IS_MAIN) {
      // 缓存微应用信息
      const cerdoGlobalState = new SingleSpaStore();
      // 捕获微应用加载错误信息
      cerdoGlobalState.addErrorHandler();
      window.cerdoGlobalState = cerdoGlobalState;
      // window.cerdoEventCenter = eventCenter;

      data = await getMicroApps();
      // 如果是主应用，请求接口成功之后 监听路由变化，注册微应用
      eventCenter.subscribe('hashChange', () => {
        cerdoGlobalState.createMicroApp(location.hash);
      });
    }
    return Array.isArray(data) ? data : [];
  };

  render() {
    const {
      children,
      layoutProps,
      // singleComponent,
      style = {},
      className = '',
    } = this.props;
    const { menus, appInfos, loading } = this.state;
    return (
      <CacheSwitch>
        {!loading && (
          <React.Fragment>
            <Route
              path="/"
              exact
              render={() => <Redirect to={process.env.DEFAULT_PAGE || '/app'} />}
            />
            <Route path="/404" key="/404" component={NotFound} />
            <Route path="/permission" key="/permission" component={NoPermission} />
            {/* 通过不同配置渲染不同 layout  */}
            {window.__POWERED_BY_QIANKUN__ ? (
              <Route
                path="/app"
                key="/app"
                render={() => (
                  <SingleLayoutComponent
                    style={style}
                    className={className}
                    menus={menus}
                    {...layoutProps}
                  >
                    {children}
                  </SingleLayoutComponent>
                )}
              />
            ) : (
              <Route
                path="/app"
                key="/app"
                render={(props) => (
                  <LayoutComponent
                    menus={menus}
                    {...props}
                    style={style}
                    className={className}
                    appInfos={appInfos}
                    {...layoutProps}
                  >
                    {children}
                  </LayoutComponent>
                )}
              />
            )}
            <Route
              path="/single/app"
              key="/single/app"
              render={() => (
                <SingleLayoutComponent
                  preKeyUrl="/single"
                  style={style}
                  className={className}
                  menus={menus}
                  {...layoutProps}
                >
                  {children}
                </SingleLayoutComponent>
              )}
            />
          </React.Fragment>
        )}
      </CacheSwitch>
    );
  }
}

export default AppRoute;
