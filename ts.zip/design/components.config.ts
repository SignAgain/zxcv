module.exports = [
  // /** antd component */
  ['LayoutComponent', '/layout/LayoutComponent'],
  ['SingleLayoutComponent', '/layout/SingleLayoutComponent'],
  ['HeaderCustom', '/header/HeaderCustom'],
  ['HeaderMenu', '/header/HeaderMenu'],
  ['SilderCustom', '/silder/SilderCustom'],
  ['RouteComponent', '/router/RouteComponent'],
  ['UpmLogin', '/pages/UpmLogin'],
  ['FormDesigner', '/FormDesigner/index'],
];
