// /** antd component */
export { default as LayoutComponent } from './layout/LayoutComponent';
export { default as SingleLayoutComponent } from './layout/SingleLayoutComponent';
export { default as HeaderCustom } from './header/HeaderCustom';
export { default as HeaderMenu } from './header/HeaderMenu';
export { default as SilderCustom } from './silder/SilderCustom';
export { default as RouteComponent } from './router/RouteComponent';
export { default as UpmLogin } from './pages/UpmLogin';
export { default as FormDesigner } from './FormDesigner';
