import React, { Component, MouseEventHandler } from 'react';
import { Layout, Menu } from 'antd';
import { withRouter } from 'react-router-dom';
import { isFunction } from 'lodash';
import { MenuUnfoldOutlined, MenuFoldOutlined } from '@ant-design/icons';
import SiderMenu from './SilderMenu';
import eventCenter from '@cerdo/cerdo-utils/es/eventCenter';
import { menuClick } from '@cerdo/cerdo-utils/es/api';
import find from 'lodash/find';
import layouts from 'layouts';
import Avatar from '../header/Avatar';
import WebSocket from '../header/Websocket';
import ChangeUser from '../header/ChangeUser';
import { type LayoutType } from '../layout/LayoutComponent';

const { Sider } = Layout;

// const {
//     selectedKey,
//     collapsed,
//     collapsedToggle,
//     topMenu
// } = this.state;

// const {
//     menus,
//     history: { location },
// } = this.props;

export interface ISiderCustomPorps<menuDataType = any> {
  popoverHide?: () => any;
  flattenMenus?: menuDataType[];
  menus?: menuDataType[];
  parentTreeId?: string | number;
  [key: string]: any;
  layout: LayoutType;
}

export interface ISiderCustomState {
  selectedKey?: string | number | null;
  collapsed?: boolean;
  collapsedToggle?: boolean;
  topMenu?: boolean;
  openKeys?: string[] | number[];
}

class SiderCustom extends Component<ISiderCustomPorps, ISiderCustomState> {
  token: number;
  collapsedToggleToken: number;
  tabCloseToken: number;
  toggle: MouseEventHandler<HTMLSpanElement>;

  constructor(props) {
    super(props);
    this.state = {
      collapsed: layouts.silde.menu.collapsed || props.layout === 'avatar',
      selectedKey: '',
      openKeys: [],
      collapsedToggle: !layouts.silde.menu.togglehidden || false,
      topMenu: layouts.main.topMenu,
    };
  }

  componentDidMount() {
    // const curPage = getSessionItem('curPage');
    // if (curPage) {
    //     this.setState({
    //         selectedKey: curPage,
    //     })
    // }
    this.token = eventCenter.subscribe('tabsChange', (type, data) => {
      // key: activeKey
      this.setState({
        selectedKey: data.key,
      });
    });

    // 菜单收缩事件
    this.collapsedToggleToken = eventCenter.subscribe('collapsedToggle', (type, data) => {
      this.setState({
        collapsed: !!data.collapsed,
      });
    });

    this.tabCloseToken = eventCenter.subscribe('tabClose', (type, data) => {
      this.setState({
        selectedKey: null,
      });
    });
  }

  componentDidUpdate(prevProps) {
    const { layout } = this.props;
    if (prevProps.layout !== layout && layout === 'avatar') {
      this.handleCollapsedChange(true);
    }
  }

  componentWillUnmount() {
    eventCenter.unsubscribe(this.token);
    eventCenter.unsubscribe(this.tabCloseToken);
    eventCenter.unsubscribe(this.collapsedToggleToken);
  }

  openMenu = (openKeys) => {};

  menuClick = (e) => {
    const { targettype, item = {} } = e.item.props;
    // 事件中心增加菜单点击事件
    eventCenter.publish('menuClick', { ...item });
    // tips: 对当前 menuItem 做 target 做判断，如果是跳转链接 不设置 selectKey
    if (targettype === '_blank') {
      // 菜单 路由地址为 http 开始，认为是 第三方外部系统
      if (item?.perLink?.startsWith('http')) {
        menuClick({
          path: item.perLink,
          title: item.perName,
        });
      }
      return;
    }
    this.setState({
      selectedKey: e.key,
    });
    const { popoverHide } = this.props; // 响应式布局控制小屏幕点击菜单时隐藏菜单操作
    if (isFunction(popoverHide)) popoverHide();
  };

  getOpenKeys = (pathname) => {
    const { flattenMenus } = this.props;
    const meunsValue = find(flattenMenus, (item) => {
      return item.perLink === pathname || item.id === pathname;
    });
    if (meunsValue) {
      return meunsValue.idPath.split('/');
    }
    return [];
  };

  getSelectedKey = (pathname) => {
    const { flattenMenus } = this.props;
    const meunsValue = find(flattenMenus, (item) => {
      return item.perLink === pathname || item.id === pathname;
    });
    if (meunsValue) {
      return [meunsValue.id];
    }
    return [];
  };

  handleCollapsedChange = (collapsed) => {
    eventCenter.publish('collapsedToggle', {
      collapsed,
    });
  };

  // meuns菜单数据过滤 只展示顶级菜单数据 菜单进行过滤 只展示levelNum = 2 第 1 个系统级菜单,
  // 不存在 levelNum = 2 的菜单数据时  直接返回 menus
  handleReRenderMenus = () => {
    const { menus, parentTreeId } = this.props;
    let reMenusList = [];
    reMenusList = menus.filter((item) => {
      return item.id === parentTreeId && item.levelNum === 2;
    });
    return reMenusList.length ? reMenusList[0]?.children || [] : menus;
  };

  // onCollapsedChange={(collapsed) => this.setState({ collapsed })} collapsed={collapsed}

  render() {
    const { selectedKey, collapsed, collapsedToggle, topMenu } = this.state;

    const {
      menus,
      history: { location },
      layout,
      onThemeChange,
    } = this.props;

    const openKeys = collapsed ? [] : this.getOpenKeys(location.pathname);
    const avatar = layout === 'avatar';

    return (
      <Sider
        trigger={
          collapsedToggle
            ? React.createElement(collapsed ? MenuUnfoldOutlined : MenuFoldOutlined, {
                className: 'menu-trigger',
                style: { paddingTop: 4, marginLeft: '-10px' },
                onClick: this.toggle,
              })
            : null
        }
        className="cerdo-layout-sider"
        style={{ paddingBottom: avatar ? 10 : 35 }}
        collapsible={!avatar}
        collapsed={collapsed}
        collapsedWidth={85}
        onCollapse={this.handleCollapsedChange}
        width={214}
      >
        {avatar && (
          <>
            <Menu
              mode="horizontal"
              // theme="dark"
              style={{
                display: 'flex',
                justifyContent: 'center',
                padding: '12px 0',
                background: 'transparent',
                border: 'none',
              }}
            >
              <Avatar layout={layout} handleThemeClick={onThemeChange} />
            </Menu>
            <ChangeUser />
            <WebSocket />
          </>
        )}
        <div key="SiderMenu" style={{ flex: 1, overflow: 'auto' }}>
          <SiderMenu
            style={{
              overflow: 'hidden auto',
              height: '100%',
              background: 'transparent',
              border: 'none',
            }}
            menus={topMenu ? this.handleReRenderMenus() : menus}
            onClick={this.menuClick}
            mode="inline"
            openKeys={openKeys}
            selectedKeys={this.getSelectedKey(selectedKey || location.pathname)}
            defaultOpenKeys={openKeys}
            onOpenChange={this.openMenu}
          />
        </div>
      </Sider>
    );
  }
}

export default withRouter(SiderCustom);
