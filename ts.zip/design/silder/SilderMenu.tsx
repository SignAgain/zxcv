import React, { Component } from 'react';
import { Menu } from 'antd';
import type { MenuProps } from 'antd/es/menu';
import { Link, withRouter } from 'react-router-dom';
import { isArray } from 'lodash';
import { FileTextOutlined } from '@ant-design/icons';
import layouts from 'layouts';
import Icon from '@cerdo/cerdo-design/es/icon/Icon';

export interface ISilderMenuProps<menuType = any>
  extends Pick<
    MenuProps,
    'defaultOpenKeys' | 'style' | 'onClick' | 'mode' | 'selectedKeys' | 'onOpenChange'
  > {
  menus?: menuType[];
  openKeys?: string | string[];
}

// @ts-ignore
@withRouter
class SilderMenu extends Component<ISilderMenuProps> {
  loadRoute = (e, menuItem) => {
    // 菜单点击 或者 外链跳转前做控制
    if (!layouts.silde.menu.loadRoute(menuItem)) {
      e.preventDefault();
      return false;
    }
    return true;
  };

  renderMenuItem = (item) =>
    isArray(item.children) &&
    // isRouter = 0 是正常菜单  1 是隐藏菜单 isRoute 有可能为 null 判断条件改为 ！== ”1“
    item.children.filter((a) => a.isRouter !== '1').length > 0
      ? this.renderSubMenu(item)
      : // isRouter = 0 不展示 menuitem
        item.isRouter !== '1' && (
          <Menu.Item key={item.id} title="">
            {/* item={item}  targettype={item.target} */}
            {item.target === '_blank' ? (
              <a
                onClick={(e) => {
                  this.loadRoute(e, item);
                }}
                title={item.perName}
                href={item.perLink?.startsWith('http') ? item.perLink : item.baseUrl + item.perLink}
                target={item.target}
              >
                {item.menuIcon ? (
                  <Icon type={item.menuIcon} />
                ) : (
                  Number(item.levelNum) <= 3 && <FileTextOutlined />
                )}
                <span className="nav-text">{item.perName}</span>
              </a>
            ) : (
              item.compName && (
                <Link
                  onClick={(e) => {
                    this.loadRoute(e, item);
                  }}
                  title={item.perName}
                  to={{ pathname: item.perLink }}
                >
                  {item.menuIcon ? (
                    <Icon type={item.menuIcon} />
                  ) : (
                    Number(item.levelNum) <= 3 && <FileTextOutlined />
                  )}
                  <span className="nav-text">{item.perName}</span>
                </Link>
              )
            )}
          </Menu.Item>
        );

  renderSubMenu = (item) => (
    <Menu.SubMenu
      // 使用id作为唯一key  targettype属性用来判断是否是跳转链接
      key={item.id}
      // targettype={item.target}
      title={
        item.perLink && item.compName ? (
          item.target === '_blank' ? (
            <a
              onClick={(e) => {
                this.loadRoute(e, item);
              }}
              title={item.perName}
              href={item.perLink?.startsWith('http') ? item.perLink : item.baseUrl + item.perLink}
              target={item.target}
            >
              {item.menuIcon ? (
                <Icon type={item.menuIcon} />
              ) : (
                Number(item.levelNum) <= 3 && <FileTextOutlined />
              )}
              <span className="nav-text">{item.perName}</span>
            </a>
          ) : (
            <div title={item.perName}>
              {item.menuIcon ? (
                <Icon type={item.menuIcon} />
              ) : (
                Number(item.levelNum) <= 3 && <FileTextOutlined />
              )}
              <span className="nav-text">{item.perName}</span>
            </div>
            // {/* <Link to={{ pathname: item.perLink }}>
            //     {
            //         item.menuIcon
            //             ? <Icon type={item.menuIcon} />
            //             : Number(item.levelNum) <= 3 && <FileTextOutlined />
            //     }
            //     <span className="nav-text">{`3${item.perName}`}</span>
            // </Link> */}
          )
        ) : (
          <div title={item.perName}>
            {item.menuIcon ? (
              <Icon type={item.menuIcon} />
            ) : (
              Number(item.levelNum) <= 3 && <FileTextOutlined />
            )}
            <span className="nav-text">{item.perName}</span>
          </div>
        )
      }
    >
      {item.children.filter((a) => a.isRouter !== '1').map((b) => this.renderMenuItem(b))}
    </Menu.SubMenu>
  );

  render() {
    const { defaultOpenKeys, style, onClick, mode, selectedKeys, onOpenChange, menus } = this.props;
    return (
      <Menu
        // key={defaultOpenKeys.length > 0}
        className="cerdo-layout-sildermenu"
        style={style}
        onClick={onClick}
        mode={mode}
        // theme="dark"
        inlineIndent={24}
        selectedKeys={selectedKeys}
        defaultOpenKeys={defaultOpenKeys}
        onOpenChange={onOpenChange}
      >
        {isArray(menus) &&
          menus.map((item) =>
            isArray(item.children) && item.children.filter((a) => a.isRouter !== '1').length > 0
              ? this.renderSubMenu(item)
              : this.renderMenuItem(item),
          )}
      </Menu>
    );
  }
}

export default SilderMenu;
