import { ISchema } from '@formily/react';

export const ArrayTabs: ISchema = {
  type: 'object',
  properties: {
    addCopy: {
      type: 'boolean',
      'x-decorator': 'FormItem',
      'x-component': 'Switch',
      'x-component-props': {
        defaultChecked: true,
      },
    },
    filtterCopy: {
      type: 'string',
      'x-component': 'ValueInput',
      'x-decorator': 'FormItem',
      'x-component-props': {
        include: ['EXPRESSION'],
      },
    },
    animated: {
      type: 'boolean',
      'x-decorator': 'FormItem',
      'x-component': 'Switch',
    },
    centered: {
      type: 'boolean',
      'x-decorator': 'FormItem',
      'x-component': 'Switch',
    },
    size: {
      type: 'string',
      enum: ['large', 'small', 'default', null],
      'x-decorator': 'FormItem',
      'x-component': 'Select',
      'x-component-props': {
        defaultValue: 'default',
      },
    },
  },
};
