import { ISchema } from '@formily/react';

export const FormDictCheckbox: ISchema & { Group?: ISchema } = {
  type: 'object',
  properties: {
    dictid: {
      type: 'string',
      'x-component': 'Input',
      'x-decorator': 'FormItem',
    },
  },
};
