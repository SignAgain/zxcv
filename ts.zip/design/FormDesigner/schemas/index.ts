import { ArrayTabs } from './ArrayTabs';
import { FormDictSelect } from './FormDictSelect';
import { FormDictCheckbox } from './FormDictCheckbox';
import { FormUploadFile } from './FormUploadFile';
import { FormDictCascader } from './FormDictCascader';
import { FormDictTreeSelect } from './FormDictTreeSelect';
import { Text } from './Text';

export default {
  FormDictSelect,
  ArrayTabs,
  FormDictCheckbox,
  FormUploadFile,
  FormDictCascader,
  FormDictTreeSelect,
  Text,
};
