export const FormDictCheckbox = {
  'zh-CN': {
    title: '字典复选框组',
    settings: {
      'x-component-props': {
        dictid: {
          title: '数据字典id',
        },
      },
    },
  },
  'en-US': {
    title: 'FormDictCheckbox',
    settings: {
      'x-component-props': {
        dictid: {
          title: 'Dict Id',
        },
      },
    },
  },
};
