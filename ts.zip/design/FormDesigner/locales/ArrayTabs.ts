export const ArrayTabs = {
  'zh-CN': {
    title: '自增Tabs',
    settings: {
      'x-component-props': {
        addCopy: '是否开启添加复制',
        filtterCopy: '添加复制过滤函数',
        animated: '启用动画过渡',
        centered: '标签居中',
        tab: '选项名称',
      },
    },
  },
  'en-US': {
    title: 'Array Tabs',
    settings: {
      'x-component-props': {
        animated: 'Enable Animated',
        centered: 'Label Centered',
        tab: 'Tab Title',
      },
    },
  },
};
