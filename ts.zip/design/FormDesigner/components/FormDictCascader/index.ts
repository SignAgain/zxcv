import React from 'react';
import { FormDictCascader as DictCascader } from '@cerdo/cerdo-design/es/formily/FormDictCascader';
import type IDictCascaderPlus from '@cerdo/cerdo-design/es/FormDictCascader';
import { createBehavior, createResource } from '@designable/core';
import { DnFC } from '@designable/react';
import AllSchemas from '../../schemas';
import AllLocales from '../../locales';
import { createFieldSchema } from '@designable/formily-antd';
import type { ISchema } from '@formily/json-schema';

export const FormDictCascader: DnFC<React.ComponentProps<typeof IDictCascaderPlus>> = DictCascader;

FormDictCascader.Behavior = createBehavior({
  name: 'FormDictCascader',
  extends: ['Field'],
  selector: (node) => node.props['x-component'] === 'FormDictCascader',
  designerProps: {
    propsSchema: createFieldSchema(AllSchemas.FormDictCascader as ISchema),
  },
  designerLocales: AllLocales.FormDictCascader,
});

FormDictCascader.Resource = createResource({
  icon: 'CascaderSource',
  elements: [
    {
      componentName: 'Field',
      props: {
        title: 'FormDictCascader',
        'x-decorator': 'FormItem',
        'x-component': 'FormDictCascader',
      },
    },
  ],
});
