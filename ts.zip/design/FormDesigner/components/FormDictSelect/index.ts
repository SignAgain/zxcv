import { FormDictSelect as DictSelect } from '@cerdo/cerdo-design/es/formily/FormDictSelect';
import { createBehavior, createResource } from '@designable/core';
import { DnFC } from '@designable/react';
import AllSchemas from '../../schemas';
import AllLocales from '../../locales';
import { createFieldSchema } from '@designable/formily-antd';
import type { ISchema } from '@formily/json-schema';

export const FormDictSelect: DnFC = DictSelect;

FormDictSelect.Behavior = createBehavior({
  name: 'FormDictSelect',
  extends: ['Field'],
  selector: (node) => node.props['x-component'] === 'FormDictSelect',
  designerProps: {
    propsSchema: createFieldSchema(AllSchemas.FormDictSelect as ISchema),
  },
  designerLocales: AllLocales.FormDictSelect,
});

FormDictSelect.Resource = createResource({
  icon: 'SelectSource',
  elements: [
    {
      componentName: 'Field',
      props: {
        title: 'FormDictSelect',
        'x-decorator': 'FormItem',
        'x-component': 'FormDictSelect',
      },
    },
  ],
});
