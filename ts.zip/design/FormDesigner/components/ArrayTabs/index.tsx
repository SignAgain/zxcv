import React from 'react';
import { TreeNode, createBehavior, createResource } from '@designable/core';
import { useDropTemplate } from '@designable/formily-antd/esm/hooks';
import AllSchemas from '../../schemas';
import AllLocales from '../../locales';
import { createFieldSchema } from '@designable/formily-antd';
import type TabsProps from 'antd/lib/tabs';
import {
  useTreeNode,
  TreeNodeWidget,
  DroppableWidget,
  useNodeIdProps,
  DnFC,
} from '@designable/react';
import { observer } from '@formily/react';
import { Tabs } from 'antd';
import {
  queryNodesByComponentPath,
  createEnsureTypeItemsNode,
  createNodeId,
} from '@designable/formily-antd/esm/shared';
import type { ISchema } from '@formily/json-schema';

const ensureObjectItemsNode = createEnsureTypeItemsNode('object');

export const ArrayTabs: DnFC<React.ComponentProps<typeof TabsProps>> = observer((props) => {
  const node = useTreeNode();
  const nodeId = useNodeIdProps();

  const designer = useDropTemplate('ArrayTabs', (source) => {
    const objectNode = new TreeNode({
      componentName: node.componentName,
      props: {
        type: 'object',
      },
      children: [...source],
    });
    return [objectNode];
  });

  if (node.children.length === 0) {
    return <DroppableWidget />;
  }

  const dataSource = [{ label: 'Tab1', key: '1' }];

  const children = queryNodesByComponentPath(node, [
    'ArrayTabs',
    '*',
    (name) => name.indexOf('ArrayTabs.') === -1,
  ]);

  return (
    <div {...nodeId} className="dn-array-tabs">
      <Tabs {...props} type="editable-card">
        {dataSource?.map((item, index) => {
          const key = `tab-${index}`;
          return (
            <Tabs.TabPane
              key={key}
              forceRender
              closable={index !== 0}
              // tab={<FeedbackBadge index={index} />}
              tab={item.label}
            >
              <div {...createNodeId(designer, ensureObjectItemsNode(node).id)}>
                {children.length ? (
                  children.map((node) => <TreeNodeWidget key={node.id} node={node} />)
                ) : (
                  <DroppableWidget hasChildren={false} />
                )}
              </div>
            </Tabs.TabPane>
          );
        })}
      </Tabs>
    </div>
  );
});

ArrayTabs.Behavior = createBehavior({
  name: 'ArrayTabs',
  extends: ['Field'],
  selector: (node) => node.props['x-component'] === 'ArrayTabs',
  designerProps: {
    propsSchema: createFieldSchema(AllSchemas.ArrayTabs as ISchema),
    droppable: true,
  },
  designerLocales: AllLocales.ArrayTabs,
});

ArrayTabs.Resource = createResource({
  icon: 'TabSource',
  elements: [
    {
      componentName: 'Field',
      props: {
        type: 'array',
        'x-decorator': 'FormItem',
        'x-component': 'ArrayTabs',
        'x-component-props': {},
      },
    },
  ],
});
