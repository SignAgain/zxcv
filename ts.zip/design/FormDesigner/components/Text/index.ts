import { createBehavior, createResource } from '@designable/core';
import { DnFC } from '@designable/react';
import { createVoidFieldSchema } from '@designable/formily-antd';
import AllSchemas from '../../schemas';
import AllLocales from '../../locales';
import { Text as FormText } from '@designable/formily-antd';
import type { ISchema } from '@formily/json-schema';

export const Text: DnFC = FormText;

Text.Behavior = createBehavior({
  name: 'Text',
  extends: ['Field'],
  selector: (node) => node.props['x-component'] === 'Text',
  designerProps: {
    propsSchema: createVoidFieldSchema(AllSchemas.Text as ISchema),
  },
  designerLocales: AllLocales.Text,
});

Text.Resource = createResource({
  icon: 'TextSource',
  elements: [
    {
      componentName: 'Field',
      props: {
        type: 'string',
        'x-component': 'Text',
      },
    },
  ],
});
