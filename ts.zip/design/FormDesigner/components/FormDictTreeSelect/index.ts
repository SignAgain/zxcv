import { FormDictTreeSelect as DictTreeSelect } from '@cerdo/cerdo-design/es/formily/FormDictTreeSelect';
import { createBehavior, createResource } from '@designable/core';
import { DnFC } from '@designable/react';
import AllSchemas from '../../schemas';
import AllLocales from '../../locales';
import { createFieldSchema } from '@designable/formily-antd';
import type { ISchema } from '@formily/json-schema';

export const FormDictTreeSelect: DnFC = DictTreeSelect;

FormDictTreeSelect.Behavior = createBehavior({
  name: 'FormDictTreeSelect',
  extends: ['Field'],
  selector: (node) => node.props['x-component'] === 'FormDictTreeSelect',
  designerProps: {
    propsSchema: createFieldSchema(AllSchemas.FormDictTreeSelect as ISchema),
  },
  designerLocales: AllLocales.FormDictTreeSelect,
});

FormDictTreeSelect.Resource = createResource({
  icon: 'TreeSelectSource',
  elements: [
    {
      componentName: 'Field',
      props: {
        title: 'FormDictTreeSelect',
        'x-decorator': 'FormItem',
        'x-component': 'FormDictTreeSelect',
      },
    },
  ],
});
