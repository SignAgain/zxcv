import { FormUploadFile as UploadFile } from '@cerdo/cerdo-design/es/formily/FormUploadFile';
import { createBehavior, createResource } from '@designable/core';
import { DnFC } from '@designable/react';
import { createFieldSchema } from '@designable/formily-antd';
import AllSchemas from '../../schemas';
import AllLocales from '../../locales';
import type { ISchema } from '@formily/json-schema';

export const FormUploadFile: DnFC = UploadFile;

FormUploadFile.Behavior = createBehavior({
  name: 'FormUploadFile',
  extends: ['Field'],
  selector: (node) => node.props['x-component'] === 'FormUploadFile',
  designerProps: {
    propsSchema: createFieldSchema(AllSchemas.FormUploadFile as ISchema),
  },
  designerLocales: AllLocales.FormUploadFile,
});

FormUploadFile.Resource = createResource({
  icon: 'UploadDraggerSource',
  elements: [
    {
      componentName: 'Field',
      props: {
        type: 'Array<string | number>',
        title: 'FormUploadFile',
        'x-decorator': 'FormItem',
        'x-component': 'FormUploadFile',
      },
    },
  ],
});
