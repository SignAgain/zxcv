import { FormDictCheckbox as Checkbox } from '@cerdo/cerdo-design/es/formily/FormDictCheckbox';
import { createBehavior, createResource } from '@designable/core';
import { DnFC } from '@designable/react';
import { createFieldSchema } from '@designable/formily-antd';
import AllSchemas from '../../schemas';
import AllLocales from '../../locales';
import type { ISchema } from '@formily/json-schema';

export const FormDictCheckbox: DnFC = Checkbox;

FormDictCheckbox.Behavior = createBehavior({
  name: 'FormDictCheckbox',
  extends: ['Field'],
  selector: (node) => node.props['x-component'] === 'FormDictCheckbox',
  designerProps: {
    propsSchema: createFieldSchema(AllSchemas.FormDictCheckbox as ISchema),
  },
  designerLocales: AllLocales.FormDictCheckbox,
});

FormDictCheckbox.Resource = createResource({
  icon: 'CheckboxGroupSource',
  elements: [
    {
      componentName: 'Field',
      props: {
        type: 'Array<string | number>',
        title: 'FormDictCheckbox',
        'x-decorator': 'FormItem',
        'x-component': 'FormDictCheckbox',
      },
    },
  ],
});
