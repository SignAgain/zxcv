import React, { useMemo } from 'react';
import { createForm } from '@formily/core';
import { TreeNode } from '@designable/core';
import type { ISchemaFieldReactFactoryOptions } from '@formily/react';
import { transformToSchema } from '@designable/formily-transformer';
import CerdoForm from '@cerdo/cerdo-design/es/CerdoForm';

export interface IPreviewWidgetProps {
  tree: TreeNode;
  createSchemaFieldOptions?: ISchemaFieldReactFactoryOptions;
}

export const PreviewWidget: React.FC<IPreviewWidgetProps> = (props) => {
  const form = useMemo(() => createForm(), []);
  const { form: formProps, schema } = transformToSchema(props.tree);
  return (
    <CerdoForm
      form={form}
      {...formProps}
      schema={schema}
      createSchemaFieldOptions={props.createSchemaFieldOptions}
    />
  );
};
