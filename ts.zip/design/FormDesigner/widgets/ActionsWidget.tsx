import React, { useEffect } from 'react';
import { Space, Button, Radio } from 'antd';
import { useDesigner, TextWidget } from '@designable/react';
import { GlobalRegistry } from '@designable/core';
import { observer } from '@formily/react';
import { loadInitialSchema as loadInit, saveSchema as save } from '../service';
import { isFunction } from 'lodash';
import { transformToSchema, transformToTreeNode } from '@designable/formily-transformer';

interface IActionsWidgetProps {
  saveSchema?: (string) => void;
  loadInitialSchema?: string;
}

export const ActionsWidget = observer((props: IActionsWidgetProps) => {
  const { loadInitialSchema, saveSchema } = props;
  const designer = useDesigner();
  useEffect(() => {
    if (loadInitialSchema) {
      designer.setCurrentTree(transformToTreeNode(JSON.parse(loadInitialSchema)));
    } else {
      loadInit(designer);
    }
  }, [loadInitialSchema]);
  const supportLocales = ['zh-cn', 'en-us', 'ko-kr'];
  useEffect(() => {
    if (!supportLocales.includes(GlobalRegistry.getDesignerLanguage())) {
      GlobalRegistry.setDesignerLanguage('zh-cn');
    }
  }, []);
  return (
    <Space style={{ marginRight: 10 }}>
      <Radio.Group
        value={GlobalRegistry.getDesignerLanguage()}
        optionType="button"
        options={[
          { label: 'English', value: 'en-us' },
          { label: '简体中文', value: 'zh-cn' },
        ]}
        onChange={(e) => {
          GlobalRegistry.setDesignerLanguage(e.target.value);
        }}
      />
      {/* <Button
        onClick={() => {
          // saveSchema(designer)
          if (isFunction(saveSchema)) {
            saveSchema(JSON.stringify(transformToSchema(designer.getCurrentTree())))
          }
        }}
      >
        <TextWidget>保存</TextWidget>
      </Button> */}
      <Button
        type="primary"
        onClick={() => {
          if (isFunction(saveSchema)) {
            saveSchema(JSON.stringify(transformToSchema(designer.getCurrentTree())));
          } else {
            save(designer);
          }
        }}
      >
        <TextWidget>保存</TextWidget>
      </Button>
    </Space>
  );
});
