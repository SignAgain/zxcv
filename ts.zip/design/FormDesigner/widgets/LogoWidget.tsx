import React from 'react';
import { useTheme } from '@designable/react';

const logo = {
  dark: 'https://app.fsfund.com/apps/app-web/common/images/logo-dark.png',
  light: 'https://app.fsfund.com/apps/app-web/common/images/logo-light.png',
};

export const LogoWidget: React.FC = () => {
  const url = logo[useTheme()];
  return (
    <div style={{ display: 'flex', alignItems: 'center', fontSize: 14 }}>
      <img src={url} style={{ height: '42px', width: 'auto' }} />
    </div>
  );
};
