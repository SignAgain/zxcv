import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Res,
} from '@nestjs/common';
import { ApiBody, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { Response } from 'express';
import { Subscription } from 'rxjs';
import { Public } from '../common/auth';
import { AgentRuntimeService } from '../runtime/agent-runtime.service';
import { AgentSessionService } from '../state/agent-session.service';
import { StreamEventType, StreamSource } from '../types/stream-client-event';

class SendMessageDto {
  @IsString()
  @IsNotEmpty()
  content!: string;
}

@Public()
@ApiTags('Agent')
@Controller('agent')
export class AgentController {
  constructor(
    private readonly runtime: AgentRuntimeService,
    private readonly sessions: AgentSessionService,
  ) {}

  @Post('sessions')
  @ApiOperation({ summary: 'Create agent session' })
  createSession() {
    // 创建会话并发布 session.created 事件，供前端建立会话态。
    const session = this.sessions.createSession();
    this.sessions.publish(session.id, StreamEventType.SessionCreated, StreamSource.SessionService, {
      sessionId: session.id,
      createdAt: session.createdAt,
    });
    return { sessionId: session.id, createdAt: session.createdAt };
  }

  @Get('sessions/:sessionId/stream')
  @ApiOperation({ summary: 'Subscribe session events over SSE' })
  @ApiParam({ name: 'sessionId', required: true })
  stream(@Param('sessionId') sessionId: string, @Res() res: Response): void {
    // 先校验会话是否存在，避免建立无效连接。
    this.sessions.getSession(sessionId);

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const write = (payload: unknown) => {
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    };

    write({
      event_id: 'stream-open',
      sequence_num: 0,
      event_type: 'stream.open',
      source: StreamSource.SessionService,
      payload: { sessionId },
      created_at: new Date().toISOString(),
    });

    // 心跳用于让长连接保持活跃，并作为连接存活信号。
    const heartbeat = setInterval(() => {
      write(
        this.sessions.publish(
          sessionId,
          StreamEventType.Heartbeat,
          StreamSource.SessionService,
          { sessionId },
        ),
      );
    }, 15000);

    const stream$ = this.sessions.stream(sessionId);
    const subscription: Subscription = stream$.subscribe((event) => write(event));

    // 客户端断开时及时释放资源，避免内存和定时器泄漏。
    res.on('close', () => {
      clearInterval(heartbeat);
      subscription.unsubscribe();
      res.end();
    });
  }

  @Post('sessions/:sessionId/messages')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Send a message and run agent workflow' })
  @ApiParam({ name: 'sessionId', required: true })
  @ApiBody({ type: SendMessageDto })
  async sendMessage(@Param('sessionId') sessionId: string, @Body() body: SendMessageDto) {
    const content = (body.content || '').trim();
    if (!content) {
      return {
        sessionId,
        status: 'ignored',
        reason: 'content is empty',
      };
    }

    this.sessions.publish(sessionId, StreamEventType.RunStarted, StreamSource.Runtime, {
      prompt: content,
    });

    // HTTP 接口快速返回，避免网关因长耗时 LLM 调用返回 504；最终结果通过 SSE 推送。
    void this.executeRunInBackground(sessionId, content);
    return {
      sessionId,
      status: 'accepted',
    };
  }

  private async executeRunInBackground(sessionId: string, content: string): Promise<void> {
    try {
      // 执行过程中通过 onEvent 将内部事件实时转发到 SSE 通道。
      const result = await this.runtime.execute({
        prompt: content,
        history: this.sessions.getMessages(sessionId),
        onEvent: (eventType, source, payload) => {
          this.sessions.publish(sessionId, eventType, source, payload);
        },
      });

      this.sessions.setMessages(sessionId, result.messages);
      this.sessions.publish(sessionId, StreamEventType.RunCompleted, StreamSource.Runtime, {
        finalText: result.finalText,
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.sessions.publish(sessionId, StreamEventType.RunFailed, StreamSource.Runtime, {
        message,
      });
    }
  }
}
