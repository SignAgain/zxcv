import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PlanAgent } from '../agents/built-in/plan-agent';
import { QueryEngineService } from '../engine/query-engine.service';
import { RuntimeExecuteInput } from '../types/agent';
import { QueryResult } from '../types/query';
import { ToolRegistryService } from '../tools/tool-registry.service';

/**
 * AgentRuntime 作为单一入口，负责拼装上下文并驱动 QueryEngine。
 */
@Injectable()
export class AgentRuntimeService {
  constructor(
    private readonly planAgent: PlanAgent,
    private readonly queryEngine: QueryEngineService,
    private readonly toolRegistry: ToolRegistryService,
    private readonly configService: ConfigService,
  ) {}

  async execute(input: RuntimeExecuteInput): Promise<QueryResult> {
    const history = [...input.history];

    // 确保会话里始终有 system 指令，当前默认使用 PlanAgent 的系统提示。
    if (!history.length || history[0].role !== 'system') {
      history.unshift({
        role: 'system',
        content: this.planAgent.getSystemPrompt(),
      });
    }

    history.push({
      role: 'user',
      content: input.prompt,
    });

    // 按 Agent 能力收敛可用工具，防止越权调用。
    const allowedTools = this.toolRegistry.listOpenAITools(this.planAgent.getAllowedToolNames());

    return this.queryEngine.run(
      {
        messages: history,
        tools: allowedTools,
        maxTurns: this.readNumberConfig('AGENT_MAX_TURNS', 200),
        model: this.configService.get<string>('LLM_MODEL') ?? 'kimi-k2.5',
        temperature: this.readTemperatureByMode(),
        topP: this.readNumberConfig('LLM_TOP_P', 0.95),
        maxOutputTokens: this.readNumberConfig('LLM_MAX_OUTPUT_TOKENS', 1024),
        thinkingEnabled: this.readBooleanConfig('LLM_THINKING_ENABLED', true),
        onEvent: (event) => input.onEvent?.(event.eventType, event.source, event.payload),
      },
      {
        workspaceRoot: this.configService.get<string>('AGENT_WORKSPACE_ROOT') || process.cwd(),
      },
    );
  }

  private readTemperatureByMode(): number {
    const configured = this.readNumberConfig('LLM_TEMPERATURE');
    if (typeof configured === 'number') {
      return configured;
    }
    // kimi-k2.5 推荐：thinking=1.0，instant=0.6。
    return this.readBooleanConfig('LLM_THINKING_ENABLED', true) ? 1.0 : 0.6;
  }

  private readNumberConfig(key: string, fallback?: number): number | undefined {
    const value = this.configService.get<string | number | undefined>(key);
    if (typeof value === 'number' && Number.isFinite(value)) {
      return value;
    }
    if (typeof value === 'string' && value.trim()) {
      const parsed = Number(value);
      if (!Number.isNaN(parsed) && Number.isFinite(parsed)) {
        return parsed;
      }
    }
    return fallback;
  }

  private readBooleanConfig(key: string, fallback: boolean): boolean {
    const value = this.configService.get<string | boolean | undefined>(key);
    if (typeof value === 'boolean') {
      return value;
    }
    if (typeof value === 'string') {
      const normalized = value.trim().toLowerCase();
      if (normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on') {
        return true;
      }
      if (normalized === 'false' || normalized === '0' || normalized === 'no' || normalized === 'off') {
        return false;
      }
    }
    return fallback;
  }
}
