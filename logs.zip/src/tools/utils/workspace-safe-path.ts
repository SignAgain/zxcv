import * as path from 'node:path';

/**
 * 将路径解析到 workspaceRoot 下，防止目录穿越（与 file_read 工具一致）。
 */
export function resolvePathUnderWorkspace(workspaceRoot: string, rawPath: string): string {
  const root = path.resolve(workspaceRoot);
  const resolved = path.isAbsolute(rawPath) ? path.resolve(rawPath) : path.resolve(root, rawPath);
  const relative = path.relative(root, resolved);
  if (relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error('Path is outside workspace root');
  }
  return resolved;
}
