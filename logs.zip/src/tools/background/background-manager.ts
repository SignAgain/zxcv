import { randomUUID } from 'node:crypto';
import { exec } from 'node:child_process';
import { BG_TIMEOUT_MS, MAX_TOOL_CHARS, NOTIF_RESULT_MAX } from '../constants';

export type BgTaskRecord = {
  status: string;
  result: string | null;
  command: string;
};

export type BgNotification = {
  task_id: string;
  status: string;
  command: string;
  result: string;
};

/**
 * 后台 shell 任务与完成通知队列；便于在对话中注入完成结果。
 */
export class BackgroundManager {
  private readonly tasks = new Map<string, BgTaskRecord>();
  private readonly notificationQueue: BgNotification[] = [];

  constructor(private readonly workdir: () => string) {}

  run(command: string): string {
    const taskId = randomUUID().replace(/-/g, '').slice(0, 8);
    this.tasks.set(taskId, {
      status: 'running',
      result: null,
      command,
    });
    const cwd = this.workdir();
    exec(
      command,
      {
        cwd,
        timeout: BG_TIMEOUT_MS,
        maxBuffer: 2 * 1024 * 1024,
      },
      (err, stdout, stderr) => {
        let output: string;
        let status: string;
        if (err) {
          const msg = String(err.message ?? err);
          if (msg.includes('ETIMEDOUT') || msg.includes('SIGTERM')) {
            output = 'Error: Timeout (300s)';
            status = 'timeout';
          } else {
            output = `Error: ${msg}`;
            status = 'error';
          }
        } else {
          output = `${stdout ?? ''}${stderr ?? ''}`.trim() || '(no output)';
          status = 'completed';
        }
        const capped =
          output.length > MAX_TOOL_CHARS ? output.slice(0, MAX_TOOL_CHARS) : output;
        const rec = this.tasks.get(taskId);
        if (rec) {
          rec.status = status;
          rec.result = capped;
        }
        const forQueue = capped.slice(0, NOTIF_RESULT_MAX);
        this.notificationQueue.push({
          task_id: taskId,
          status,
          command: command.slice(0, 80),
          result: forQueue || '(no output)',
        });
      },
    );
    return `Background task ${taskId} started: ${command.slice(0, 80)}`;
  }

  check(taskId?: string): string {
    if (taskId) {
      const t = this.tasks.get(taskId);
      if (!t) {
        return `Error: Unknown task ${taskId}`;
      }
      const preview = t.command.slice(0, 60);
      const body = t.result ?? '(running)';
      return `[${t.status}] ${preview}\n${body}`;
    }
    const lines: string[] = [];
    for (const [tid, t] of this.tasks) {
      lines.push(`${tid}: [${t.status}] ${t.command.slice(0, 60)}`);
    }
    return lines.length ? lines.join('\n') : 'No background tasks.';
  }

  drainNotifications(): BgNotification[] {
    const notifs = [...this.notificationQueue];
    this.notificationQueue.length = 0;
    return notifs;
  }
}
