import { Injectable } from '@nestjs/common';
import { ToolCall } from '../types/agent-message';
import { AgentTool, OpenAIFunctionTool, ToolContext, ToolResult } from '../types/tool';
import { BackgroundRunTool } from './built-in/background/background-run.tool';
import { CheckBackgroundTool } from './built-in/background/check-background.tool';
import { EditFileTool } from './built-in/files/edit-file.tool';
import { FileReadTool } from './built-in/files/file-read.tool';
import { BashTool } from './built-in/shell/bash.tool';

@Injectable()
export class ToolRegistryService {
  private readonly tools = new Map<string, AgentTool>();

  constructor(
    fileReadTool: FileReadTool,
    editFileTool: EditFileTool,
    bashTool: BashTool,
    backgroundRunTool: BackgroundRunTool,
    checkBackgroundTool: CheckBackgroundTool,
  ) {
    this.register(fileReadTool);
    this.register(editFileTool);
    this.register(bashTool);
    this.register(backgroundRunTool);
    this.register(checkBackgroundTool);
  }

  register(tool: AgentTool): void {
    this.tools.set(tool.name, tool);
  }

  get(name: string): AgentTool | undefined {
    return this.tools.get(name);
  }

  listOpenAITools(allowedNames?: string[]): OpenAIFunctionTool[] {
    const names = allowedNames ?? Array.from(this.tools.keys());
    return names
      .map((name) => this.tools.get(name))
      .filter((tool): tool is AgentTool => Boolean(tool))
      .map((tool) => ({
        type: 'function',
        function: {
          name: tool.name,
          description: tool.description,
          parameters: tool.inputJsonSchema,
        },
      }));
  }

  async execute(call: ToolCall, context: ToolContext): Promise<ToolResult> {
    const tool = this.tools.get(call.name);
    if (!tool) {
      return { success: false, error: `Unknown tool: ${call.name}` };
    }

    const parsed = tool.inputSchema.safeParse(call.input);
    if (!parsed.success) {
      return {
        success: false,
        error: parsed.error.issues.map((item) => item.message).join('; '),
      };
    }

    return tool.call(parsed.data, context);
  }
}
