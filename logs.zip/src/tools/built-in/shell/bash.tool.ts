import { Injectable } from '@nestjs/common';
import { exec } from 'node:child_process';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { BASH_TIMEOUT_MS, DANGEROUS_BASH, MAX_TOOL_CHARS } from '../../constants';

const BashInputSchema = z.object({
  command: z.string().min(1),
});

type BashInput = z.infer<typeof BashInputSchema>;

@Injectable()
export class BashTool implements AgentTool<BashInput, string> {
  name = 'bash';
  description = 'Run a shell command (blocking).';
  inputSchema = BashInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { command: { type: 'string' } },
    required: ['command'],
  };
  isReadOnly = false;

  async call(input: BashInput, context: ToolContext): Promise<ToolResult<string>> {
    if (DANGEROUS_BASH.some((d) => input.command.includes(d))) {
      return { success: true, data: 'Error: Dangerous command blocked' };
    }
    const cwd = context.workspaceRoot;
    const text = await new Promise<string>((resolve) => {
      exec(
        input.command,
        { cwd, timeout: BASH_TIMEOUT_MS, maxBuffer: 2 * 1024 * 1024 },
        (err, stdout, stderr) => {
          if (err) {
            const msg = String(err.message ?? err);
            if (msg.includes('ETIMEDOUT') || msg.includes('SIGTERM')) {
              resolve('Error: Timeout (120s)');
              return;
            }
          }
          const out = `${stdout ?? ''}${stderr ?? ''}`.trim();
          const sliced = out.length > MAX_TOOL_CHARS ? out.slice(0, MAX_TOOL_CHARS) : out;
          resolve(sliced || '(no output)');
        },
      );
    });
    return { success: true, data: text };
  }
}
