import { Injectable } from '@nestjs/common';
import { promises as fs } from 'fs';
import * as path from 'path';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';

// FileRead 输入契约：仅支持文本读取相关参数。
const FileReadInputSchema = z.object({
  path: z.string().min(1),
  offset: z.number().int().positive().optional(),
  limit: z.number().int().positive().max(5000).optional(),
});

type FileReadInput = z.infer<typeof FileReadInputSchema>;

@Injectable()
export class FileReadTool implements AgentTool<FileReadInput, Record<string, unknown>> {
  name = 'file_read';
  description = 'Read UTF-8 text from a file within AGENT_WORKSPACE_ROOT';
  inputSchema = FileReadInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      path: { type: 'string', description: 'Absolute or workspace-relative file path' },
      offset: { type: 'integer', minimum: 1 },
      limit: { type: 'integer', minimum: 1, maximum: 5000 },
    },
    required: ['path'],
    additionalProperties: false,
  };
  isReadOnly = true;

  async call(input: FileReadInput, context: ToolContext): Promise<ToolResult<Record<string, unknown>>> {
    try {
      // 解析并校验路径，确保不会越出 AGENT_WORKSPACE_ROOT。
      const filePath = this.resolvePath(context.workspaceRoot, input.path);
      const content = await fs.readFile(filePath, 'utf-8');
      const lines = content.split(/\r?\n/);

      const start = input.offset ? input.offset - 1 : 0;
      const sliced = input.limit ? lines.slice(start, start + input.limit) : lines.slice(start);
      const numbered = sliced.map((line, idx) => `${start + idx + 1}|${line}`).join('\n');

      return {
        success: true,
        data: {
          path: filePath,
          content: numbered,
          totalLines: lines.length,
        },
      };
    } catch (error) {
      // 工具错误转为结构化失败结果，而不是直接抛异常中断主流程。
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  }

  private resolvePath(workspaceRoot: string, rawPath: string): string {
    const root = path.resolve(workspaceRoot);
    const resolved = path.isAbsolute(rawPath) ? path.resolve(rawPath) : path.resolve(root, rawPath);

    const relative = path.relative(root, resolved);
    if (relative.startsWith('..') || path.isAbsolute(relative)) {
      // 防目录穿越：禁止读取工作区外的文件。
      throw new Error('Path is outside AGENT_WORKSPACE_ROOT');
    }

    return resolved;
  }
}
