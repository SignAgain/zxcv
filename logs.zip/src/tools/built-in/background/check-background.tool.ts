import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';

const CheckBackgroundInputSchema = z.object({
  task_id: z.string().optional(),
});

type CheckBackgroundInput = z.infer<typeof CheckBackgroundInputSchema>;

@Injectable()
export class CheckBackgroundTool implements AgentTool<CheckBackgroundInput, string> {
  name = 'check_background';
  description = 'Check background task status. Omit task_id to list all.';
  inputSchema = CheckBackgroundInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { task_id: { type: 'string' } },
  };
  isReadOnly = true;

  async call(input: CheckBackgroundInput, context: ToolContext): Promise<ToolResult<string>> {
    if (!context.background) {
      return {
        success: false,
        error: 'Background tasks are not available in this execution context.',
      };
    }
    const id =
      typeof input.task_id === 'string' && input.task_id.length ? input.task_id : undefined;
    return { success: true, data: context.background.check(id) };
  }
}
