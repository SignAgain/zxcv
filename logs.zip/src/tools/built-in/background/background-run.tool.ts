import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';

const BackgroundRunInputSchema = z.object({
  command: z.string().min(1),
});

type BackgroundRunInput = z.infer<typeof BackgroundRunInputSchema>;

@Injectable()
export class BackgroundRunTool implements AgentTool<BackgroundRunInput, string> {
  name = 'background_run';
  description = 'Run command in background thread. Returns task_id immediately.';
  inputSchema = BackgroundRunInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { command: { type: 'string' } },
    required: ['command'],
  };
  isReadOnly = false;

  async call(input: BackgroundRunInput, context: ToolContext): Promise<ToolResult<string>> {
    if (!context.background) {
      return {
        success: false,
        error: 'Background tasks are not available in this execution context.',
      };
    }
    return { success: true, data: context.background.run(input.command) };
  }
}
