/**
 * Chat Agent 循环与 QueryEngine 合并的内置工具名（与 file_read 统一，不再单独提供 read_file）。
 */
export const CHAT_BUILTIN_TOOL_NAMES = [
  'file_read',
  'bash',
  'write_file',
  'edit_file',
  'background_run',
  'check_background',
] as const;
