import { Module } from '@nestjs/common';
import { BackgroundRunTool } from './built-in/background/background-run.tool';
import { CheckBackgroundTool } from './built-in/background/check-background.tool';
import { EditFileTool } from './built-in/files/edit-file.tool';
import { FileReadTool } from './built-in/files/file-read.tool';
import { BashTool } from './built-in/shell/bash.tool';
import { ToolRegistryService } from './tool-registry.service';

/**
 * 内置 AgentTool 注册表；与 Chat Agent、QueryEngine、AgentRuntime 共用。
 */
@Module({
  providers: [
    FileReadTool,
    EditFileTool,
    BashTool,
    BackgroundRunTool,
    CheckBackgroundTool,
    ToolRegistryService,
  ],
  exports: [ToolRegistryService],
})
export class ToolsModule {}
