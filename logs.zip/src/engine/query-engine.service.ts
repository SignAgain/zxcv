import { Injectable } from '@nestjs/common';
import { QueryParams, QueryResult } from '../types/query';
import { ToolContext } from '../types/tool';
import { CHAT_BUILTIN_TOOL_NAMES } from '../tools/builtin-tool-names';
import { ToolRegistryService } from '../tools/tool-registry.service';
import { LlmClient } from '../utils/llm-client';
import { mergeOpenAiToolsDistinct } from '../utils/openai-messages';

/**
 * QueryEngine 负责执行「LLM -> 工具 -> LLM」循环，直到得到终态响应或达到回合上限。
 * 大模型调用经 LlmClient.streamChat（SSE 汇总为单轮 assistant + tool_calls）。
 */
@Injectable()
export class QueryEngineService {
  constructor(
    private readonly llmClient: LlmClient,
    private readonly toolRegistry: ToolRegistryService,
  ) {}

  async run(params: QueryParams, context: ToolContext): Promise<QueryResult> {
    const messages = [...params.messages];
    const maxTurns = params.maxTurns ?? 6;

    for (let turn = 1; turn <= maxTurns; turn += 1) {
      // 每轮都把当前消息历史发送给模型，并流式上报 token 增量。
      const response = await this.llmClient.streamChat(
        {
          messages,
          tools: mergeOpenAiToolsDistinct(
            params.tools,
            this.toolRegistry.listOpenAITools([...CHAT_BUILTIN_TOOL_NAMES]),
          ),
          model: params.model,
          temperature: params.temperature,
          topP: params.topP,
          maxOutputTokens: params.maxOutputTokens,
          thinkingEnabled: params.thinkingEnabled,
        },
        {
          onDelta: (text) => {
            params.onEvent?.({
              eventType: 'llm.delta',
              source: 'llm_client',
              payload: { text },
            });
          },
        },
      );

      const assistantMessage = response.message;
      messages.push(assistantMessage);
      params.hooks?.onMessage?.(assistantMessage);

      // 非流式整包返回：用一次 delta 推送整段文本，兼容仍监听 llm.delta 的前端。
      if (assistantMessage.content) {
        params.onEvent?.({
          eventType: 'llm.delta',
          source: 'llm_client',
          payload: { text: assistantMessage.content },
        });
      }

      if (!response.toolCalls.length) {
        params.hooks?.onTurnComplete?.(turn);
        return {
          messages,
          finalText: assistantMessage.content,
        };
      }

      for (const toolCall of response.toolCalls) {
        params.hooks?.onToolCall?.(toolCall.name, toolCall.input);
        params.onEvent?.({
          eventType: 'tool.call',
          source: 'query_engine',
          payload: {
            id: toolCall.id,
            name: toolCall.name,
            input: toolCall.input,
          },
        });

        const result = await this.toolRegistry.execute(toolCall, context);
        params.hooks?.onToolResult?.(toolCall.name, result);
        params.onEvent?.({
          eventType: 'tool.result',
          source: 'query_engine',
          payload: {
            id: toolCall.id,
            name: toolCall.name,
            result,
          },
        });

        messages.push({
          // 工具结果作为 tool role 消息写回历史，供下一轮模型消费。
          role: 'tool',
          toolCallId: toolCall.id,
          name: toolCall.name,
          content: JSON.stringify(result),
        });
      }

      params.hooks?.onTurnComplete?.(turn);
    }

    return {
      messages,
      finalText: 'Reached maxTurns without terminal response.',
    };
  }
}
