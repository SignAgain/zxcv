import { AgentMessage, ToolCall } from './agent-message';
import { OpenAIFunctionTool } from './tool';

export interface LlmStreamCallbacks {
  onDelta?: (text: string) => void;
}

export interface LlmChatRequest {
  messages: AgentMessage[];
  tools: OpenAIFunctionTool[];
  model?: string;
  temperature?: number;
  topP?: number;
  maxOutputTokens?: number;
  thinkingEnabled?: boolean;
}

export interface LlmChatResponse {
  message: AgentMessage;
  toolCalls: ToolCall[];
}
