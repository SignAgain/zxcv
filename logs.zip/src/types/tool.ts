import { ZodTypeAny } from 'zod';

/**
 * Chat Agent 注入的后台 shell 能力；QueryEngine 等场景通常不注入，此时 background_* 工具应返回明确错误。
 */
export interface BackgroundShellContext {
  run(command: string): string;
  check(taskId?: string): string;
}

export interface ToolContext {
  workspaceRoot: string;
  background?: BackgroundShellContext;
}

export interface ToolResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface AgentTool<Input = unknown, Output = unknown> {
  name: string;
  description: string;
  inputSchema: ZodTypeAny;
  inputJsonSchema: Record<string, unknown>;
  isReadOnly: boolean;
  call(input: Input, context: ToolContext): Promise<ToolResult<Output>>;
}

export interface OpenAIFunctionTool {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
}
