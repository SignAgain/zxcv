import React, { useState, useMemo, useEffect } from 'react';
import { Modal } from '@gza/quantex-design';
import { msgCenter } from '@gza/quantex-utils';
import { ResponseCode } from '@gza/quantex-utils/lib/API';
import Layout from './components/Layout';
import FlexLayoutContext from './components/Context';
import LayoutGrid from '@/components/LayoutGrid';
import {
  FlexLayoutProps,
  IContextValue,
  IWorkbenchData,
  IComponentMenu,
  IAction,
} from './interface';
import getWorkbench from './utils/getWorkbench';
import updateWorkbench from './utils/updateWorkbench';
import saveWorkbench from './utils/saveWorkbench';
import getUserMenu from '../../containers/Main/getUserMenu';
import { RELOAD_WORKBENCH_LIST } from './utils/constants';

const FlexLayout: React.FC<FlexLayoutProps> = (props) => {
  const [modal] = useState(new Modal.Store());
  const [workbenchData, setWorkbenchData] = useState<IWorkbenchData>();
  const [componentMenu, setComponentMenu] = useState<IComponentMenu>([]);
  useEffect(() => {
    async function fetchData() {
      const menuRes = await getUserMenu();
      if (menuRes.code === ResponseCode.SUCCESS) {
        setComponentMenu(menuRes.data.list);
        const data = await getWorkbench(props);
        setWorkbenchData(data);
      }
    }

    fetchData();
    const msgToken = msgCenter.subscribe(RELOAD_WORKBENCH_LIST, () => {
      fetchData();
    });
    return () => {
      msgCenter.unsubscribe(msgToken);
    };
  }, []);

  const contextValue: IContextValue = useMemo(() => {
    return {
      modal,
      workbenchData,
      componentMenu,
      updateGridWorkbench: (source: any) => {
        setWorkbenchData(source);
        saveWorkbench(source);
      },
      updateWorkbench: (action: IAction) => {
        const nextWorkbenchData = updateWorkbench(workbenchData as any, action);
        setWorkbenchData(nextWorkbenchData);
        saveWorkbench(nextWorkbenchData);
      },
    } as IContextValue;
  }, [workbenchData, componentMenu]);
  return (
    <FlexLayoutContext.Provider value={contextValue}>
      {workbenchData && workbenchData?.layoutType === 'custom' ? (
        <LayoutGrid {...props} />
      ) : (
        workbenchData?.tabs.map((tab: any, index: number) => {
          return <Layout key={tab.id} layout={tab} dataPath={['tabs', index, 'layouts']} />;
        })
      )}
      <Modal store={modal} />
    </FlexLayoutContext.Provider>
  );
};

export default FlexLayout;
