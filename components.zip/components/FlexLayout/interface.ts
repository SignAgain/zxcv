import { ReactText } from 'react';

export interface CreateConfig {
  id: string;
  type: string;
  layoutType: 'custom' | 'default';
  templateId: string;
  name: string;
  isDefault: boolean;
  autoSaveComParams: boolean;
  workbenchType?: string;
  height: number;
}

export interface FlexLayoutProps {
  id?: string;
  createConfig?: any;
  match?: any;
  location?: any;
}

/**
 * 描述操作面板数据路径
 */
export type IDataPath = Array<ReactText>;

export interface ILayoutProps {
  layout: any;
  dataPath: IDataPath;
}

export interface ILayout {
  layouts: Object[];
}

export interface ILayoutItem {
  id: string;
  url: string;
  name: string;
  menus?: any[];
  props?: any;
  activeMenuId?: ReactText; // 当前激活的页面组件
  activeMenuName?: string;
  linkageValue: string;
  componentParams: any;
  panels?: ILayoutItem[];
}

export interface IWorkbenchData {
  /**
   * 子工作台列表
   */
  id: string;
  name: string;
  tabs: ILayout[];
  layoutType: 'custom' | 'default';
  isDefaultOpen: boolean;
  autoSaveComParams: boolean;
  height: number;
  type: string;
  userCode?: string;
}

export interface IComponentMenuItem {
  id: ReactText;
  pId: ReactText;
  icon?: string;
  appId: string;
  name: string;
  url?: string;
  type?: string[]; // 菜单项类型： 'menu', 'component'
}

export type IComponentMenu = IComponentMenuItem[];

/**
 * 描述操作整体数据结构所需要的字段
 */
export interface IAction {
  type: string;
  panel: ILayoutItem;
  dataPath: IDataPath;
  /**
   * 批量更新操作的时候传递此字段
   */
  batch?: ActionEvent[];
}

export interface ActionEvent {
  panel: ILayoutItem;
  dataPath: IDataPath;
}

export interface IContextValue {
  modal: any;
  workbenchData: IWorkbenchData;
  componentMenu: IComponentMenu;
  /**
   * 纯函数，更新一个版块
   * @param layoutItem 发起对象
   */
  updateWorkbench: (action: IAction) => void;
}

export const ActType = {
  UPDATE: 'update',
  ADD: 'add',
};
