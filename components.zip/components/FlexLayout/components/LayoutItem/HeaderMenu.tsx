import React, { useContext, useEffect, useState } from 'react';
import { Popconfirm } from 'antd';
import classNames from 'classnames';
import {
  PlusOutlined,
  MinusOutlined,
  FullscreenOutlined,
  BarsOutlined,
  FullscreenExitOutlined,
} from '@ant-design/icons';
import FlexLayoutContext from '../Context';
import {
  DELETE,
  ADD_LEFT,
  ADD_RIGHT,
  ADD_TOP,
  ADD_BOTTOM,
  UPDATE,
  HEADER_HEIGHT,
} from '../../utils/constants';
import { IDataPath, ILayoutItem, IContextValue, IWorkbenchData, ActType } from '../../interface';
import { get } from 'lodash';
import { Alert, utils } from '@gza/quantex-design';
import layouts from 'layouts';

import styles from './index.scss';

const iconStyle = {
  fontSize: '12px',
};

interface LayoutItemProps {
  dataPath: IDataPath;
  panel: ILayoutItem;
  match?: any;
  pOrientation?: string;
  workbenchData: IWorkbenchData;
  updateMenu: (type: string) => void;
}

const HeaderMenu: React.FC<LayoutItemProps> = (props) => {
  const { updateWorkbench }: IContextValue = useContext(FlexLayoutContext);
  useEffect(() => {
    return () => {
      // TODO 销毁逻辑
      // const curRef = ReactDOM.findDOMNode(this);
      // const iframes = curRef.querySelectorAll('iframe');
      // iframes.forEach(iframe => {
      //   iframe.src = 'about:blank';
      //   iframe.parentNode.removeChild(iframe);
      // });
    };
  }, []);
  const [isMoreMenuVisible, setIsMoreMenuVisible] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  useEffect(() => {
    const f = () => {
      setIsFullscreen(utils.fullScreen.getFullScreenStatus());
    };
    document.addEventListener('fullscreenchange', f);
    return () => {
      document.removeEventListener('fullscreenchange', f);
    };
  }, []);
  // fullscreen 相关
  const changeFullscreen = () => {
    if (isFullscreen) {
      utils.fullScreen.exit();
    } else {
      const el: any = document.querySelector(`#${`${props.workbenchData.id}-${props.panel.id}`}`);
      utils.fullScreen.makeNodeFullScreen(el, true);
    }
  };

  let timeout: any = null;
  const toggleMoreMenu = (bool: boolean) => {
    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => {
      setIsMoreMenuVisible(bool);
    }, 100);
  };
  const { panel, dataPath } = props;
  const updateFn = (type: string) => {
    layouts.main.beforeSaveWorkbench(props.workbenchData).then((flag) => {
      if (!flag) {
        return;
      }
      updateWorkbench({ type, panel, dataPath });
    });
  };

  // 处理面板展开(+)与折叠(-)
  let isCollapse = !!get(panel, 'props.size');
  const toggleCollapse = () => {
    panel.props = panel.props || {};
    if (panel.props.lock) {
      Alert.info('不能继续折叠了');
      return;
    }
    if (isCollapse) {
      // 删除size、恢复flex,恢复展开面板
      delete panel.props.size;
      panel.props.flex = panel.props.oldFlex;
    } else {
      // 设置size、删除flex，折叠面板
      panel.props.size = HEADER_HEIGHT;
      panel.props.oldFlex = panel.props.flex || 0.5;
      delete panel.props.flex;
    }
    updateWorkbench({ type: UPDATE, panel, dataPath });
  };

  const iconCls = classNames({
    [styles['menu-icon']]: true,
    'hover-primary': true,
  });
  const moreMenuItemCls = classNames({
    [styles['menu-more-item']]: true,
    'hover-border-primary': true,
    'hover-modal-bg': true,
  });

  // 在折叠模式并且是纵向拆分模式下，只保留展开(+)按钮
  if (isCollapse && props.pOrientation === 'vertical') {
    return (
      <div
        className={styles['menu-group']}
        onMouseDown={(e) => {
          e.stopPropagation();
        }}
      >
        <PlusOutlined
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleCollapse();
          }}
          className={iconCls}
          style={iconStyle}
        />
      </div>
    );
  }
  return (
    <div
      className={styles['menu-group']}
      onMouseDown={(e) => {
        e.stopPropagation();
      }}
    >
      {isFullscreen ? (
        <FullscreenExitOutlined onClick={changeFullscreen} className={iconCls} style={iconStyle} />
      ) : (
        <>
          {isCollapse ? (
            <PlusOutlined
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggleCollapse();
              }}
              className={iconCls}
              style={iconStyle}
            />
          ) : (
            <MinusOutlined
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggleCollapse();
              }}
              className={iconCls}
              style={iconStyle}
            />
          )}
          <FullscreenOutlined onClick={changeFullscreen} className={iconCls} style={iconStyle} />
          <BarsOutlined
            onMouseEnter={() => {
              toggleMoreMenu(true);
            }}
            onMouseLeave={() => {
              toggleMoreMenu(false);
            }}
            className={iconCls}
            style={iconStyle}
          />
        </>
      )}
      <div
        onMouseEnter={() => {
          toggleMoreMenu(true);
        }}
        onMouseLeave={() => {
          toggleMoreMenu(false);
        }}
        className={`${styles['menu-more']} layout-workbench-bg-header ${
          isMoreMenuVisible ? '' : styles.hide
        }`}
      >
        {/* <span onClick={openInNewWindow.bind(null, index)} className={moreMenuItemCls}>
          新窗口打开
        </span> */}
        {/* <span onClick={reload.bind(null, index)} className={moreMenuItemCls}>
          重新加载
        </span> */}
        <span
          onClick={() => {
            props.updateMenu?.(ActType.UPDATE);
          }}
          className={moreMenuItemCls}
        >
          修改组件
        </span>
        <Popconfirm
          title="确定删除该面板?"
          placement="topRight"
          trigger={['hover', 'click']}
          mouseEnterDelay={300}
          onConfirm={updateFn.bind(null, DELETE)}
        >
          <span className={moreMenuItemCls}>删除面板</span>
        </Popconfirm>
        <span onClick={updateFn.bind(null, ADD_TOP)} className={moreMenuItemCls}>
          向上拆分
        </span>
        <span onClick={updateFn.bind(null, ADD_BOTTOM)} className={moreMenuItemCls}>
          向下拆分
        </span>
        <span onClick={updateFn.bind(null, ADD_LEFT)} className={moreMenuItemCls}>
          向左拆分
        </span>
        <span onClick={updateFn.bind(null, ADD_RIGHT)} className={moreMenuItemCls}>
          向右拆分
        </span>
      </div>
    </div>
  );
};

export default HeaderMenu;
