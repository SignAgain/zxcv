import React, { useState, useContext, useMemo } from 'react';
import { Transfer, Button, message } from 'antd';
import { Tree } from '@gza/quantex-design';
import { cloneDeep } from 'lodash';
import { IComponentMenu, IComponentMenuItem, ActType } from '../../interface';
import FlexLayoutContext from '../Context';
import styles from './index.scss';

interface IProps {
  onInsert: (selectedMenus: IComponentMenu) => void;
  onClose: () => void;
  menus: IComponentMenu; // 面板已有的菜单
  type?: string;
}

const CompMenu: React.FC<IProps> = (props) => {
  const { componentMenu } = useContext(FlexLayoutContext);

  const dataSource = useMemo(() => {
    // 兼容Tree组件id，需要把id改成string; 保留目录级菜单及带有组件属性（‘component')的菜单 & 兼容没有 type 属性的数据
    return componentMenu
      .filter(
        (menu) =>
          !menu.type ||
          (menu.url == null && menu.type?.includes('component')) ||
          menu.type?.includes('component'),
      )
      .map((menu) => ({ ...menu, key: `${menu.id}`, title: menu.name }));
  }, [componentMenu]);

  // 统计页面总数
  const totalCountOfPage = useMemo(() => {
    return componentMenu.reduce((previousValue, currentValue) => {
      if (currentValue.url) {
        return ++previousValue;
      }
      return previousValue;
    }, 0);
  }, [componentMenu]);

  /**
   * 过滤目录级节点和页面级节点组合
   * @param keys 节点 key 组合
   */
  const filterParentAndPageKeys = (keys: string[]) => {
    const parentKeys: string[] = [];
    const pageKeys: string[] = [];
    const allPageKeys = [...parentIndex.keys()];
    keys.forEach((key) => {
      if (allPageKeys.indexOf(key) > -1) {
        pageKeys.push(key);
      } else {
        parentKeys.push(key);
      }
    });
    return { parentKeys, pageKeys };
  };

  /**
   * 根据 targetKeys 获取[需全选中]的父级
   * @param targetKeys 目前已经在transfer右侧框的页面节点 key 组合
   */
  const getCheckedParentByTargetKeys = (targetKeys: string[] = []) => {
    let checkedParentKeys: string[] = [];
    const isCheckedAll = (arr: string[] = []) => {
      return arr.every((key) => targetKeys.indexOf(key) !== -1);
    };
    const parentKeys = getParentKeys(targetKeys);
    parentKeys.forEach((parent) => {
      if (isCheckedAll(childIndex.get(parent))) {
        checkedParentKeys.push(parent);
      }
    });
    return checkedParentKeys;
  };

  // 选项在两栏之间转移时的回调函数
  const onChange = (selectedKeys: string[], direction: 'left' | 'right', moveKeys: string[]) => {
    const _onChange = (selectedKeys: string[], moveKeys: string[]) => {
      if (selectedKeys.length > 8) {
        message.warning('单个面板最多可添加 8 个组件');
        return;
      }
      let cloneKeys: string[] = selectedKeys;
      if (direction === 'right') {
        // 将target排序改成：后选中的在下方
        cloneKeys = cloneKeys.concat(moveKeys);
        cloneKeys.splice(0, moveKeys.length);
        // 获取所有选中项的父级
        const parentKeys = getCheckedParentByTargetKeys(cloneKeys);
        setCheckedParentKeys(parentKeys as string[]);
      }
      if (direction === 'left') {
        const parentKeys = getParentKeys(moveKeys);
        setCheckedParentKeys((prev) => {
          // 剔除待移动节点的所有父节点
          return prev.filter((key) => {
            return parentKeys.indexOf(key) === -1;
          });
        });
      }
      setTargetKeys(cloneKeys);
    };

    let newMoveKeys = moveKeys;
    const { parentKeys, pageKeys: newSelectedKeys } = filterParentAndPageKeys(selectedKeys);
    if (parentKeys.length) {
      // 顶部全选按钮进入
      newMoveKeys = filterParentAndPageKeys(moveKeys).pageKeys;
    }
    _onChange(newSelectedKeys, newMoveKeys);
  };

  // 点击插入组件
  const insertComp = () => {
    const selectedMenus = targetKeys.map((key) => {
      return componentMenu.find((data) => data.id === Number(key));
    });
    props.onInsert(selectedMenus as IComponentMenu);
  };

  /**
   * 根据keys获取这些keys的父节点组合
   * @param keys 具体的页面节点组合
   */
  const getParentKeys: (keys: string[]) => string[] = (keys) => {
    let parentKeys = keys.reduce((result: string[], current: string) => {
      const keys = parentIndex.get(current);
      return result.concat(keys);
    }, []);
    return [...new Set(parentKeys)];
  };

  /**
   * 获取当前页面节点的 父节点 key数组
   * @param menu 页面节点
   */
  const _getParentKeys = (menu: IComponentMenuItem) => {
    let parentKeys: IComponentMenuItem['pId'][] = [];
    parentKeys.push(menu.pId);
    const parent = componentMenu.find((item) => item.id === menu.pId);
    if (parent && parent.pId !== parent.id) {
      const ancestorKeys = _getParentKeys(parent);
      parentKeys.push(...ancestorKeys);
    }

    return parentKeys.map((key) => `${key}`);
  };

  /**
   * 根据该目录级节点 id 获取其所有页面节点
   * @param id 目录级节点 id
   */
  const _getChildKeys = (id: string) => {
    let childKeys: string[] = [];
    [...parentIndex.keys()].forEach((key) => {
      if (parentIndex.get(key).indexOf(id) !== -1) {
        childKeys.push(key);
      }
    });
    return childKeys.map((key) => `${key}`);
  };

  /**
   * 存储每一个页面节点的父节点
   * {
   *    parentNodeId: [pageNodeId1, pageNodeId2,...]
   * }
   */
  const parentIndex = useMemo(() => {
    let parentMap = new Map();
    componentMenu.forEach((menu) => {
      if (menu.url) {
        // 页面节点，存储父亲
        const id = `${menu.id}`;
        parentMap.set(id, _getParentKeys(menu));
      }
    });
    return parentMap;
  }, [componentMenu]);

  /**
   * 存储每一个父节点包含的页面节点
   * {
   *    pageNodeId: [parentNodeId1, parentNodeId2,...]
   * }
   */
  const childIndex = useMemo(() => {
    let childMap = new Map();
    componentMenu.forEach((menu) => {
      if (!menu.url) {
        // 父亲节点，存储包含页面节点
        const id = `${menu.id}`;
        childMap.set(id, _getChildKeys(id));
      }
    });
    return childMap;
  }, [componentMenu]);

  const [targetKeys, setTargetKeys] = useState(() => {
    let defaultTargetKeys: string[] = [];
    if (props.type === ActType.UPDATE) {
      defaultTargetKeys = props.menus.map((menu) => `${menu.id}`);
    }
    return defaultTargetKeys;
  });

  const [checkedParenKeys, setCheckedParentKeys] = useState(() => {
    let checkedParentKeys: string[] = [];
    if (props.type === ActType.UPDATE) {
      checkedParentKeys = getCheckedParentByTargetKeys(targetKeys);
    }
    return checkedParentKeys;
  });

  const [selectedCountOfPage, setSelectedCountOfPage] = useState(targetKeys.length);

  // 选中的父节点
  const checkedParentTargetKeys = useMemo(() => {
    return checkedParenKeys;
  }, [targetKeys]);
  return (
    <div className={`${styles['comp-menu-container']} form-content-wrapper`}>
      <Transfer
        dataSource={dataSource}
        titles={['组件库', '已选组件']}
        targetKeys={targetKeys}
        render={(item) => item.title}
        onChange={onChange}
        selectAllLabels={[
          () => {
            return <span>{`${selectedCountOfPage} / ${totalCountOfPage}`}</span>;
          },
          ({ selectedCount, totalCount }: { selectedCount: number; totalCount: number }) => {
            return <span>{`${selectedCount} / ${totalCount}`}</span>;
          },
        ]}
      >
        {({ direction, onItemSelect, onItemSelectAll, selectedKeys }) => {
          if (direction === 'left') {
            // 当使用顶部的全选时候，需要过滤selectedKeys中的父级菜单，否则反选会不正常
            const newSelectedKeys = filterParentAndPageKeys(selectedKeys).pageKeys;
            const checkedKeys = [...newSelectedKeys, ...targetKeys, ...checkedParentTargetKeys];
            const disableCheckboxValues = [...targetKeys, ...checkedParentTargetKeys];
            // 顶部选中组件数量统计
            const selectedCountOfPage = newSelectedKeys.concat(targetKeys).length;
            setSelectedCountOfPage(selectedCountOfPage);

            return (
              <Tree
                blockNode
                checkable
                defaultExpandAll
                showFrame={false}
                showLine={false}
                checkedKeys={checkedKeys}
                disableCheckboxValues={disableCheckboxValues}
                treeData={cloneDeep(dataSource)}
                onCheck={(_, { checked, node }) => {
                  if ((node as any).data.url) {
                    onItemSelect(node.key as string, checked);
                  } else {
                    // check的是父节点，则只移动页面节点
                    const checkedKeys = childIndex
                      .get(node.key)
                      .filter((key: string) => targetKeys.indexOf(key) === -1);
                    onItemSelectAll(checkedKeys as string[], checked);
                  }
                }}
              />
            );
          }
        }}
      </Transfer>
      <div className="form-btn-wrapper">
        <Button className="m-r-8" onClick={props.onClose}>
          取消
        </Button>
        <Button type="primary" onClick={insertComp}>
          提交
        </Button>
      </div>
    </div>
  );
};

export default CompMenu;
