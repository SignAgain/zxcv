import React, { useEffect, useRef, useContext, useState } from 'react';
import redirectUrl from '@/common/redirectUrl';
import FlexLayoutContext from '../Context';
import { UPDATE } from '../../utils/constants';
import clearActiveMenu from '../../utils/clearActiveMenu';
import getComponentParams from '../../utils/getComponentParams';
import pageMap from '@/containers/pagemap';
import HeaderMenu from './HeaderMenu';
import CompMenu from './CompMenu';
import {
  IDataPath,
  ILayoutItem,
  IContextValue,
  IComponentMenuItem,
  IComponentMenu,
  ActType,
} from '../../interface';
import { get, isEmpty, compact } from 'lodash';
import layouts from 'layouts';
import { Popover, Modal, message } from 'antd';
import classNames from 'classnames';
import styles from './index.scss';

// const TabPane = Tabs.TabPane;
const { confirm } = Modal;

interface LayoutItemProps {
  componentParams: any;
  linkageValue: string;
  dataPath: IDataPath;
  panel: ILayoutItem;
  match?: any;
  pOrientation?: string;
}

const LayoutItem: React.FC<LayoutItemProps> = (props) => {
  const comRef = React.useRef();
  const { modal, updateWorkbench, workbenchData, componentMenu }: IContextValue =
    useContext(FlexLayoutContext);
  const [hide, setHide] = useState(false);
  const [subTitleHide, setSubTitleHide] = useState(false);
  const [hasComponent, setHasComponent] = useState(false);
  const activeMenuId = useRef(props.panel.id);
  const componentParamsFirst = useRef(props.panel.componentParams || {}); // 首次加载时页面组件的参数

  useEffect(() => {
    // 保存面板组件实例
    window.globalStore.addWorkbenchComRef(comRef, {
      layoutItemId: props.panel.id,
      workbenchId: workbenchData.id,
    });
    return () => {
      // 删除面板组件实例
      window.globalStore.delWorkbenchComRef({
        layoutItemId: props.panel.id,
        workbenchId: workbenchData.id,
      });
      // TODO 销毁逻辑
      // const curRef = ReactDOM.findDOMNode(this);
      // const iframes = curRef.querySelectorAll('iframe');
      // iframes.forEach(iframe => {
      //   iframe.src = 'about:blank';
      //   iframe.parentNode.removeChild(iframe);
      // });
    };
  }, []);

  useEffect(() => {
    // 判断当前工作台面板是否有组件，有就触发 componentParams 事件，传递给组件（非 iframe 方式的组件），只执行一次
    if (hasComponent) {
      window.globalStore.emitWorkbenchEvent(
        'componentParams',
        {
          params: props.panel.componentParams || {},
        },
        {
          props: {
            workbenchId: workbenchData.id,
            layoutItemId: props.panel.id,
          },
        },
      );
    }
  }, [hasComponent, activeMenuId.current]);

  // FIXME 由于外层数据结构暂时不支持 menus，这里手动转换支持一些
  const menus: any[] = isEmpty(props.panel?.menus)
    ? [{ id: props.panel.id, url: props.panel.url }]
    : (props.panel.menus as any[]);
  // const [activeKey, setActiveKey] = useState(menus[0].url);
  const isNewWindow = !!props.match;
  let isCollapse = !!get(props.panel, 'props.size');
  const layoutItemCls = classNames({
    [styles['layout-item-wrapper']]: true,
    'modal-bg-common': true,
    [`layout-item-fullscreen-${menus[0].id}`]: true,
    'js-table-id-prefix': true,
    [styles.collapse]: isCollapse && props.pOrientation === 'vertical', // 在折叠模式并且是纵向拆分模式下，覆盖header的样式
  });

  const addMenu = (type = ActType.ADD) => {
    layouts.main.beforeSaveWorkbench(workbenchData).then((flag) => {
      if (!flag) {
        return;
      }
      const modalTitle = type === ActType.UPDATE ? '修改组件' : '添加组件';
      modal.openForm(
        modalTitle,
        <CompMenu
          type={type}
          menus={menus}
          onClose={() => {
            modal.close();
          }}
          onInsert={(currentSelectedMenus: IComponentMenuItem[]) => {
            const selectedMenus = compact(currentSelectedMenus);

            // 清空/关闭组件
            const clearMenus = function () {
              // 清空当前激活菜单相关配置项
              clearActiveMenu(props.panel);

              updateWorkbench({
                type: UPDATE,
                dataPath: props.dataPath,
                panel: props.panel,
              });
              modal.close();
            };

            if (!selectedMenus.length) {
              if (type === 'update') {
                confirm({
                  title: '清空组件',
                  content: '确认清空该面板所有组件?',
                  okText: '确认',
                  onOk() {
                    clearMenus();
                  },
                });
              } else {
                message.warning('请选择需要添加的组件');
              }
              return;
            }

            const menus = selectedMenus.map((item) => {
              return {
                id: item.id,
                pId: item.pId,
                url: item.url,
                name: item.name,
              };
            });
            const findActiveItem: Partial<IComponentMenuItem> =
              selectedMenus.filter((item) => {
                return item.id === props.panel.activeMenuId;
              })[0] || {};

            let updatePanel = {
              ...props.panel,
              linkageValue: 'white',
              activeMenuName: findActiveItem.name || selectedMenus[0].name,
              activeMenuId: findActiveItem.id || selectedMenus[0].id,
              menus,
            };

            updateWorkbench({
              type: UPDATE,
              dataPath: props.dataPath,
              panel: updatePanel,
            });
            modal.close();
          }}
        />,
        {
          width: 840,
        },
      );
    });
  };

  const renderTabContent = (menu: any) => {
    let { url } = menu;
    if (!url) {
      if (hasComponent) {
        // 组件不存在时，置 false
        setHasComponent(false);
      }
      return (
        <div key={menu.url || menu.id} className={styles.content}>
          <div
            className={styles.plus}
            onClick={() => {
              addMenu();
            }}
          >
            <span>+</span>
            <div>从组件库添加</div>
          </div>
        </div>
      );
    }

    if (!componentMenu.some((item: any) => item.url === menu.url)) {
      return <div>抱歉，您没有当前组件权限</div>;
    }
    if (url.includes(':') || url.startsWith('/iframe')) {
      // 如果路径匹配到的是可直接访问链接,则返回 iframe
      if (url.startsWith('/iframe')) {
        // 通过服务端来重定向到指定访问链接
        url += `&theme=${window.getCurrentTheme()}`;
        if (!url.includes('isInWorkbench')) {
          url += `&isInWorkbench=true`;
        }
        // 将workbenchId和layoutItemId拼接到url上
        if (!url.includes('workbenchId')) {
          url += `&workbenchId=${workbenchData.id}&layoutItemId=${props.panel.id}`;
        }
      }
    }

    const contentCls = classNames({
      // [styles.hide]: menu.url !== activeKey, // TODO 多 tab 支持
      [styles.content]: true,
      'ag-calc-height-wrapper': true,
    });
    // 将workbenchId和layoutItemId传递给组件
    const tabProps = {
      workbenchId: workbenchData.id,
      layoutItemId: props.panel.id,
      linkageValue: props.panel.linkageValue,
      params: componentParamsFirst.current, // 保证第一次渲染组件时的组件参数，确保组件参数的传递是不变的
    };
    let path = url;
    let TabContent;
    if (pageMap.has(url)) {
      let Component = pageMap.get(url);
      TabContent = (
        <div key={menu.url} className={contentCls}>
          <Component ref={comRef} {...tabProps} />
        </div>
      );
      if (!hasComponent) {
        // 组件存在时，置 true
        setHasComponent(true);
      }
    } else {
      path = redirectUrl(url);
      if (!path) {
        TabContent = pageMap.get(`${process.env.APP_ID}/Notfound`);
      } else {
        const newParams = new URLSearchParams({
          componentParams: JSON.stringify(componentParamsFirst.current),
          linkageValue: props.panel.linkageValue,
        });
        const appId = window.getUrlParams(url).appId;
        path = `${path}&${newParams.toString()}`;
        TabContent = (
          <div key={menu.url} className={contentCls}>
            <iframe
              id={props.panel.id}
              onLoad={() => iFrameLoad(props.panel.id, appId)}
              data-app-id={appId}
              data-linkage-value={props.panel.linkageValue}
              data-layout-item-id={tabProps.layoutItemId}
              className={styles.iframe}
              style={{ background: 'transparent' }}
              src={path}
            />
          </div>
        );
      }
    }
    return TabContent;
  };

  const iFrameLoad = (id: string, appId?: string) => {
    // 当 iframe load 完成时，给 iframe 子应用发送 componentParams 事件
    const dom: any = document.getElementById(id);
    if (dom.src) {
      // 将 iframe load 完成消息推送给 portal
      dom.contentWindow.top.postMessage(
        {
          appId,
          type: 'workbench-iframe-ready',
          // layoutItemId: props.panel.id,
          // workbenchId: workbenchData.id,
        },
        '*',
      );
    }
  };

  const linkageSelect = (item: any) => {
    const updatePanel = {
      ...props.panel,
      linkageValue: item.linkageValue,
    };
    setHide(false);
    updateWorkbench({
      type: UPDATE,
      dataPath: props.dataPath,
      panel: updatePanel,
    });
  };

  const renderSelect = () => {
    const list: any[] = [
      { id: 0, name: '白色通道', linkageValue: 'white' },
      { id: 1, name: '红色通道', linkageValue: 'red' },
      { id: 2, name: '橙色通道', linkageValue: 'orange' },
      { id: 3, name: '黄色通道', linkageValue: 'yellow' },
      { id: 4, name: '绿色通道', linkageValue: 'green' },
      { id: 5, name: '蓝色通道', linkageValue: 'blue' },
      { id: 6, name: '靛色通道', linkageValue: 'indigo' },
      { id: 7, name: '紫色通道', linkageValue: 'purple' },
    ];
    return (
      <ul className="linkage-select">
        {list.map((item) => (
          <li
            className={item.linkageValue === props.panel.linkageValue ? 'active' : ''}
            key={item.id}
            onClick={() => {
              linkageSelect(item);
            }}
          >
            <div style={{ background: `${item.linkageValue}` }} />
            {item.name}
          </li>
        ))}
      </ul>
    );
  };

  /**
   * 渲染页面组件下拉列表
   * @param menus
   */
  const renderMenuSelect = (menus: IComponentMenu) => {
    if (!menus.length) {
      return null;
    }
    return (
      <ul className="linkage-select">
        {menus.map((item) => (
          <li
            className={item.id === props.panel.activeMenuId ? 'active' : ''}
            key={item.id}
            onClick={() => {
              handleMenuSelected(item);
            }}
          >
            {item.name}
          </li>
        ))}
      </ul>
    );
  };

  /**
   * 切换页面组件选择
   * @param item
   */
  const handleMenuSelected = (item: any) => {
    // 选中某条记录后，需要将当前记录上的 参数也放出来
    const componentParams = getComponentParams(props.panel, item.id) || {};

    const updatePanel = {
      ...props.panel,
      componentParams,
      // name: item.name,
      // url: item.url,
      activeMenuName: item.name,
      activeMenuId: item.id,
    };
    setSubTitleHide(false);
    activeMenuId.current = item.id;
    componentParamsFirst.current = componentParams;
    updateWorkbench({
      type: UPDATE,
      dataPath: props.dataPath,
      panel: updatePanel,
    });
  };
  return (
    <div className={layoutItemCls} id={`${workbenchData.id}-${props.panel.id}`}>
      <div className={`${styles.header} layout-workbench-bg-header`}>
        {props.panel.activeMenuName && (
          <div className={`${styles['header-title']}`}>
            <Popover
              visible={hide}
              placement="bottomLeft"
              content={renderSelect()}
              trigger="click"
              onVisibleChange={(v) => {
                setHide(v);
              }}
            >
              <span
                className={styles['linkage-bar']}
                style={{ borderColor: `${props.panel.linkageValue}` }}
              ></span>
            </Popover>
            <Popover
              visible={subTitleHide}
              placement="bottomLeft"
              content={renderMenuSelect(menus)}
              trigger="click"
              onVisibleChange={(v) => {
                setSubTitleHide(v);
              }}
            >
              <span className={styles['sub-title']}>{props.panel.activeMenuName}</span>
            </Popover>
          </div>
        )}
        <div className={styles['tab-group']} />
        {/* {menus.length <= 1 ? (
          <div className={styles['tab-group']}></div>
        ) : (
          <div
            onMouseDown={e => {
              e.stopPropagation();
            }}
            className={styles['tab-group'] + ` tab-group`}>
            <Tabs className={styles['tabs']} tabBarGutter={0} onChange={(val) => {setActiveKey(val)}} type="card">
              {menus.map(menu => (
                <TabPane tab={menu.name} key={menu.url}></TabPane>
              ))}
            </Tabs>
          </div>
        )} */}
        {isNewWindow ? null : (
          <HeaderMenu workbenchData={workbenchData} updateMenu={addMenu} {...props} />
        )}
      </div>
      <div
        className={classNames(styles['content-wrapper'])}
        style={{ display: isCollapse ? 'none' : 'block' }}
      >
        {menus.map((menu) => {
          // 若存在激活页面，则只渲染当前当前激活的页面；否则展示加号图标
          if (props.panel.activeMenuId && menu.id !== props.panel.activeMenuId) {
            return null;
          }
          return renderTabContent(menu);
        })}
      </div>
    </div>
  );
};

export default LayoutItem;
