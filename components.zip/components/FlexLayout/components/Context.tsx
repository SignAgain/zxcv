/*
 * @Author: jingsheng.wang jingsheng.wang@iquantex.com
 * @Date: 2024-05-25 21:24:18
 * @LastEditors: jingsheng.wang jingsheng.wang@iquantex.com
 * @LastEditTime: 2024-05-25 22:01:29
 * @FilePath: /quantex-scaffold/app/components/FlexLayout/components/Context.tsx
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import React from 'react';
import { IContextValue } from '../interface';

const defaultContextValue: IContextValue = {
  workbenchData: {
    layoutType: 'default',
    tabs: [],
  },
  updateWorkbench: () => {},
};

export default React.createContext(defaultContextValue);
