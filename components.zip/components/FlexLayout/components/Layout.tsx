import React, { useContext, ReactElement, useEffect } from 'react';
import {
  ReflexContainer,
  ReflexSplitter,
  ReflexElement,
  ReflexContainerProps,
  ReflexElementProps,
  HandlerProps,
} from 'react-reflex';
import { set, cloneDeep, debounce, get } from 'lodash';
import FlexLayoutContext from './Context';
import LayoutItem from './LayoutItem';
import { UPDATE, BATCH_UPDATE } from '../utils/constants';
import getPanel from '../utils/getPanel';
import { ILayoutProps, IContextValue, IAction, ILayoutItem } from '../interface';
import 'react-reflex/styles.css';

const initUpdateData = {
  type: BATCH_UPDATE,
  panel: {},
  dataPath: [],
  batch: [],
};

const Layout: React.FC<ILayoutProps> = (props) => {
  const { updateWorkbench, workbenchData }: IContextValue = useContext(FlexLayoutContext);
  const layoutData = props.layout.layouts;

  let updateData: any = cloneDeep(initUpdateData);
  const updateWorkbenchWithDebounce = debounce(() => {
    updateWorkbench(updateData);
    updateData = cloneDeep(initUpdateData);
  }, 500);

  useEffect(() => {
    // 监听 子应用 事件
    const eventHandler = (event: any) => {
      if (event.data.type === 'single-page-ready') {
        if (event.data.workbenchId === workbenchData?.id) {
          // document.querySelector('#layout-1669170990823-row-1 #row-1')
          const dom: any = document.querySelector(
            `#${event.data.workbenchId}-${event.data.layoutItemId} #${event.data.layoutItemId}`,
          );
          if (dom.src) {
            const panelData = getPanel(event.data.layoutItemId, workbenchData)! as ILayoutItem;
            // 将当前 panel 的参数发回去
            dom.contentWindow.postMessage(
              {
                type: 'componentParams',
                params: panelData?.componentParams || {},
                // 把对应的工作台面板id和panel Id 传过去
              },
              '*',
            );
          }
        }
      }
    };
    if (process.env.IS_PORTAL) {
      window.addEventListener('message', eventHandler, false);
    }

    return () => {
      window.removeEventListener('message', eventHandler, false);
    };
  }, [workbenchData]);

  const onResizePanel = (event: HandlerProps, { panel, dataPath }: IAction) => {
    const { flex } = event.component.props;
    const updatePanel = cloneDeep(panel);
    set(updatePanel, 'props.flex', flex);
    updateData.batch.push({
      panel: updatePanel,
      dataPath,
    });
    updateWorkbenchWithDebounce();
  };

  const renderLayout = (
    layout: any,
    dataPath: Array<string | number>,
    containerProps?: ReflexContainerProps | ReflexElementProps,
    pOrientation?: string,
  ) => {
    const renderPanel = (panel: any, path: Array<string | number>, pOrientation?: string) => {
      if (panel.panels) {
        return renderLayout(
          panel.panels,
          [...path, 'panels'],
          panel.props,
          get(panel, 'props.orientation'),
        );
      }
      return <LayoutItem dataPath={path} panel={panel} pOrientation={pOrientation} />;
    };
    const elements = layout.reduce((a: ReactElement[], b: any, index: number) => {
      // 不是最后一个元素需要在中间添加操作条组件
      const newDataPath = [...dataPath, index];
      a.push(
        <ReflexElement
          key={b.id}
          minSize={260}
          {...b.props}
          onStopResize={(event) => {
            onResizePanel(event, {
              type: UPDATE,
              panel: b,
              dataPath: newDataPath,
            });
          }}
        >
          {renderPanel(b, newDataPath, pOrientation)}
        </ReflexElement>,
      );
      if (index !== layout.length - 1) {
        a.push(<ReflexSplitter key={`splitter_${b.id}`} propagate />);
      }
      return a;
    }, []);
    return <ReflexContainer {...containerProps}>{elements}</ReflexContainer>;
  };

  // 处理layout,增加direction
  const handleDirection = (panels: any[]) => {
    let hasCollapse = false;
    // eslint-disable-next-line @typescript-eslint/prefer-for-of
    for (let i = 0; i < panels.length; i++) {
      let item = panels[i];
      item.props && Reflect.deleteProperty(item.props, 'lock');
      if (panels.length !== 1) {
        // 增加direction属性，用于面板折叠
        set(item, 'props.direction', [1, -1]);
      }
      let size = get(item, 'props.size');
      if (size) {
        hasCollapse = true;
      }
      if (item.panels) {
        if (size) {
          // 如果有子panels，则自身不能设置size属性，应该让子panels来设置
          delete item.props.size;
          set(item, 'props.flex', item.props.oldFlex);
        }
        handleDirection(item.panels);
      }
    }
    // 如果panels存在折叠面板，则剩下的panels均分flex
    if (hasCollapse) {
      let count = 0;
      let p;
      // eslint-disable-next-line @typescript-eslint/prefer-for-of
      for (let i = 0; i < panels.length; i++) {
        let item = panels[i];
        if (!get(item, 'props.size')) {
          delete item.props.flex;
          count++;
          p = item;
        }
      }
      if (count === 1) {
        set(p, 'props.lock', true);
      }
    }
  };
  handleDirection(layoutData);

  return (
    <div
      className={`${workbenchData.id}`}
      style={{ height: `${(workbenchData.height || 1) * 100}%` }}
    >
      {renderLayout(layoutData, props.dataPath, props.layout.props, 'horizontal')}
    </div>
  );
};

export default Layout;
