export default {
  layouts: [
    {
      id: 'row-1',
      props: {
        flex: 0.5,
      },
    },
    {
      id: 'row-2',
      props: {
        flex: 0.5,
      },
    },
  ],
};
