export { default as layout_1 } from './layout_1';
export { default as layout_2 } from './layout_2';
export { default as layout_3 } from './layout_3';
export { default as up_down } from './up_down';
export { default as left_right } from './left_right';
export { default as split_three } from './split_three';
export { default as split_four } from './split_four';
export { default as split_six } from './split_six';
