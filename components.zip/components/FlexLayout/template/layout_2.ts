export default {
  layouts: [
    {
      id: 'row-1',
      props: {
        flex: 0.5,
      },
    },
    {
      id: 'row-2',
      props: {
        orientation: 'vertical',
        flex: 0.5,
      },
      panels: [
        {
          id: 'row-2-column-1',
          props: {
            flex: 1 / 3,
          },
        },
        {
          id: 'row-2-column-2',
          props: {
            flex: 1 / 3,
          },
        },
        {
          id: 'row-2-column-3',
          props: {
            flex: 1 / 3,
          },
        },
      ],
    },
  ],
};
