export default {
  props: {
    orientation: 'vertical',
  },
  layouts: [
    {
      id: 'column-1',
      props: {
        flex: 0.5,
      },
    },
    {
      id: 'column-2',
      props: {
        flex: 0.5,
      },
    },
  ],
};
