export default {
  props: {
    orientation: 'vertical',
  },
  layouts: [
    {
      id: 'row-1',
      props: {
        flex: 0.5,
      },
      panels: [
        {
          id: 'row-1-row-1',
          props: {
            flex: 0.5,
          },
        },
        {
          id: 'row-1-row-2',
          props: {
            flex: 0.5,
          },
        },
      ],
    },
    {
      id: 'row-2',
      props: {
        flex: 0.5,
      },
    },
  ],
};
