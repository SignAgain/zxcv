/**
 * 清空当前 panel 中激活组件配置项
 * @param panel
 * @returns
 */
export default function clearActiveMenu(panel: any) {
  if (!panel) {
    return;
  }
  Reflect.deleteProperty(panel, 'activeMenuName');
  Reflect.deleteProperty(panel, 'activeMenuId');
  Reflect.set(panel, 'menus', []);
  Reflect.deleteProperty(panel, 'componentParams');
}
