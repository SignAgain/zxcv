/* eslint-disable no-case-declarations */
import { Alert } from '@gza/quantex-design';
import { set, get, cloneDeep, isArray, assign } from 'lodash';
import { IWorkbenchData, IAction } from '../interface';
import {
  ADD_TOP,
  ADD_BOTTOM,
  ADD_LEFT,
  ADD_RIGHT,
  UPDATE,
  BATCH_UPDATE,
  CLOSE,
  DELETE,
} from './constants';
import clearActiveMenu from './clearActiveMenu';

/**
 * 生成一个空白块
 */
const _generateBlankPanel = () => {
  return {
    id: `layout-item-${new Date().getTime()}`,
  };
};

/**
 * 根据操作类型更新数据
 * @param param IAction
 */
export default function updateWorkbench(
  source: IWorkbenchData,
  { type, panel, dataPath, batch }: IAction,
) {
  try {
    const result = cloneDeep(source); // TODO 考虑使用 immutable
    const copyDataPath = dataPath.slice();
    const lastIndex = copyDataPath.pop() || 0; // 最后一个是 index
    const updateParentData = get(result, copyDataPath); // 更新节点的父层对象
    switch (type) {
      // 更新操作，主要场景是往已有面板里添加组件
      case UPDATE:
        set(updateParentData, lastIndex, panel);
        break;
      // 批量更新操作, 主要场景是 resize 面板后会触发多个面板 flex 值的修改动作
      case BATCH_UPDATE:
        if (isArray(batch)) {
          batch.forEach((action) => {
            const index = action.dataPath.pop() || 0;
            const pData = get(result, action.dataPath); // 更新节点的父层对象
            // TODO 优化短时间内多个布局更新结果后再一齐更新
            set(pData, index, action.panel);
          });
        }
        break;
      // 关闭组件
      case CLOSE:
        const config = {
          workbenchId: result.id,
          layoutItemId: panel.id,
        };
        Reflect.deleteProperty(panel, 'url');
        Reflect.deleteProperty(panel, 'name');

        // 删除工作台面板组件时，需要同时删除组件参数缓存，主要是避免后续用户再点击保存时，出现组件不存在但组件参数存在的情况
        Reflect.deleteProperty(panel, 'componentParams');
        window.globalStore.delWorkbenchComParams(config);
        set(updateParentData, lastIndex, panel);
        break;
      // 删除
      case DELETE:
        let delLevel = dataPath.filter((path) => path === 'panels').length;
        if (delLevel === 0) {
          Alert.info('已达到最小可删除层级, 无法删除');
          return result;
        }
        /**
         * 重置父节点数据：恢复到初始未添加面板(panels)和组件时的状态
         */
        const resetParentData = () => {
          const lastIndex = copyDataPath.pop() || 0; // panels
          const pData = get(result, copyDataPath);
          if (pData?.panels) {
            Reflect.deleteProperty(pData, 'panels');
          }
          // 清空pData
          if (pData?.activeMenuName) {
            clearActiveMenu(pData);
          }
          return {
            lastIndex,
            pData,
          };
        };
        const deleteFn = (data: any, index: number | string, moveEle?: any) => {
          if (data.layouts) {
            return;
          }
          // 判断删除元素是否有兄弟元素
          if (isArray(data) && data.length > 1) {
            // 有兄弟元素则将兄弟元素等比划分空间
            if (!moveEle) {
              data.splice(Number(index), 1);
              if (data.length === 1) {
                // 第二种情况，兄弟节点数只有一个
                // 这种情况要把剩下的这个兄弟节点往上层移动，避免出现层级嵌套过深
                const { props, ...brother } = data[0];
                const { pData, lastIndex: pIndex } = resetParentData();
                deleteFn(pData, pIndex, brother);
              } else {
                // 第一种情况，兄弟节点数大于一个
                data.forEach((item: any) => {
                  set(item, 'props.flex', undefined);
                  // set(pData, 'props.orientation', undefined);
                });
              }
            } else {
              assign(data[index], moveEle);
            }
          } else {
            // 第三种情况，无兄弟节点，尝试找上层的 panels
            const { pData, lastIndex: pIndex } = resetParentData();
            deleteFn(pData, pIndex, moveEle);
          }
        };
        deleteFn(updateParentData, lastIndex);
        break;
      // 拆分
      case ADD_TOP:
      case ADD_BOTTOM:
      case ADD_LEFT:
      case ADD_RIGHT:
      default:
        let level = dataPath.filter((path) => path === 'panels').length;
        if (++level > 3) {
          Alert.info('当前面板已达到最大可拆分层级, 不可继续拆分');
          return result;
        }
        const updateItem = get(result, dataPath);
        const originUpdate = cloneDeep(updateItem);
        Reflect.deleteProperty(updateItem, 'url');
        set(originUpdate, 'props.flex', undefined);
        set(
          updateItem,
          'props.orientation',
          type === ADD_LEFT || type === ADD_RIGHT ? 'vertical' : 'horizontal',
        );
        set(
          updateItem,
          'panels',
          type === ADD_TOP || type === ADD_LEFT
            ? [_generateBlankPanel(), originUpdate]
            : [originUpdate, _generateBlankPanel()],
        );
    }
    return result;
  } catch (error) {
    console.log('发生错误，无法修改数据源', error);
    return source;
  }
}
