import { debounce } from 'lodash';
import { DBUtil, msgCenter } from '@gza/quantex-utils';
import { IWorkbenchData } from '../interface';
import { TABLE_NAME, RELOAD_WORKBENCH_LIST } from './constants';
import layouts from 'layouts';

export async function saveWorkbenchWithoutDebounce(workbenchData: IWorkbenchData) {
  // 保存之前提供hooks钩子，如果返回false，则不执行保存操作
  const flag = await layouts.main.beforeSaveWorkbench(workbenchData);
  if (!flag) {
    return;
  }
  const dbUtils = DBUtil.wrapperTableName(TABLE_NAME);
  const data: any = await dbUtils.getDataByKey(workbenchData.id);
  if (data && data.id) {
    await dbUtils.updateData({
      id: data.id,
      config: workbenchData,
    });
  } else {
    await dbUtils.insertData({
      id: workbenchData.id,
      config: workbenchData,
    });
  }
  // 更新或者添加后都刷新工作台列表
  msgCenter.publish(RELOAD_WORKBENCH_LIST, workbenchData);
}

export default debounce(saveWorkbenchWithoutDebounce, 800);
