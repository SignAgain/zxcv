import { DBUtil } from '@gza/quantex-utils';
import { TABLE_NAME } from './constants';

export default async function getWorkbenchList() {
  const dbUtils: any = DBUtil.wrapperTableName(TABLE_NAME);
  const data = await dbUtils.queryData();
  if (!data) return [];
  return data.map((item: any) => item.config);
}
