import { IWorkbenchData, ILayoutItem } from '../interface';
/**
 * 根据 panelId 获取对应的 panel 数据
 * @param panelId 面板 id
 * @param workbenchData 面板所在工作台数据
 * @returns
 */
export default function getPanel(panelId: string, workbenchData: IWorkbenchData) {
  let panel = null;
  const exec = (panels: ILayoutItem[]) => {
    for (let item of panels) {
      if (!item.panels) {
        if (item.id === panelId) {
          panel = item;
          break;
        }
      } else {
        exec(item.panels);
      }
    }
  };
  exec(workbenchData?.tabs[0].layouts as ILayoutItem[]);

  return panel;
}
