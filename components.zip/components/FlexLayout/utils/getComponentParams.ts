function getComponentParams(panel: any, id: number | string) {
  for (let menu of panel?.menus || []) {
    if (menu.id === Number(id)) {
      return menu.componentParams;
    }
  }
}

export default getComponentParams;
