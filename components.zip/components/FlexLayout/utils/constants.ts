// 定义更新数据类型
export const ADD_TOP: string = 'ADD_TOP';
export const ADD_BOTTOM: string = 'ADD_BOTTOM';
export const ADD_LEFT: string = 'ADD_LEFT';
export const ADD_RIGHT: string = 'ADD_RIGHT';
export const CLOSE: string = 'CLOSE';
export const DELETE: string = 'DELETE';
export const UPDATE: string = 'UPDATE';
export const BATCH_UPDATE: string = 'BATCH_UPDATE';
// 存储表名
export const TABLE_NAME: string = 'new_workbench_table';
// 事件名
export const RELOAD_WORKBENCH_LIST: string = 'reload_workbench_list'; // 刷新列表

export const AUTO_SAVE_WORKBENCH_COM_PARAMS: string = 'auto_save_workbench_com_params'; // 自动保存组件参数

export const HEADER_HEIGHT = 34;
