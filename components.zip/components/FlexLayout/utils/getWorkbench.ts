/*
 * @Author: jingsheng.wang jingsheng.wang@iquantex.com
 * @Date: 2024-05-25 21:24:18
 * @LastEditors: jingsheng.wang jingsheng.wang@iquantex.com
 * @LastEditTime: 2024-05-25 22:00:29
 * @FilePath: /quantex-scaffold/app/components/FlexLayout/utils/getWorkbench.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { DBUtil } from '@gza/quantex-utils';
import * as template from '../template';
import { FlexLayoutProps, CreateConfig } from '../interface';
import { TABLE_NAME } from './constants';
import saveWorkbench from './saveWorkbench';
import appWindow from '@/common/appWindow';

function _getDefaultWorkbench() {
  return {
    id: `layout-${new Date().getTime()}`, // uuid(时间戳)
    name: '工作台', // 工作台名称
    userCode: 'admin', //
    type: 'system', // 如果是 system， 则认为是系统工作台(系统场景)
    isDefaultOpen: false, // 是否默认打开
    tabs: [template.up_down],
  };
}

async function _getLayoutsFromDB(id: string) {
  const dbUtils = DBUtil.wrapperTableName(TABLE_NAME);
  const data: any = await dbUtils.getDataByKey(id);
  return data?.config;
}

async function _generateWorkbenchFromCreateConfig(createConfig: CreateConfig) {
  // 先查询下是否已保存过当前创建的布局
  const layout = await _getLayoutsFromDB(createConfig.id);
  // 保存过则直接返回保存过的布局
  if (layout) {
    return layout;
  }
  // 如果未保存过则创建一个新的布局
  if (createConfig.type === 'blank') {
    const templateTab = {
      ...template[createConfig.templateId],
      id: `tab-${new Date().getTime()}`,
    };
    const newLayout = {
      id: createConfig.id,
      name: createConfig.name, // 工作台名称
      layoutType: createConfig.layoutType, // custom or default
      userCode: appWindow.localStore.getItem('userCode'),
      type: createConfig.workbenchType, // 如果是 system, 则认为是系统工作台(系统场景)
      isDefaultOpen: !!createConfig.isDefault, // 是否默认打开
      autoSaveComParams: !!createConfig.autoSaveComParams, // 是否自动保存参数
      height: createConfig.height,
      tabs: [templateTab],
    };
    await saveWorkbench(newLayout as any);
    return newLayout;
  }
  return {}; // TODO 支持系统场景
}

/* 从props中取数据: 新窗口打开 or tab栏渲染 */
function _getIdFromProps(props: FlexLayoutProps) {
  return props.match ? props.match.params.id : props.id;
}

export default async function getWorkbench(props: FlexLayoutProps) {
  const id = _getIdFromProps(props);
  if (id) {
    return await _getLayoutsFromDB(id);
  } else if (props.createConfig) {
    return await _generateWorkbenchFromCreateConfig(props.createConfig);
  }
  return _getDefaultWorkbench();
}
