import appWindow from '@/common/appWindow';
import { API } from '@gza/quantex-utils';

export default function getComponentMenu() {
  const api = new API('auth');
  const { code } = appWindow.userLocalStore.getItem('userInfo') || {}; // 获取用户数据
  return api.get('/api/v1/users/{code}/menus', {
    code: code,
    appId: process.env.APP_ID,
  });
}
