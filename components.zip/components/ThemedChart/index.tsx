import * as React from 'react';
import { v4 as uuidV4 } from 'uuid';
import { Chart } from '@gza/quantex-design';
import { registerChartTheme, ChartComponentProps } from '@gza/quantex-design/es/Chart';
import { msgCenter } from '@gza/quantex-utils';
import { Theme } from '@/types';

type themeConfig = Omit<Theme, 'path'>;

export interface IThemedChartProps extends ChartComponentProps {
  themes?: themeConfig[];
}

interface IThemedChartState {
  theme: string;
}

class ThemedChart extends React.Component<IThemedChartProps, IThemedChartState> {
  chartID: string;
  valideThemeIDsSet: Set<string>;
  isComponent: boolean;
  msgListener: any;

  constructor(props: IThemedChartProps) {
    super(props);
    this.chartID = `chart-${uuidV4()}`;
    this.valideThemeIDsSet = new Set<string>();
    this.isComponent = Array.isArray(this.props.themes) && this.props.themes.length > 0;
    this.themesRegister();
    this.state = {
      // 获取当前主题
      theme: window.getCurrentTheme() || 'themeDark',
    };
  }

  // 根据配置文件注册主题
  themesRegister = () => {
    const themes: any[] = this.props.themes || (process.env.THEMES as any) || [];
    themes.forEach((theme) => {
      const { id, chartConfig } = theme || {};
      if (!id || !chartConfig) {
        return;
      }
      // isComponent: true => 通过props传入themes，是具体的业务级别组件
      // isComponent: false => 使用process.env.THEMES，是项目级别配置文件
      const chartIdentity = this.isComponent ? `${this.chartID}-${id}` : id;
      // 注册有效主题
      registerChartTheme(chartIdentity, chartConfig);
      // 保存有效主题id
      this.valideThemeIDsSet.add(chartIdentity);
    });
  };

  finalTheme = (themeStr: string) => (this.isComponent ? `${this.chartID}-${themeStr}` : themeStr);

  msgCallback = (event: any) => {
    const { data } = event || {};
    const { type, theme: changedTheme } = data || {};
    if (type !== 'switchTheme') {
      return;
    }
    if (
      this.state.theme !== changedTheme &&
      this.valideThemeIDsSet.has(this.finalTheme(changedTheme))
    ) {
      this.setState({ theme: changedTheme });
    }
  };

  componentDidMount() {
    // 1. 微应用中监听主题的变化
    this.msgListener = msgCenter.subscribe('switch-theme', (_topic, { theme: changedTheme }) => {
      if (
        this.state.theme !== changedTheme &&
        this.valideThemeIDsSet.has(this.finalTheme(changedTheme))
      ) {
        this.setState({ theme: changedTheme });
      }
    });

    // 2. 子应用(iframe)中监听主题变化
    window.addEventListener('message', this.msgCallback, false);
  }

  componentWillUnmount() {
    // 清理
    msgCenter.unsubscribe(this.msgListener);
    window.removeEventListener('message', this.msgCallback);
  }

  render() {
    return <Chart {...this.props} theme={this.finalTheme(this.state.theme)} />;
  }
}

export default ThemedChart;
