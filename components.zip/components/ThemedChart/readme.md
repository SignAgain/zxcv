# ThemedChart

## WHAT:

基于 quantex-design chart 的二次封装，增加主题自动切换功能。

## WHY:

0. 主题变化是 echart 根据不同主题进行相应地配置
1. echart 的主题是通过配置文件的方式进行设置
1. 使用 ** css varibles/css 样式覆盖** 的方式不能满足对 echart 主题的配置要求

## WHERE TO USE IT

在需要针对不同主题进行定制 echarts 时使用。

## HOW TO USE IT

1. 使用方式和 quantex-design chart 一样
2. 具体请看 pages/QuantexExamples/ThemedCharts

### 如何定制自己的主题

#### 1. 默认 chart 主题配置在 config/config.ts 中进行配置

```js
const darkChart = require('../packages/quantex-plugin-theme-dark/chart.js');
const whiteChart = require('../packages/quantex-plugin-theme-white/chart.js');
```

#### 2. 定制化配置 **项目** chart 主题

1. 使用默认主题

```js
  // 项目config/config.ts
  themeConfig: {
    defaultTheme: 'themeDark',
    mainTheme: 'themeDark',
    themes: [
      {
        name: '深色',
        id: 'themeDark',
        path: '@gza/quantex-plugin-theme-dark',
        // 使用默认主题中的配置文件
        chartConfig: '@gza/quantex-plugin-theme-dark/chart.js',
      },
      {
        name: '浅色',
        id: 'themeWhite',
        path: '@gza/quantex-plugin-theme-white',
        // 使用默认主题中的配置文件
        chartConfig: '@gza/quantex-plugin-theme-white/chart.js',
      },
    ],
  },
```

2.  自定义主题

如何可视化定制自己想要的主题：[theme-builder](https://echarts.apache.org/zh/theme-builder.html)

    1. 需要拷贝默认主题，并在默认主题基础上修改
       ```js
       // 例如：拷贝默认主题到config目录中，并重命名为darkChart.js/whiteChart.js
       // ./config 目录结构如下
       // └── config.ts
       // └── darkChart.js
       // └── whiteChart.js
       // 在darkChart.js/whiteChart.js 中可修改相应配置文件
       ```
    2. config.ts 中引入 并配置

       ```js
         const darkChart = require('./darkChart.js');
         const whiteChart = require('./whiteChart.js');
         // ....
         // 项目config/config.ts
         themeConfig: {
           defaultTheme: 'themeDark',
           mainTheme: 'themeDark',
           themes: [
             {
               name: '深色',
               id: 'themeDark',
               path: '@gza/quantex-plugin-theme-dark',
               // 使用默认主题中的配置文件
               chartConfig: darkChart,
             },
             {
               name: '浅色',
               id: 'themeWhite',
               path: '@gza/quantex-plugin-theme-white',
               // 使用默认主题中的配置文件
               chartConfig: whiteChart,
             },
           ],
         },
       ```

#### 3. 定制化配置 **具体业务** 组件 chart 主题

1. 需要拷贝默认主题，并在默认主题基础上修改

   ```js
   // 例如：拷贝默认主题到具体业务目录(例如：pages/ExamChart)中，并重命名为darkChart.js/whiteChart.js
   // ./ExamChart 目录结构如下
   // └── index.scss
   // └── index.ts
   // └── darkChart.js
   // └── whiteChart.js
   // 在darkChart.js/whiteChart.js 中可修改相应配置文件
   ```

2. ExamChart/index.ts 中引入 并配置

   ```js
   import Chart from '@/components/ThemedChart';
   const darkChart = require('./darkChart.js');
   const whiteChart = require('./whiteChart.js');
   // ....
   // 保持和项目中config/config.ts/themeConfig/themes 一致，其中path可以不填，id, chartConfig 必填
   <Chart
     option={option}
     themes={[
       {
         // 可选
         name: '深色',
         // 必选
         id: 'themeDark',
         // 必选
         chartConfig: darkChart,
       },
       {
         // 可选
         name: '浅色',
         // 必选
         id: 'themeWhite',
         // 必选
         chartConfig: whiteChart,
       },
     ]}
   />;
   // 具体应用例子：quantex-scaffold/app/pages/QuantexExamples/ThemedCharts
   ```
