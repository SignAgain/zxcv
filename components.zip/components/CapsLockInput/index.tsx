import React, { useState } from 'react';
import { Input, Tooltip } from 'antd';
import { InputProps } from 'antd/es/input';
import { WarningFilled } from '@ant-design/icons';
import './index.less';

/**
 * 提供输入框大写校验并提示的功能
 * 此实现方案受限各浏览器事件行为不同，目前以 chrome 为准来实现
 * Chrome
 *  capslock 'off' only fire keyUp
 *  capslock 'on' only fire keyDown
 * FileFox
 *  capslock 'on/off' both fire keyDown
 */

interface ICapsLockInputProps extends InputProps {
  capsLockTooltipTitle?: string;
}

const CapsLockInput = (props: ICapsLockInputProps) => {
  const { capsLockTooltipTitle = '大写锁定已打开', ...rest } = props;

  const [capsLock, setCapsLock] = useState(false);

  const handleKeyUp = (e: any) => {
    const lockValue = e.getModifierState('CapsLock');
    setCapsLock(lockValue);
  };

  const handleKeyDown = (e: any) => {
    const lockValue = e.getModifierState('CapsLock');
    setCapsLock(lockValue);
  };

  /**
   * 失去焦点时不再显示 capslock 状态图标
   */
  const handleBlur = () => {
    setCapsLock(false);
  };

  return (
    <Input
      {...rest}
      suffix={
        capsLock ? (
          <Tooltip title={capsLockTooltipTitle} open>
            <WarningFilled />
          </Tooltip>
        ) : (
          <span />
        )
      }
      onKeyUp={handleKeyUp}
      onKeyDown={handleKeyDown}
      onBlur={handleBlur}
    />
  );
};

export default CapsLockInput;
