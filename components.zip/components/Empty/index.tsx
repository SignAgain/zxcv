import React from 'react';
import { Empty as AntdEmpty } from 'antd';
import { EmptyProps } from 'antd/es/empty';
import ImsIcon from '@/common/ImsIcon';

const Empty = (props: EmptyProps) => {
  const { image, ...rest } = props;
  return (
    <AntdEmpty
      image={
        image || (
          <ImsIcon
            type="gza-icon-box"
            style={{ fontSize: '64px', color: '#434752', opacity: 0.3 }}
          />
        )
      }
      {...rest}
    />
  );
};

export default Empty;
