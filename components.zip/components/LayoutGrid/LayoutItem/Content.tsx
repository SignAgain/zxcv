import React, { memo, useRef, useState, useContext } from 'react';
import classNames from 'classnames';
import FlexLayoutContext from '@/components/FlexLayout/components/Context';
import { IContextValue } from '../interface';
import pageMap from '@/containers/pagemap';
import styles from './index.scss';

const Content = memo((props: any) => {
  const comRef = React.useRef();
  const componentParamsFirst = useRef(props?.componentParams || {}); // 首次加载时页面组件的参数
  const [hasComponent, setHasComponent] = useState(false);
  const { workbenchData }: IContextValue = useContext(FlexLayoutContext);
  // const workbenchData = { id: 'layout_grid_1711177425893'};
  const { componentMenu = [] } = props;

  const iFrameLoad = (id: string, appId?: string) => {};

  const renderTabContent = (menu: any) => {
    let { url } = menu;
    if (!url) {
      if (hasComponent) {
        // 组件不存在时，置 false
        setHasComponent(false);
      }
    }

    // if (!componentMenu.some((item: any) => item.url === menu.url)) {
    //   return <div>抱歉，您没有当前组件权限</div>;
    // }
    if (url.includes(':') || url.startsWith('/iframe')) {
      // 如果路径匹配到的是可直接访问链接,则返回 iframe
      if (url.startsWith('/iframe')) {
        // 通过服务端来重定向到指定访问链接
        url += `&theme=${window.getCurrentTheme()}`;
        if (!url.includes('isInWorkbench')) {
          url += `&isInWorkbench=true`;
        }
        // 将workbenchId和layoutItemId拼接到url上
        if (!url.includes('workbenchId')) {
          url += `&workbenchId=${workbenchData.id}&layoutItemId=${props.panelId}`;
        }
      }
    }

    const contentCls = classNames({
      // [styles.hide]: menu.url !== activeKey, // TODO 多 tab 支持
      [styles.content]: true,
      'ag-calc-height-wrapper': true,
    });
    // 将workbenchId和layoutItemId传递给组件
    const tabProps = {
      workbenchId: workbenchData.id,
      layoutItemId: props.panelId,
      isInWorkbench: true,
      linkageValue: props.linkageValue || 'white',
      componentParams: componentParamsFirst.current, // 保证第一次渲染组件时的组件参数，确保组件参数的传递是不变的
    };
    let path = url;
    let TabContent;
    if (pageMap.has(url)) {
      let Component = pageMap.get(url);
      TabContent = (
        <div key={menu.url} className={contentCls}>
          <Component ref={comRef} {...tabProps} />
        </div>
      );
      if (!hasComponent) {
        // 组件存在时，置 true
        setHasComponent(true);
      }
    } else {
      // path = redirectUrl(url);
      path = url;
      if (!path) {
        TabContent = pageMap.get(`${process.env.APP_ID}/Notfound`);
      } else {
        const newParams = new URLSearchParams({
          componentParams: JSON.stringify(componentParamsFirst.current),
          linkageValue: props.linkageValue,
        });
        const appId = window.getUrlParams(url).appId;
        path = `${path}&${newParams.toString()}`;
        TabContent = (
          <div key={menu.url} className={contentCls}>
            <iframe
              id={props.panelId}
              onLoad={() => iFrameLoad(props.panelId, appId)}
              data-app-id={appId}
              data-linkage-value={props.linkageValue}
              data-layout-item-id={tabProps.layoutItemId}
              className={styles.iframe}
              style={{ background: 'transparent' }}
              src={path}
            />
          </div>
        );
      }
    }
    return TabContent;
  };

  return (
    <div className={styles['content-wrapper']}>
      {componentMenu.map((menu: any) => {
        return renderTabContent(menu);
      })}
    </div>
  );
});

export default Content;
