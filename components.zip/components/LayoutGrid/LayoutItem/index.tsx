import React, { useState } from 'react';
import { v4 as uuidV4 } from 'uuid';
import Content from './Content';
import HeaderMenu from './Header';
import { IDataPath, ILayoutItem, IComponentMenu } from '../interface';
import classNames from 'classnames';
import styles from './index.scss';

interface LayoutItemProps {
  componentParams: any;
  linkageValue: string;
  dataPath: IDataPath;
  panel: ILayoutItem;
  match?: any;
  pOrientation?: string;
  className: string;
  customize: string;
  headerProps: any;
  title?: string;
  panelId: string;
  url?: string;
  activeId: string;
  componentMenu: IComponentMenu;
  layoutId: string;
}

const LayoutItem: React.FC<LayoutItemProps> = (props) => {
  const [comkey, setComKey] = useState(`panel-${new Date()}`);
  const [activeId, setActiveId] = useState(props.activeId);
  const { className, customize, componentMenu, ...headerProps } = props;

  const layoutItemCls = classNames({
    [styles['layout-item-wrapper']]: true,
    'js-table-id-prefix': true,
  });

  const onRefresh = () => {
    comkey && setComKey(`layout-panel-${uuidV4()}`);
  };

  return (
    <div className={layoutItemCls} id={`${props.panelId}`}>
      <HeaderMenu {...headerProps} onRefresh={onRefresh} />
      {/* <CompMenu componentMenu={componentMenu} activeId={activeId} /> */}
      <Content
        key={comkey}
        {...props}
        layoutId={props.layoutId}
        activeId={activeId}
        componentMenu={componentMenu}
        url={props?.url || ''}
        panelId={props.panelId}
      />
    </div>
  );
};

export default LayoutItem;
