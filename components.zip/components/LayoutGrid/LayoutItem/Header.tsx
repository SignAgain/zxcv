import React, { useEffect, useState, memo } from 'react';
import { Popconfirm } from 'antd';
import classNames from 'classnames';
import {
  PlusOutlined,
  MinusOutlined,
  FullscreenOutlined,
  BarsOutlined,
  RedoOutlined,
} from '@ant-design/icons';
import { ActType } from '../interface';
import { utils } from '@gza/quantex-design';

import styles from './index.scss';

const iconStyle = {
  fontSize: '12px',
};

interface LayoutItemProps {
  match?: any;
  updateMenu?: (type: string) => void;
  panelId: string;
  title?: string;
  expand?: boolean;
  linkageValue?: string; // 通道信息
  onRefresh?: () => void;
}

const HeaderMenu: React.FC<LayoutItemProps> = memo((props) => {
  const { expand = true } = props;

  useEffect(() => {
    return () => {};
  }, []);
  const [isMoreMenuVisible, setIsMoreMenuVisible] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  useEffect(() => {
    const f = () => {
      setIsFullscreen(utils.fullScreen.getFullScreenStatus());
    };
    document.addEventListener('fullscreenchange', f);
    return () => {
      document.removeEventListener('fullscreenchange', f);
    };
  }, []);
  // fullscreen 相关
  const changeFullscreen = () => {
    if (isFullscreen) {
      utils.fullScreen.exit();
    } else {
      const el: any = document.querySelector(`#${`${props.panelId}`}`);
      utils.fullScreen.makeNodeFullScreen(el, true);
    }
  };

  let timeout: any = null;
  const toggleMoreMenu = (bool: boolean) => {
    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => {
      setIsMoreMenuVisible(bool);
    }, 100);
  };

  const iconCls = classNames({
    [styles['menu-icon']]: true,
    'hover-primary': true,
  });
  const moreMenuItemCls = classNames({
    [styles['menu-more-item']]: true,
    'hover-border-primary': true,
    'hover-modal-bg': true,
  });

  const isNewWindow = !!props.match;

  return (
    <div className={`${styles.header} layout-workbench-bg-header`}>
      {/* {props.activeMenuName && ( */}
      <div className={`${styles['header-title']}`}>
        <span className={styles['sub-title']}>{props.title}</span>
      </div>
      {/* )} */}
      <div className={`${styles['tab-group']} collapse-col-title`} />
      {isNewWindow ? null : (
        <div
          className={styles['menu-group']}
          onMouseDown={(e) => {
            e.stopPropagation();
          }}
        >
          {expand ? (
            <MinusOutlined
              onClick={() => props.onZoomOut(props.panelId)}
              className={iconCls}
              style={iconStyle}
            />
          ) : (
            <PlusOutlined
              onClick={() => props.onZoomIn(props.panelId)}
              className={iconCls}
              style={iconStyle}
            />
          )}
          <FullscreenOutlined onClick={changeFullscreen} className={iconCls} style={iconStyle} />
          <RedoOutlined onClick={props.onRefresh} className={iconCls} style={iconStyle} />
          <BarsOutlined
            onMouseEnter={() => {
              toggleMoreMenu(true);
            }}
            onMouseLeave={() => {
              toggleMoreMenu(false);
            }}
            className={iconCls}
            style={iconStyle}
          />
          <div
            onMouseEnter={() => {
              toggleMoreMenu(true);
            }}
            onMouseLeave={() => {
              toggleMoreMenu(false);
            }}
            className={`${styles['menu-more']} layout-workbench-bg-header ${
              isMoreMenuVisible ? '' : styles.hide
            }`}
          >
            <span
              onClick={() => {
                props.updateMenu?.(ActType.UPDATE);
              }}
              className={moreMenuItemCls}
            >
              修改组件
            </span>
            <Popconfirm
              title="确定删除该面板?"
              placement="topRight"
              trigger={['hover', 'click']}
              mouseEnterDelay={300}
              onConfirm={() => props.onDelete(props.panelId)}
            >
              <span className={moreMenuItemCls}>删除面板</span>
            </Popconfirm>
          </div>
        </div>
      )}
    </div>
  );
});

export default HeaderMenu;
