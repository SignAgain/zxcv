import React, { useEffect, useRef, useState, useContext } from 'react';
import { observer } from 'mobx-react';
import { reject, find } from 'lodash';
import { Avatar } from 'antd';
import { Modal } from 'quantex-design';
import classNames from 'classnames';
import Layout from './Layout';
import styles from './index.scss';
import { AppstoreOutlined } from '@ant-design/icons';
import FlexLayoutContext from '@/components/FlexLayout/components/Context';
import DrawerCard from './DrawerCard';

import { AUTO_SAVE_WORKBENCH_COM_PARAMS } from '@/components/FlexLayout/utils/constants';
import useEventCenter from '@/hooks/useEventCenter';

interface LayoutGridProps {
  modules: Record<string, unknown>;
  moduleConfig: Array<unknown>;
  className?: string;
}

const LayoutGrid: React.FC<LayoutGridProps> = ({ moduleConfig }) => {
  const [modal] = useState(new Modal.Store({ footer: null, mask: false, width: 700 }));
  const drawerCardRef = useRef<any>(null);
  const { workbenchData, updateGridWorkbench }: any = useContext(FlexLayoutContext);
  const [items, setItems] = useState<any[]>([]);
  const layoutRef = useRef(workbenchData?.layout || []);

  const layoutId = workbenchData.id;

  const onImportModules = (items: Array<unknown>) => {
    addLayoutItems(items);
    modal.close();
  };

  useEventCenter(`${AUTO_SAVE_WORKBENCH_COM_PARAMS}-${layoutId}`, (data: any) => {
    // 不设置自动保存组件参数
    if (!workbenchData.autoSaveComParams) {
      return;
    }
    const { data: _data } = data;
    autoSaveComponentParams(_data.layoutItemId, _data.componentParams);
    // 保存参数的延时状态可以在卡片内部设置, 使用 lodash 的 debounce 方法
    // if (timerRef.current) {
    //   clearTimeout(timerRef.current);
    // }

    // // 设置新的定时器，3秒后清除状态
    // timerRef.current = setTimeout(() => {
    // }, 3000);
  });

  useEffect(() => {
    setItems(workbenchData?.layout || []);
  }, []);

  useEffect(() => {
    layoutRef.current = workbenchData.layout;
  }, [JSON.stringify(workbenchData.layout)]);

  const rootCls = classNames({
    [styles.root]: true,
    'qtd-layout-grid': true,
  });

  const addLayoutItems = (xitems: any[]) => {
    const oldItemsNum = items.length;
    const newItems = xitems.map((item, index) => ({
      x: ((oldItemsNum + index) * 8) % 24,
      y: Infinity,
      w: 8,
      h: 20,
      ...item,
    }));
    setItems((prevItems) => [...prevItems, ...newItems]);
  };

  const removeLayoutItem = (panelId: string) => {
    setItems((prevItems) => reject(prevItems, { panelId }));
  };

  const onZoomIn = (panelId: string) => {
    const newItems = [...items];
    const zoomItem = find(newItems, (item) => item.panelId === panelId);
    zoomItem.expand = true;
    zoomItem.h = zoomItem.cacheH;
    setItems([...newItems]);
  };

  const onZoomOut = (panelId: string) => {
    const newItems = [...items];
    const zoomItem = find(newItems, (item) => item.panelId === panelId);
    zoomItem.expand = false;
    zoomItem.cacheH = zoomItem.h;
    zoomItem.h = 1.5;
    setItems([...newItems]);
  };

  /**
   * 自动保存组件参数
   * @param layoutItemId
   * @param params
   * @returns
   */
  const autoSaveComponentParams = (layoutItemId: string, params: Object = {}) => {
    onLayoutChange(formatComponentParams(layoutItemId, params));
  };

  /**
   * 格式化组件参数
   * @param layoutItemId
   * @param params
   * @returns
   */
  const formatComponentParams = (layoutItemId: string, params: Object = {}) => {
    console.log('layoutItemId', layoutRef?.current);
    return layoutRef?.current?.map((item) => {
      const { panelId } = item;
      if (panelId === layoutItemId) {
        return {
          ...item,
          componentParams: { ...params },
        };
      }
      return { ...item };
    });
  };

  const onLayoutChange = (layout: any[]) => {
    setItems(layout);
    // 更新工作台数据
    updateGridWorkbench({
      ...workbenchData,
      layout,
    });
  };

  /**
   * 打开
   */
  const onOpen = () => {
    drawerCardRef.current.onOpen();
  };

  return (
    <div className={rootCls} id={`layout-grid-${layoutId}`}>
      <Layout
        items={items}
        // highlightItemId={undefined}
        onZoomIn={onZoomIn}
        onZoomOut={onZoomOut}
        onDelete={removeLayoutItem}
        onLayoutChange={onLayoutChange}
        layoutId={layoutId}
      />
      <div className={styles['fixed-widgets']}>
        <Avatar onClick={onOpen} size="large" icon={<AppstoreOutlined />} />
      </div>

      <DrawerCard onImport={onImportModules} moduleConfig={moduleConfig} ref={drawerCardRef} />
      <Modal {...modal.props} />
    </div>
  );
};

export default observer(LayoutGrid);
