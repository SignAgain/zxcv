import React from 'react';
import PropTypes from 'prop-types';
import { msgCenter } from '@gza/quantex-utils';
import classNames from 'classnames';
import { Responsive, WidthProvider } from 'react-grid-layout';

import LayoutItem from './LayoutItem';
import styles from './index.scss';

require('react-grid-layout/css/styles.css');

const ResponsiveReactGridLayout = WidthProvider(Responsive);

class Layout extends React.Component {
  id = `layout-grid-${new Date().getTime()}`; // uuid(时间戳)
  renderGridItem = (el) => {
    // const { highlightItemId } = this.props;
    const shadowEl = { ...el, refreshable: true };
    // const Content = this.props.modules[el.component];
    const contentRef = shadowEl.refreshable && React.createRef();
    const layoutItemProps = {
      layoutId: this.props.layoutId,
      componentMenu: shadowEl.componentMenu,
      activeId: shadowEl.activeId,
      title: shadowEl.name,
      expand: shadowEl.expand,
      customize: shadowEl.customize,
      panelId: shadowEl.panelId,
      url: shadowEl.url,
      onDelete: (xid) => {
        this.props.onDelete(xid);
      },
      onZoomIn: (xid) => {
        this.props.onZoomIn(xid);
      },
      onZoomOut: (xid) => {
        this.props.onZoomOut(xid);
      },
      refreshable: shadowEl.refreshable,
      openable: shadowEl.openable,
      onOpen: shadowEl.onOpen,
      componentParams: shadowEl.componentParams || {},
    };

    const itemCls = classNames({
      'react-grid-item-collapse': shadowEl.expand === false,
    });
    return (
      <div key={shadowEl.i} className={itemCls}>
        <LayoutItem {...layoutItemProps}>{/** <Content {...contentProps} /> */}</LayoutItem>
      </div>
    );
  };

  onLayoutChange = (layout) => {
    this.props.onLayoutChange(
      this.props.items.map((item, index) => {
        const { i, ...assignProps } = layout[index];
        return {
          ...item,
          ...assignProps,
        };
      }),
    );
  };

  /**
   * 拖拽结束
   */
  onResizeStop = () => {
    // 拖拽结束时重新计算固定表头高度
    msgCenter.publish('fixed-table-resize');
  };

  render() {
    const { onZoomIn, onZoomOut, onDelete, items, highlightItemId, ...pureProps } = this.props;
    const layouts = items.map((item) => {
      const { title, component, ...pureItem } = item;
      return pureItem;
    });
    return (
      <ResponsiveReactGridLayout
        {...pureProps}
        id={this.id}
        margin={[2, 2]}
        autoSize
        onDrop={this.onDrop}
        layouts={{ lg: layouts }}
        className={`${styles.layout} layout`}
        draggableHandle=".collapse-col-title"
        onLayoutChange={this.onLayoutChange}
        onResizeStop={this.onResizeStop}
        measureBeforeMount={false}
        // compactType={null}
        resizeHandles={['se']}
        // allowOverlap // 允许重叠
        isDroppable={true}
        onBreakpointChange={this.onBreakpointChange}
      >
        {this.props.items.map((el) => this.renderGridItem(el))}
      </ResponsiveReactGridLayout>
    );
  }
}

Layout.propTypes = {
  items: PropTypes.array,
};

Layout.defaultProps = {
  items: [],
  cols: { lg: 24, md: 24, sm: 24, xs: 24, xxs: 24 },
  rowHeight: 17,
  containerPadding: [1, 1],
};

export default Layout;
