import React, { useState, useImperativeHandle, forwardRef, useEffect, useRef } from 'react';
import { Button, Drawer, Input, List } from 'antd';
import _ from 'lodash';
import { v4 as uuidV4 } from 'uuid';
import styles from './index.scss';
import module222 from './module.json';

interface IDrawerCardProps {
  onImport: (items: any[]) => void;
  moduleConfig: any[];
  ref: any;
}

const DrawerCard: React.FC<IDrawerCardProps> = forwardRef((props, ref) => {
  const moduleRef = useRef<any>(null);
  const [module, setModule] = useState<any[]>([]);
  const [dropModule, setDropModule] = useState({});

  useImperativeHandle(ref, () => ({
    onOpen,
    getDropModule,
  }));

  const [open, setOpen] = useState(false);
  const [selectComponent, setSelectComponent] = useState<Array<string>>([]);

  useEffect(() => {
    setModule(module222);
    moduleRef.current = module222;
  }, [JSON.stringify(module222)]);

  const getDropModule = () => {
    return dropModule;
  };

  /**
   * 卡片库渲染
   */
  const renderCardComponent = () => {
    return (
      <List
        itemLayout="horizontal"
        dataSource={module}
        renderItem={(item) => (
          <List.Item
            style={{
              backgroundColor: selectComponent.includes(item.id) ? 'var(--text-selection-bg)' : '',
            }}
            onClick={() => handleListItemClick(item)}
          >
            <List.Item.Meta
              draggable={true}
              unselectable="on"
              onDragStart={() => setDropModule(item)}
              dataItem={JSON.stringify(item)}
              title={item.name}
              description={
                <div title={item.description} className={styles['text-container']}>
                  {item.description}
                </div>
              }
            />
          </List.Item>
        )}
      />
    );
  };

  /**
   * 卡片点击事件
   */
  const handleListItemClick = (item) => {
    const curSelectComponent = [...selectComponent];
    const index = curSelectComponent.indexOf(item.id);
    if (index > -1) {
      curSelectComponent.splice(index, 1);
      setSelectComponent([...curSelectComponent]);
      return;
    }
    setSelectComponent([...selectComponent, item.id]);
  };

  /**
   * 卡片搜索
   */
  const handleSearch = _.debounce((event) => {
    const value = event.target.value;
    if (_.isNil(value)) {
      setModule(moduleRef.current);
      return;
    }
    const filterCard = moduleRef.current.filter((item) => {
      return item.name.includes(value);
    });
    setModule(filterCard);
  }, 300);

  /**
   * 关闭
   */
  const onClose = () => {
    setOpen(false);
    setSelectComponent([]);
  };

  /**
   * 打开
   */
  const onOpen = () => {
    setOpen(true);
  };

  /**
   * 导入
   */
  const handleImport = () => {
    const selectedItems = moduleRef.current.filter((item) => selectComponent.includes(item.id));
    props.onImport(
      selectedItems.map((item) => {
        return {
          name: item.name,
          componentMenu: [
            {
              ...item,
            },
          ],
          activeId: item.id,
          i: `layout-item-${uuidV4()}`,
          panelId: `layout-panel-${uuidV4()}`,
        };
      }),
    );
    // onClose();
  };

  return (
    <Drawer
      title="卡片库"
      placement="right"
      className={styles['layout-grid-drawer']}
      onClose={onClose}
      open={open}
      mask={false}
      // closeIcon={false}
    >
      <div className={styles['card-box']}>
        <header className={styles['card-header']}>
          <Input onChange={handleSearch} placeholder="请输入卡片名称进行搜索" />
        </header>
        <div className={styles['card-content']}>{renderCardComponent()}</div>
        <footer className={styles['card-footer']}>
          <Button type="primary" onClick={handleImport}>
            一键导入
          </Button>
        </footer>
      </div>
    </Drawer>
  );
});

export default DrawerCard;
