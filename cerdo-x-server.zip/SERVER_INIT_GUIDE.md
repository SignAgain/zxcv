# NestJS 企业级后端初始化指南

本指南用于指导如何从零初始化一个具备**全链路追踪、统一异常处理、统一响应封装、UPM鉴权**的标准化 NestJS 后端服务。

## 1. 技术栈说明

- **核心框架**: NestJS (v10+)
- **编程语言**: TypeScript (基于 JDK 17 / Spring Boot 3.x 架构思想设计)
- **数据库 ORM**: TypeORM + PostgreSQL
- **日志管理**: Winston (支持按天切割、TraceId 注入)
- **接口文档**: Swagger (自动生成)

## 2. 核心架构与内置功能

初始化后的 Server 默认具备以下企业级特性：

1. **全链路追踪 (TraceId)**: 基于 `AsyncLocalStorage` 实现。每个请求自动生成或继承 `x-trace-id`，并在所有日志中自动打印，无需层层传递。
2. **统一响应体 (AjaxResult)**: 基于全局拦截器 (`AjaxResultInterceptor`) 实现。Controller 只需返回核心数据，自动被包装为 `{ code, type, success, message, data, traceId }` 格式。
3. **全局异常兜底**: 基于全局过滤器 (`AjaxResultExceptionFilter`) 实现。自动捕获业务异常、系统 Error 及参数校验失败，屏蔽内部堆栈，统一返回友好的 AjaxResult 格式。
4. **UPM 统一鉴权**: 基于全局守卫 (`AuthGuard`) 实现。自动拦截请求校验 Token，支持白名单与 `@Public()` 注解免登，支持通过 `@CurrentUser()` 获取当前登录人信息。

## 3. 快速初始化步骤

### 步骤一：安装核心依赖
```bash
# 安装 NestJS 核心及常用库
npm i @nestjs/common @nestjs/core @nestjs/config @nestjs/swagger @nestjs/typeorm @nestjs/axios
npm i typeorm pg class-validator class-transformer
# 安装日志及通用工具
npm i winston winston-daily-rotate-file cookie-parser
```

### 步骤二：配置环境变量
在项目根目录创建 `.env` 文件，配置数据库与 UPM 鉴权信息：
```env
# Server Port
PORT=3000

# Database
DB_HOST=127.0.0.1
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=yourpassword
DB_DATABASE=yourdb

# UPM Auth
CERDO_UPM_BASE_URL=https://your-upm-domain.com
CERDO_UPM_APP_ID=your_app_id
CERDO_UPM_APP_SECRET=your_app_secret
CERDO_APP_API_WHITE_NAME=/api/ping,/api/health
```

### 步骤三：引入核心 CommonModule
将 `logger.ts`, `auth.ts`, `ajax-result.ts` 等核心文件放入 `src/common` 目录下，并在 `AppModule` 中全局导入 `CommonModule`：

```typescript
// app.module.ts
@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync({...}),
    CommonModule, // 引入全局拦截器、过滤器、鉴权守卫
  ],
})
export class AppModule {}
```

### 步骤四：修改 main.ts 引导程序
```typescript
// main.ts
async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });
  
  // 1. 替换默认日志器
  app.useLogger(new TraceLogger());
  // 2. 挂载 TraceId 中间件
  app.use(traceIdMiddleware); 
  // 3. 开启参数校验
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  // 4. 配置 Swagger
  SwaggerModule.setup('api/docs', app, document);
  
  await app.listen(process.env.PORT || 3000);
}
bootstrap();
```

## 4. 日常开发规范 (Best Practices)

### 4.1 编写 Controller
- **无需手动捕获异常**：直接抛出 `Error` 或 `HttpException`，全局过滤器会处理。
- **无需手动包装结果**：直接 `return data` 即可。

```typescript
@ApiTags('用户管理')
@Controller('users')
export class UserController {
  
  @Get('profile')
  @ApiOperation({ summary: '获取当前用户信息' })
  getProfile(@CurrentUser() user: UpmUserInfo) {
    // 直接返回数据，拦截器会自动包装为 AjaxResult
    return {
      userId: user.userId,
      role: 'ADMIN'
    };
  }

  @Public() // 使用此注解跳过 Token 校验
  @Get('public-info')
  getPublicInfo() {
    return "This is public";
  }
}
```

### 4.2 打印日志
在任何 Service 或 Controller 中，直接使用 NestJS 自带的 `Logger`，日志会自动带上当前请求的 `TraceId`：

```typescript
import { Logger, Injectable } from '@nestjs/common';

@Injectable()
export class UserService {
  private readonly logger = new Logger(UserService.name);

  doSomething() {
    // 输出: 2026-04-01 12:00:00 INFO [uuid-1234] [UserService] 开始处理业务...
    this.logger.log('开始处理业务...'); 
  }
}
```