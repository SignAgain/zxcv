# Trump Fullstack 后端 HTTP API 调用说明

本文档描述 `server`（NestJS）对外暴露的 HTTP 接口，与代码中 `Controller` 及 `main.ts` 配置保持一致。

---

## 1. 基础信息

| 项目 | 说明 |
|------|------|
| **Base Path（全局前缀）** | `/aifs/trump-web/api` |
| **完整 Base URL** | `http://{host}:{port}/aifs/trump-web/api` |
| **默认端口** | 环境变量 `PORT`，未配置时默认为 `3000` |
| **Swagger UI（仅非生产）** | `NODE_ENV !== 'production'` 时启用，路径为 `{origin}/aifs/trump-web/api/api/docs` |

---

## 2. 通用约定

### 2.1 全链路追踪 `traceId`

- 请求可携带请求头 **`x-trace-id`**（可选）；若未携带，服务端会生成新的 UUID。
- 成功响应体中的 **`traceId`** 与本次请求一致，便于前后端、日志对齐排查。

### 2.2 统一 JSON 响应（AjaxResult）

除 **SSE 流式接口**（见下文）外，普通 JSON 接口的返回值会被全局拦截器包装为：

```json
{
  "code": "0000",
  "type": "SUCCESS",
  "success": true,
  "message": "success",
  "tracing": "AppController#ping",
  "traceId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "data": { }
}
```

| 字段 | 说明 |
|------|------|
| `code` | 业务码，`0000` 表示成功 |
| `type` | `SUCCESS` 或 `ERROR` |
| `success` | 是否成功 |
| `message` | 提示信息 |
| `tracing` | 处理该请求的类与方法名 |
| `traceId` | 全链路追踪 ID |
| `data` | 业务数据；Controller 无返回时可能为 `null` |

**异常与校验失败**：全局异常过滤器会将错误也包装为同类结构，且 **HTTP 状态码多为 200**，通过 `success: false` 与 `code` 区分（便于前端统一拦截）。常见业务码包括：

| code | 含义（简述） |
|------|----------------|
| `0000` | 成功 |
| `AU0002` | 鉴权失败（Token 缺失或 UPM 校验失败） |
| `VAL0001` | 参数校验失败（如 class-validator） |
| `SYS0001` | 未分类的服务器内部错误 |

### 2.3 鉴权（当前实现）

- 全局 `AuthGuard` 默认要求鉴权；**本文档所列接口均在对应 Controller 上标记了 `@Public()`，当前无需 Token 即可调用**。
- 若后续某接口取消 `@Public()`，需在请求头 **`token`** 或 Cookie **`cerdo_token`** 中携带有效 Token（与 UPM 配置相关）。

### 2.4 Content-Type

- JSON 接口：请求使用 `Content-Type: application/json`（`POST` 带 body 时）。
- SSE：见各接口说明，响应为 `text/event-stream`。

---

## 3. 接口列表

以下路径均相对于 **Base Path** `/aifs/trump-web/api`。

---

### 3.1 连通性测试

**`GET /ping`**

- **说明**：存活/连通探测。
- **鉴权**：公开（`@Public()`）。

**成功时 `data` 示例**（业务数据，外层仍有 AjaxResult 包装）：

```json
{
  "message": "pong from nestjs",
  "timestamp": "2026-04-02T12:00:00.000Z"
}
```

---

### 3.2 健康检查

**`GET /health`**

- **说明**：服务健康状态与版本信息。
- **鉴权**：公开。

**成功时 `data` 示例**：

```json
{
  "status": "UP",
  "version": "x.y.z",
  "deploymentTime": "2026-04-02T08:00:00.000Z",
  "currentTime": "2026-04-02T12:00:00.000Z"
}
```

---

### 3.3 创建 Agent 会话

**`POST /agent/sessions`**

- **说明**：创建新会话，返回 `sessionId`；同时会向会话事件流发布 `session.created`（若已订阅 SSE）。
- **鉴权**：公开。
- **请求体**：无。

**成功时 `data` 示例**：

```json
{
  "sessionId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "createdAt": "2026-04-02T12:00:00.000Z"
}
```

---

### 3.4 订阅会话事件（SSE）

**`GET /agent/sessions/:sessionId/stream`**

- **说明**：按会话建立 **Server-Sent Events** 长连接，接收 Agent 运行过程事件、心跳等。**该接口不使用 AjaxResult 包装**，响应为原始 SSE 流。
- **鉴权**：公开。
- **路径参数**：`sessionId` — 须为已存在的会话 ID，否则服务端会抛错（经全局异常过滤器转为 JSON 错误体，见 §2.2）。

**响应头（要点）**

- `Content-Type: text/event-stream`
- `Cache-Control: no-cache`
- `Connection: keep-alive`

**事件格式**

每条消息为 SSE `data:` 行，值为 JSON 字符串，结构符合 `StreamClientEvent`：

| 字段 | 类型 | 说明 |
|------|------|------|
| `event_id` | string | 事件 ID |
| `sequence_num` | number | 序号 |
| `event_type` | string | 事件类型（见下表） |
| `source` | string | 事件来源（如 `session_service`、`agent_runtime` 等） |
| `payload` | object | 负载 |
| `created_at` | string | ISO 8601 时间 |

连接建立后，首条事件常为 `event_type: "stream.open"`，之后约每 **15 秒** 有心跳类事件（`session.heartbeat`）。

**`event_type` 常量（与代码 `StreamEventType` 一致）**

| event_type | 说明 |
|------------|------|
| `session.created` | 会话已创建 |
| `run.started` | 一次运行开始 |
| `llm.delta` | LLM 流式增量 |
| `tool.call` | 工具调用 |
| `tool.result` | 工具结果 |
| `run.completed` | 运行成功结束 |
| `run.failed` | 运行失败 |
| `session.heartbeat` | 心跳 |

**示例（curl）**

```bash
curl -N -H "Accept: text/event-stream" \
  "http://localhost:3000/aifs/trump-web/api/agent/sessions/{sessionId}/stream"
```

---

### 3.5 发送消息并触发 Agent 工作流

**`POST /agent/sessions/:sessionId/messages`**

- **说明**：发送用户消息；接口 **快速返回** `accepted`，实际 LLM/工具执行在后台进行，结果通过 **SSE**（§3.4）推送。
- **鉴权**：公开。
- **路径参数**：`sessionId`

**请求体（JSON）**

| 字段 | 类型 | 约束 |
|------|------|------|
| `content` | string | 必填，非空字符串（`class-validator`：`@IsString()` `@IsNotEmpty()`） |

**成功时 `data` 示例（已接受）**

```json
{
  "sessionId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "status": "accepted"
}
```

**内容被忽略时**（仅空白等极端情况与业务逻辑）：可能返回 `status: "ignored"` 及 `reason`（具体以实际响应为准），仍可能为 HTTP 200 + AjaxResult 包装。

**示例（curl）**

```bash
curl -s -X POST \
  -H "Content-Type: application/json" \
  -d "{\"content\":\"你好\"}" \
  "http://localhost:3000/aifs/trump-web/api/agent/sessions/{sessionId}/messages"
```

---

## 4. 调用顺序建议（Agent）

1. `POST /agent/sessions` 获取 `sessionId`。
2. 使用浏览器 `EventSource` 或支持 SSE 的客户端连接 `GET /agent/sessions/{sessionId}/stream`。
3. `POST /agent/sessions/{sessionId}/messages` 发送用户输入，在 SSE 中接收 `run.*`、`llm.delta`、`tool.*` 等事件直至 `run.completed` 或 `run.failed`。

---

## 5. 与自动文档的关系

非生产环境可通过 **Swagger UI** 查看 OpenAPI 描述；若与本文档有出入，**以仓库内 `*.controller.ts` 与 `main.ts` 为准**，并可将差异反馈维护者更新本文档。

---

## 6. 修订记录

| 日期 | 说明 |
|------|------|
| 2026-04-02 | 初版，基于当前 `AppController`、`AgentController` 与全局中间件/拦截器实现整理 |
