import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class AppService {
  private readonly startupTime: string;
  private readonly version: string;

  constructor() {
    this.startupTime = new Date().toISOString();
    try {
      // 使用 __dirname 相对路径，确保在 src 或 dist 目录下都能正确找到 package.json
      const packageJsonPath = path.join(__dirname, '..', '..', 'package.json');
      const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
      this.version = packageJson.version || 'unknown';
    } catch {
      this.version = 'unknown';
    }
  }

  ping() {
    return {
      message: 'pong from nestjs',
      timestamp: new Date().toISOString(),
    };
  }

  health() {
    return {
      status: 'UP',
      version: this.version,
      deploymentTime: this.startupTime,
      currentTime: new Date().toISOString(),
    };
  }
}
