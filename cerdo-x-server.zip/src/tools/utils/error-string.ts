/** 将 catch 到的未知错误转为可读字符串，避免 [object Object] */
export function formatCaughtUnknown(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (typeof e === 'object' && e !== null) {
    try {
      return JSON.stringify(e);
    } catch {
      return 'non-serializable error object';
    }
  }
  return String(e);
}
