import { Module } from '@nestjs/common';
import { TaskModule } from '../tasks/task.module';
import { LlmClient } from '../utils/llm-client';
import { BUILTIN_TOOL_PROVIDERS } from './built-in/builtin-tool.providers';
import { INFRA_BACKGROUND_PROVIDERS } from './infra/background/infra-background.providers';
import { PROTOCOL_PROVIDERS } from './protocol/protocol.providers';
import { CompressStateService } from './protocol/compress-state.service';
import { TeamProtocolService } from './protocol/team-protocol.service';
import { ToolRegistryService } from './registry/tool-registry.service';
import { WorkspaceBackgroundService } from './infra/background/workspace-background.service';

/**
 * 内置 AgentTool 注册表；与 Chat Agent、QueryEngine、AgentRuntime 共用。
 */
@Module({
  imports: [TaskModule],
  providers: [
    LlmClient,
    ...INFRA_BACKGROUND_PROVIDERS,
    ...PROTOCOL_PROVIDERS,
    ...BUILTIN_TOOL_PROVIDERS,
    ToolRegistryService,
  ],
  exports: [
    ToolRegistryService,
    TeamProtocolService,
    WorkspaceBackgroundService,
    CompressStateService,
  ],
})
export class ToolsModule {}
