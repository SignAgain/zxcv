# `src/tools` 说明

本目录承载 **Agent 可调用的内置工具（`AgentTool`）** 及其配套：注册表、协议层服务、后台执行基础设施与公共工具函数。`ToolsModule` 供 Chat Agent、`QueryEngine`、`AgentRuntime` 等共用。

## 目录结构

```
tools/
├── tools.module.ts              # Nest 模块：聚合 providers / exports
├── constants.ts                 # 工具侧常量（超时、截断等）
├── registry/                    # 注册与对外工具名列表
│   ├── tool-registry.service.ts # 工具名 → 实例；execute / listOpenAITools
│   └── builtin-tool-names.ts    # CHAT_BUILTIN_TOOL_NAMES（与 QueryEngine 对齐）
├── protocol/                    # 多工具共享的协议与状态（非「单次 tool 文件」）
│   ├── protocol.providers.ts    # PROTOCOL_PROVIDERS
│   ├── compress-state.service.ts
│   ├── skill-loader.service.ts
│   ├── team-protocol.service.ts
│   ├── todo-write-state.service.ts
│   └── todo-write.manager.ts
├── infra/                       # 运行时基础设施（与「工具实现」区分）
│   └── background/
│       ├── infra-background.providers.ts
│       ├── workspace-background.service.ts  # 按 workspace 复用 BackgroundManager
│       └── background-manager.ts            # 后台 shell 任务与通知队列
├── built-in/                    # 按能力域划分的具体工具实现
│   ├── builtin-tool.providers.ts            # 汇总 BUILTIN_TOOL_PROVIDERS
│   ├── files/         # 读 / 写 / 编辑文件
│   ├── shell/         # 终端
│   ├── background/    # background_run / check_background（工具层）
│   ├── session/       # TodoWrite、子代理、load_skill、compress 等
│   ├── tasks/         # 任务 CRUD / claim
│   └── team/          # 队友、消息、协作相关
└── utils/               # 路径安全、错误格式化、输入辅助等
    ├── workspace-safe-path.ts
    ├── error-string.ts
    └── tool-input.ts
```

## 各层职责

| 路径 | 作用 |
|------|------|
| **registry** | 集中注册所有内置工具；对外提供 `execute`、`listOpenAITools`。新增工具后需在此 `register`。 |
| **protocol** | 可被多个 `built-in` 工具注入的 Nest 服务（会话状态、团队协议、技能扫描等）。 |
| **infra/background** | 与「后台 shell」相关的**进程侧**能力：`BackgroundManager` + 按 workspace 复用的 `WorkspaceBackgroundService`；与 `built-in/background` 下的两个 **Agent 工具**配合使用。 |
| **built-in** | 实现 `AgentTool` 的类；按子域拆分，并用各域的 `*-tools.providers.ts` 导出该域的 `providers` 数组。 |
| **utils / constants** | 与具体业务无关的共用逻辑与常量。 |

## 模块装配顺序（`tools.module.ts`）

1. `LlmClient`  
2. `INFRA_BACKGROUND_PROVIDERS`  
3. `PROTOCOL_PROVIDERS`  
4. `BUILTIN_TOOL_PROVIDERS`（见 `built-in/builtin-tool.providers.ts` 中的合并顺序）  
5. `ToolRegistryService`  

对外导出：`ToolRegistryService`、`TeamProtocolService`、`WorkspaceBackgroundService`、`CompressStateService`。

## 内置工具名参考

与 `registry/builtin-tool-names.ts` 中 `CHAT_BUILTIN_TOOL_NAMES` 一致，例如：`read_file`、`bash`、`write_file`、`edit_file`、`TodoWrite`、`task`、`load_skill`、`compress`、`background_run`、`check_background`，以及 `task_*`、`spawn_teammate`、`list_teammates`、`send_message` 等（完整列表以该文件为准）。

## 新增一个内置工具的推荐步骤

1. **实现**：在 `built-in/<域>/` 下新增 `*.tool.ts`（或扩展现有 `*-agent.tools.ts`），实现 `AgentTool` 接口。  
2. **注册 Nest**：在对应域的 `*-tools.providers.ts` 中加入该类；若为新域，在 `built-in/builtin-tool.providers.ts` 中 `import` 并展开该域的 `*_TOOL_PROVIDERS`。  
3. **注册运行时**：在 `registry/tool-registry.service.ts` 的构造函数中注入并 `register`。  
4. **对外名列表**：若需被 QueryEngine 等使用，在 `registry/builtin-tool-names.ts` 的 `CHAT_BUILTIN_TOOL_NAMES` 中补充工具名（与 `AgentTool.name` 一致）。  
5. **协议依赖**：若需跨请求/会话状态，在 `protocol/` 增加或复用服务，并在 `protocol.providers.ts` 中导出。

按上述步骤即可保持目录职责清晰，并避免遗漏 DI 与注册表两处。
