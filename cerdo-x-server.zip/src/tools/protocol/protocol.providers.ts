import { CompressStateService } from './compress-state.service';
import { SkillLoaderService } from './skill-loader.service';
import { TeamProtocolService } from './team-protocol.service';
import { TodoWriteStateService } from './todo-write-state.service';

export const PROTOCOL_PROVIDERS = [
  TodoWriteStateService,
  SkillLoaderService,
  TeamProtocolService,
  CompressStateService,
] as const;
