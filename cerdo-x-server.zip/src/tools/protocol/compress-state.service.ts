import { Injectable } from '@nestjs/common';

/** 记录会话是否请求过 compress，供后续宿主扩展（例如截断历史） */
@Injectable()
export class CompressStateService {
  private readonly pending = new Set<string>();

  mark(sessionId: string): void {
    this.pending.add(sessionId);
  }

  consume(sessionId: string): boolean {
    if (!this.pending.has(sessionId)) return false;
    this.pending.delete(sessionId);
    return true;
  }
}
