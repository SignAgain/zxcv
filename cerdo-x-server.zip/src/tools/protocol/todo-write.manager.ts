/** TodoWrite 工具用的内存列表（content / status / activeForm） */
export class TodoWriteFullManager {
  private items: Array<{
    content: string;
    status: string;
    activeForm: string;
  }> = [];

  update(items: unknown): string {
    if (!Array.isArray(items)) throw new Error('items must be an array');
    const validated: typeof this.items = [];
    let ip = 0;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const rec =
        item && typeof item === 'object' && !Array.isArray(item)
          ? (item as Record<string, unknown>)
          : {};
      const content = String(rec.content ?? '').trim();
      const status = String(rec.status ?? 'pending').toLowerCase();
      const af = String(rec.activeForm ?? '').trim();
      if (!content) throw new Error(`Item ${i}: content required`);
      if (
        status !== 'pending' &&
        status !== 'in_progress' &&
        status !== 'completed'
      ) {
        throw new Error(`Item ${i}: invalid status '${status}'`);
      }
      if (!af) throw new Error(`Item ${i}: activeForm required`);
      if (status === 'in_progress') ip += 1;
      validated.push({ content, status, activeForm: af });
    }
    if (validated.length > 20) throw new Error('Max 20 todos');
    if (ip > 1) throw new Error('Only one in_progress allowed');
    this.items = validated;
    return this.render();
  }

  render(): string {
    if (!this.items.length) return 'No todos.';
    const m: Record<string, string> = {
      completed: '[x]',
      in_progress: '[>]',
      pending: '[ ]',
    };
    const lines: string[] = [];
    for (const item of this.items) {
      const mark = m[item.status] ?? '[?]';
      const suffix =
        item.status === 'in_progress' ? ` <- ${item.activeForm}` : '';
      lines.push(`${mark} ${item.content}${suffix}`);
    }
    const done = this.items.filter((t) => t.status === 'completed').length;
    lines.push(`\n(${done}/${this.items.length} completed)`);
    return lines.join('\n');
  }

  hasOpenItems(): boolean {
    return this.items.some((t) => t.status !== 'completed');
  }
}
