import { Injectable } from '@nestjs/common';
import { TodoWriteFullManager } from './todo-write.manager';

@Injectable()
export class TodoWriteStateService {
  private readonly bySession = new Map<string, TodoWriteFullManager>();

  getOrCreate(sessionId: string): TodoWriteFullManager {
    let m = this.bySession.get(sessionId);
    if (!m) {
      m = new TodoWriteFullManager();
      this.bySession.set(sessionId, m);
    }
    return m;
  }
}
