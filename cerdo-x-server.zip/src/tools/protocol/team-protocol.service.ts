import { Injectable } from '@nestjs/common';
import { randomBytes } from 'node:crypto';
import * as fsp from 'node:fs/promises';
import * as path from 'node:path';
import type { AgentMessage } from '../../types/agent-message';

const VALID_MSG_TYPES = new Set([
  'message',
  'broadcast',
  'shutdown_request',
  'shutdown_response',
  'plan_approval_response',
]);

type InboxMsg = Record<string, unknown> & {
  type?: string;
  from?: string;
  content?: string;
};

type TeamMember = { name: string; role: string; status: string };

function workspaceKey(workspaceRoot: string): string {
  return path.resolve(workspaceRoot);
}

/**
 * 队友协议：收件箱 JSONL、`.team/config.json`、关停/计划跟踪（按 workspace 隔离）。
 * 本服务无队友后台 LLM：`spawn_teammate` 仅登记成员。
 */
@Injectable()
export class TeamProtocolService {
  private readonly shutdownRequests = new Map<
    string,
    Record<string, { target: string; status: string }>
  >();
  private readonly planRequests = new Map<
    string,
    Record<string, { from: string; plan: string; status: string }>
  >();
  private teamDir(root: string): string {
    return path.join(workspaceKey(root), '.team');
  }

  private inboxDir(root: string): string {
    return path.join(this.teamDir(root), 'inbox');
  }

  private configPath(root: string): string {
    return path.join(this.teamDir(root), 'config.json');
  }

  private getShutdownMap(root: string): Record<string, { target: string; status: string }> {
    const k = workspaceKey(root);
    if (!this.shutdownRequests.has(k)) this.shutdownRequests.set(k, {});
    return this.shutdownRequests.get(k)!;
  }

  private getPlanMap(root: string): Record<string, { from: string; plan: string; status: string }> {
    const k = workspaceKey(root);
    if (!this.planRequests.has(k)) this.planRequests.set(k, {});
    return this.planRequests.get(k)!;
  }

  private async ensureInbox(root: string): Promise<void> {
    await fsp.mkdir(this.inboxDir(root), { recursive: true });
  }

  async send(
    workspaceRoot: string,
    sender: string,
    to: string,
    content: string,
    msgType = 'message',
    extra?: Record<string, unknown>,
  ): Promise<string> {
    if (!VALID_MSG_TYPES.has(msgType)) {
      return `Error: invalid msg_type ${msgType}`;
    }
    await this.ensureInbox(workspaceRoot);
    const msg: InboxMsg = {
      type: msgType,
      from: sender,
      content,
      timestamp: Date.now() / 1000,
      ...extra,
    };
    const line = `${JSON.stringify(msg)}\n`;
    const fp = path.join(this.inboxDir(workspaceRoot), `${to}.jsonl`);
    await fsp.appendFile(fp, line, 'utf8');
    return `Sent ${msgType} to ${to}`;
  }

  async readInbox(workspaceRoot: string, name: string): Promise<InboxMsg[]> {
    const fp = path.join(this.inboxDir(workspaceRoot), `${name}.jsonl`);
    let raw: string;
    try {
      raw = await fsp.readFile(fp, 'utf8');
    } catch {
      return [];
    }
    const lines = raw.trim().split(/\r?\n/).filter(Boolean);
    await fsp.writeFile(fp, '', 'utf8');
    return lines.map((l) => JSON.parse(l) as InboxMsg);
  }

  async broadcast(
    workspaceRoot: string,
    sender: string,
    content: string,
    names: string[],
  ): Promise<string> {
    let count = 0;
    for (const n of names) {
      if (n !== sender) {
        await this.send(workspaceRoot, sender, n, content, 'broadcast');
        count += 1;
      }
    }
    return `Broadcast to ${count} teammates`;
  }

  private async loadTeam(root: string): Promise<{ team_name: string; members: TeamMember[] }> {
    try {
      const raw = await fsp.readFile(this.configPath(root), 'utf8');
      return JSON.parse(raw) as { team_name: string; members: TeamMember[] };
    } catch {
      return { team_name: 'default', members: [] };
    }
  }

  private async saveTeam(
    root: string,
    c: { team_name: string; members: TeamMember[] },
  ): Promise<void> {
    await fsp.mkdir(this.teamDir(root), { recursive: true });
    await fsp.writeFile(this.configPath(root), JSON.stringify(c, null, 2), 'utf8');
  }

  async spawnTeammate(
    workspaceRoot: string,
    name: string,
    role: string,
    prompt: string,
  ): Promise<string> {
    const c = await this.loadTeam(workspaceRoot);
    const member = c.members.find((m) => m.name === name);
    if (member) {
      if (member.status !== 'idle' && member.status !== 'shutdown') {
        return `Error: '${name}' is currently ${member.status}`;
      }
      member.status = 'working';
      member.role = role;
    } else {
      c.members.push({ name, role, status: 'working' });
    }
    await this.saveTeam(workspaceRoot, c);
    void prompt;
    return `Registered teammate '${name}' (role: ${role}). No background LLM loop in this server; use HTTP/外部进程驱动队友。`;
  }

  async listTeammates(workspaceRoot: string): Promise<string> {
    const c = await this.loadTeam(workspaceRoot);
    if (!c.members.length) return 'No teammates.';
    const lines = [`Team: ${c.team_name}`];
    for (const m of c.members) {
      lines.push(`  ${m.name} (${m.role}): ${m.status}`);
    }
    return lines.join('\n');
  }

  async memberNames(workspaceRoot: string): Promise<string[]> {
    const c = await this.loadTeam(workspaceRoot);
    return c.members.map((m) => m.name);
  }

  async getMember(workspaceRoot: string, name: string): Promise<TeamMember | undefined> {
    const c = await this.loadTeam(workspaceRoot);
    return c.members.find((m) => m.name === name);
  }

  async setMemberStatus(workspaceRoot: string, name: string, status: string): Promise<void> {
    const c = await this.loadTeam(workspaceRoot);
    const m = c.members.find((x) => x.name === name);
    if (m) {
      m.status = status;
      await this.saveTeam(workspaceRoot, c);
    }
  }

  applyInboxTrackers(workspaceRoot: string, inbox: InboxMsg[]): void {
    const shut = this.getShutdownMap(workspaceRoot);
    const plans = this.getPlanMap(workspaceRoot);
    for (const msg of inbox) {
      const t = msg.type;
      if (t === 'shutdown_response') {
        const rid =
          typeof msg.request_id === 'string' ? msg.request_id.trim() : '';
        if (rid && shut[rid]) {
          const appr = msg.approve;
          if (typeof appr === 'boolean') {
            shut[rid].status = appr ? 'approved' : 'rejected';
          }
        }
      }
      if (t === 'plan_approval_response') {
        const rid =
          typeof msg.request_id === 'string' ? msg.request_id.trim() : '';
        const from = typeof msg.from === 'string' ? msg.from.trim() : '';
        const planRaw =
          typeof msg.plan === 'string' && msg.plan.trim()
            ? msg.plan
            : typeof msg.content === 'string'
              ? msg.content
              : '';
        if (rid && planRaw && from && from !== 'lead') {
          plans[rid] = {
            from,
            plan: planRaw,
            status: 'pending',
          };
        }
      }
    }
  }

  /** drain lead 收件箱并 applyInboxTrackers；供 `read_inbox` 工具与 QueryEngine 主循环共用。 */
  private async drainLeadInboxAndTrack(workspaceRoot: string): Promise<InboxMsg[]> {
    const inbox = await this.readInbox(workspaceRoot, 'lead');
    this.applyInboxTrackers(workspaceRoot, inbox);
    return inbox;
  }

  async readLeadInbox(workspaceRoot: string): Promise<string> {
    const inbox = await this.drainLeadInboxAndTrack(workspaceRoot);
    return JSON.stringify(inbox, null, 2);
  }

  /**
   * 与 QueryEngine 每轮注入 lead 收件箱前一致：
   * 若有新消息则返回一条 user 消息（`&lt;inbox&gt;...`），否则 null。
   */
  async leadInboxUserMessageIfAny(workspaceRoot: string): Promise<AgentMessage | null> {
    const inbox = await this.drainLeadInboxAndTrack(workspaceRoot);
    if (!inbox.length) return null;
    return {
      role: 'user',
      content: `<inbox>${JSON.stringify(inbox, null, 2)}</inbox>`,
    };
  }

  async shutdownRequest(workspaceRoot: string, teammate: string): Promise<string> {
    const reqId = randomBytes(4).toString('hex');
    const shut = this.getShutdownMap(workspaceRoot);
    shut[reqId] = { target: teammate, status: 'pending' };
    await this.send(workspaceRoot, 'lead', teammate, 'Please shut down gracefully.', 'shutdown_request', {
      request_id: reqId,
    });
    shut[reqId].status = 'approved';
    await this.setMemberStatus(workspaceRoot, teammate, 'shutdown');
    return `Shutdown request ${reqId} sent to '${teammate}'. No active teammate LLM loop in this process; member marked shutdown immediately.`;
  }

  shutdownStatus(workspaceRoot: string, requestId: string): string {
    const r = this.getShutdownMap(workspaceRoot)[requestId];
    if (!r) {
      return JSON.stringify({ error: 'not found' });
    }
    return JSON.stringify(r);
  }

  async forceTeammateOffline(workspaceRoot: string, teammate: string): Promise<string> {
    const m = await this.getMember(workspaceRoot, teammate);
    if (!m) {
      return `Error: Unknown teammate '${teammate}'`;
    }
    const shut = this.getShutdownMap(workspaceRoot);
    for (const id of Object.keys(shut)) {
      if (shut[id].target === teammate) {
        shut[id].status = 'approved';
      }
    }
    await this.setMemberStatus(workspaceRoot, teammate, 'shutdown');
    return `Teammate '${teammate}' marked shutdown. Pending shutdown requests for this member are marked approved.`;
  }

  async planApproval(
    workspaceRoot: string,
    requestId: string,
    approve: boolean,
    feedback: string,
  ): Promise<string> {
    const plans = this.getPlanMap(workspaceRoot);
    const req = plans[requestId];
    if (!req) {
      return `Error: Unknown plan request_id '${requestId}'`;
    }
    req.status = approve ? 'approved' : 'rejected';
    await this.send(workspaceRoot, 'lead', req.from, feedback, 'plan_approval_response', {
      request_id: requestId,
      approve,
      feedback,
    });
    return `Plan ${req.status} for '${req.from}'`;
  }

  idleLead(): string {
    return 'Lead does not idle.';
  }
}
