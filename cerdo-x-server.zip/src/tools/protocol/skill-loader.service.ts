import { Injectable } from '@nestjs/common';
import * as fs from 'node:fs';
import * as path from 'node:path';

type SkillEntry = { meta: Record<string, string>; body: string };

/** 扫描工作区 `skills` 目录下的 `SKILL.md` */
@Injectable()
export class SkillLoaderService {
  private readonly cache = new Map<string, Map<string, SkillEntry>>();

  private walkSync(dir: string, out: Map<string, SkillEntry>): void {
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const ent of entries) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        this.walkSync(p, out);
      } else if (ent.name === 'SKILL.md') {
        const text = fs.readFileSync(p, 'utf8');
        const match = /^---\n([\s\S]*?)\n---\n([\s\S]*)$/.exec(text);
        let meta: Record<string, string> = {};
        let body = text;
        if (match) {
          const front = match[1];
          body = match[2].trim();
          for (const line of front.split(/\r?\n/)) {
            const idx = line.indexOf(':');
            if (idx > 0) {
              const k = line.slice(0, idx).trim();
              const v = line.slice(idx + 1).trim();
              meta[k] = v;
            }
          }
        }
        const name = meta.name ?? path.basename(path.dirname(p));
        out.set(name, { meta, body });
      }
    }
  }

  private getMap(workspaceRoot: string): Map<string, SkillEntry> {
    const root = path.resolve(workspaceRoot);
    let m = this.cache.get(root);
    if (!m) {
      m = new Map();
      const skillsDir = path.join(root, 'skills');
      this.walkSync(skillsDir, m);
      this.cache.set(root, m);
    }
    return m;
  }

  /** 使下次 load 重新扫描（例如用户新增了 SKILL.md） */
  invalidate(workspaceRoot: string): void {
    this.cache.delete(path.resolve(workspaceRoot));
  }

  descriptions(workspaceRoot: string): string {
    const skills = this.getMap(workspaceRoot);
    if (!skills.size) return '(no skills)';
    const lines: string[] = [];
    for (const [n, s] of skills) {
      lines.push(`  - ${n}: ${s.meta.description ?? '-'}`);
    }
    return lines.join('\n');
  }

  load(workspaceRoot: string, name: string): string {
    const skills = this.getMap(workspaceRoot);
    const s = skills.get(name);
    if (!s) {
      return `Error: Unknown skill '${name}'. Available: ${[...skills.keys()].join(', ') || '(none)'}`;
    }
    return `<skill name="${name}">\n${s.body}\n</skill>`;
  }
}
