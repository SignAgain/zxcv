import { WorkspaceBackgroundService } from './workspace-background.service';

export const INFRA_BACKGROUND_PROVIDERS = [WorkspaceBackgroundService] as const;
