import { Injectable } from '@nestjs/common';
import * as path from 'node:path';
import { BackgroundShellContext } from '../../../types/tool';
import { BackgroundManager } from './background-manager';

/**
 * 按 AGENT_WORKSPACE_ROOT（解析后的路径）复用同一套后台任务与通知队列，
 * 供 `background_run` / `check_background` 与 QueryEngine 注入 `<background-results>` 共用。
 */
@Injectable()
export class WorkspaceBackgroundService {
  private readonly managers = new Map<string, BackgroundManager>();

  getManager(workspaceRoot: string): BackgroundManager {
    const key = path.resolve(workspaceRoot);
    let m = this.managers.get(key);
    if (!m) {
      m = new BackgroundManager(() => key);
      this.managers.set(key, m);
    }
    return m;
  }

  /** 注入到 ToolContext.background，与单例 BackgroundManager 对齐 */
  createShellContext(workspaceRoot: string): BackgroundShellContext {
    const mgr = this.getManager(workspaceRoot);
    return {
      run: (command: string, timeoutMs?: number) => mgr.run(command, timeoutMs),
      check: (taskId?: string) => mgr.check(taskId),
      drainNotifications: () => mgr.drainNotifications(),
    };
  }
}
