import { Injectable } from '@nestjs/common';
import { ToolCall } from '../../types/agent-message';
import { AgentTool, OpenAIFunctionTool, ToolContext, ToolResult } from '../../types/tool';
import { BackgroundRunTool } from '../built-in/background/background-run.tool';
import { CheckBackgroundTool } from '../built-in/background/check-background.tool';
import { EditFileTool } from '../built-in/files/edit-file.tool';
import { FileReadTool } from '../built-in/files/file-read.tool';
import { WriteFileTool } from '../built-in/files/write-file.tool';
import { CompressTool } from '../built-in/session/compress.tool';
import { LoadSkillTool } from '../built-in/session/load-skill.tool';
import { SubagentTool } from '../built-in/session/subagent.tool';
import { TodoWriteTool } from '../built-in/session/todo-write.tool';
import { BashTool } from '../built-in/shell/bash.tool';
import {
  ClaimTaskTool,
  TaskCreateTool,
  TaskGetTool,
  TaskListTool,
  TaskUpdateTool,
} from '../built-in/tasks/task-agent.tools';
import {
  BroadcastTool,
  ForceTeammateOfflineTool,
  IdleTool,
  ListTeammatesTool,
  PlanApprovalTool,
  ReadInboxTool,
  SendMessageTool,
  ShutdownRequestTool,
  ShutdownResponseTool,
  SpawnTeammateTool,
} from '../built-in/team/team-agent.tools';

@Injectable()
export class ToolRegistryService {
  private readonly tools = new Map<string, AgentTool>();

  constructor(
    fileReadTool: FileReadTool,
    writeFileTool: WriteFileTool,
    editFileTool: EditFileTool,
    bashTool: BashTool,
    backgroundRunTool: BackgroundRunTool,
    checkBackgroundTool: CheckBackgroundTool,
    todoWriteTool: TodoWriteTool,
    subagentTool: SubagentTool,
    loadSkillTool: LoadSkillTool,
    compressTool: CompressTool,
    taskCreateTool: TaskCreateTool,
    taskUpdateTool: TaskUpdateTool,
    taskListTool: TaskListTool,
    taskGetTool: TaskGetTool,
    claimTaskTool: ClaimTaskTool,
    spawnTeammateTool: SpawnTeammateTool,
    listTeammatesTool: ListTeammatesTool,
    sendMessageTool: SendMessageTool,
    readInboxTool: ReadInboxTool,
    broadcastTool: BroadcastTool,
    shutdownRequestTool: ShutdownRequestTool,
    shutdownResponseTool: ShutdownResponseTool,
    forceTeammateOfflineTool: ForceTeammateOfflineTool,
    planApprovalTool: PlanApprovalTool,
    idleTool: IdleTool,
  ) {
    this.register(fileReadTool);
    this.register(writeFileTool);
    this.register(editFileTool);
    this.register(bashTool);
    this.register(backgroundRunTool);
    this.register(checkBackgroundTool);
    this.register(todoWriteTool);
    this.register(subagentTool);
    this.register(loadSkillTool);
    this.register(compressTool);
    this.register(taskCreateTool);
    this.register(taskUpdateTool);
    this.register(taskListTool);
    this.register(taskGetTool);
    this.register(claimTaskTool);
    this.register(spawnTeammateTool);
    this.register(listTeammatesTool);
    this.register(sendMessageTool);
    this.register(readInboxTool);
    this.register(broadcastTool);
    this.register(shutdownRequestTool);
    this.register(shutdownResponseTool);
    this.register(forceTeammateOfflineTool);
    this.register(planApprovalTool);
    this.register(idleTool);
  }

  register(tool: AgentTool): void {
    this.tools.set(tool.name, tool);
  }

  get(name: string): AgentTool | undefined {
    return this.tools.get(name);
  }

  listOpenAITools(allowedNames?: string[]): OpenAIFunctionTool[] {
    const names = allowedNames ?? Array.from(this.tools.keys());
    return names
      .map((name) => this.tools.get(name))
      .filter((tool): tool is AgentTool => Boolean(tool))
      .map((tool) => ({
        type: 'function',
        function: {
          name: tool.name,
          description: tool.description,
          parameters: tool.inputJsonSchema,
        },
      }));
  }

  async execute(call: ToolCall, context: ToolContext): Promise<ToolResult> {
    const tool = this.tools.get(call.name);
    if (!tool) {
      return { success: false, error: `Unknown tool: ${call.name}` };
    }

    const parsed = tool.inputSchema.safeParse(call.input);
    if (!parsed.success) {
      return {
        success: false,
        error: parsed.error.issues.map((item) => item.message).join('; '),
      };
    }

    return tool.call(parsed.data, context);
  }
}
