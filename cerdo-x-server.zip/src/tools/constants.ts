/** 工具输出截断、bash/后台超时等，与历史 Chat Agent 约定一致 */

export const MAX_TOOL_CHARS = 50_000;
export const BASH_TIMEOUT_MS = 120_000;
export const BG_TIMEOUT_MS = 300_000;
export const NOTIF_RESULT_MAX = 500;

export const DANGEROUS_BASH = [
  'rm -rf /',
  'sudo',
  'shutdown',
  'reboot',
  '> /dev/',
];
