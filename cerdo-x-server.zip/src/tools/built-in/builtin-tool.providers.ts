import { BACKGROUND_TOOL_PROVIDERS } from './background/background-tools.providers';
import { FILE_TOOL_PROVIDERS } from './files/file-tools.providers';
import { SESSION_TOOL_PROVIDERS } from './session/session-tools.providers';
import { SHELL_TOOL_PROVIDERS } from './shell/shell-tools.providers';
import { TASK_TOOL_PROVIDERS } from './tasks/task-tools.providers';
import { TEAM_TOOL_PROVIDERS } from './team/team-tools.providers';

/** 全部内置 AgentTool 的 Nest `providers` 项（顺序与注册表一致）。 */
export const BUILTIN_TOOL_PROVIDERS = [
  ...FILE_TOOL_PROVIDERS,
  ...SHELL_TOOL_PROVIDERS,
  ...BACKGROUND_TOOL_PROVIDERS,
  ...SESSION_TOOL_PROVIDERS,
  ...TASK_TOOL_PROVIDERS,
  ...TEAM_TOOL_PROVIDERS,
] as const;
