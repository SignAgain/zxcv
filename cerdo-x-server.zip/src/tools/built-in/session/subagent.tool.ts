import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { LlmClient } from '../../../utils/llm-client';
import { formatCaughtUnknown } from '../../utils/error-string';

const SubagentInputSchema = z.object({
  prompt: z.string().min(1),
  agent_type: z.enum(['Explore', 'general-purpose']).optional(),
});

type SubagentInput = z.infer<typeof SubagentInputSchema>;

/** `task` 工具：单次 LLM 调用模拟子代理（无独立多轮循环）。 */
@Injectable()
export class SubagentTool implements AgentTool<SubagentInput, string> {
  name = 'task';
  description =
    'Spawn a subagent for isolated exploration or work (Explore vs general-purpose).';
  inputSchema = SubagentInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      prompt: { type: 'string' },
      agent_type: { type: 'string', enum: ['Explore', 'general-purpose'] },
    },
    required: ['prompt'],
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(
    private readonly llm: LlmClient,
    private readonly config: ConfigService,
  ) {}

  async call(input: SubagentInput, _context: ToolContext): Promise<ToolResult<string>> {
    const at = input.agent_type ?? 'Explore';
    const system =
      at === 'Explore'
        ? 'You are a focused exploration subagent. Answer concisely in plain text.'
        : 'You are a general-purpose subagent. Answer concisely in plain text.';
    try {
      const maxRaw = this.config.get<string | number>('LLM_SUBAGENT_MAX_TOKENS');
      const maxTok =
        typeof maxRaw === 'number'
          ? maxRaw
          : Number.parseInt(String(maxRaw ?? ''), 10);
      const res = await this.llm.streamChat(
        {
          messages: [
            { role: 'system', content: system },
            { role: 'user', content: input.prompt },
          ],
          tools: [],
          model: this.config.get<string>('LLM_MODEL') ?? undefined,
          maxOutputTokens: Number.isFinite(maxTok) ? maxTok : 2048,
          thinkingEnabled: false,
          logMeta: {
            phase: 'subagent.task',
            roundLabel: at,
          },
        },
        {},
      );
      const text = res.message.content?.trim() || '(no output)';
      return { success: true, data: text };
    } catch (e: unknown) {
      return { success: false, error: formatCaughtUnknown(e) };
    }
  }
}
