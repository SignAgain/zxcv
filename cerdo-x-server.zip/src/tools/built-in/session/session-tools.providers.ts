import { CompressTool } from './compress.tool';
import { LoadSkillTool } from './load-skill.tool';
import { SubagentTool } from './subagent.tool';
import { TodoWriteTool } from './todo-write.tool';

export const SESSION_TOOL_PROVIDERS = [
  TodoWriteTool,
  SubagentTool,
  LoadSkillTool,
  CompressTool,
] as const;
