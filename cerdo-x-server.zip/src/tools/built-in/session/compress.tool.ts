import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { CompressStateService } from '../../protocol/compress-state.service';

const CompressInputSchema = z.object({});

@Injectable()
export class CompressTool implements AgentTool<Record<string, never>, string> {
  name = 'compress';
  description = 'Manually compress conversation context.';
  inputSchema = CompressInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {},
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(private readonly compressState: CompressStateService) {}

  async call(
    _input: Record<string, never>,
    context: ToolContext,
  ): Promise<ToolResult<string>> {
    if (context.sessionId) {
      this.compressState.mark(context.sessionId);
    }
    return { success: true, data: 'Compressing...' };
  }
}
