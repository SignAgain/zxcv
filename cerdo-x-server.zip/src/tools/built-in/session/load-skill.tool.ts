import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { SkillLoaderService } from '../../protocol/skill-loader.service';

const LoadSkillInputSchema = z.object({
  name: z.string().min(1),
});

type LoadSkillInput = z.infer<typeof LoadSkillInputSchema>;

@Injectable()
export class LoadSkillTool implements AgentTool<LoadSkillInput, string> {
  name = 'load_skill';
  description = 'Load specialized knowledge by skill name.';
  inputSchema = LoadSkillInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { name: { type: 'string' } },
    required: ['name'],
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(private readonly skills: SkillLoaderService) {}

  async call(input: LoadSkillInput, context: ToolContext): Promise<ToolResult<string>> {
    const text = this.skills.load(context.workspaceRoot, input.name);
    if (text.startsWith('Error:')) {
      return { success: false, error: text.slice('Error:'.length).trim() };
    }
    return { success: true, data: text };
  }
}
