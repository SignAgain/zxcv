import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { TodoWriteStateService } from '../../protocol/todo-write-state.service';

const TodoWriteInputSchema = z.object({
  items: z.array(
    z.object({
      content: z.string(),
      status: z.enum(['pending', 'in_progress', 'completed']),
      activeForm: z.string(),
    }),
  ),
});

type TodoWriteInput = z.infer<typeof TodoWriteInputSchema>;

@Injectable()
export class TodoWriteTool implements AgentTool<TodoWriteInput, string> {
  name = 'TodoWrite';
  description = 'Update task tracking list.';
  inputSchema = TodoWriteInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      items: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            content: { type: 'string' },
            status: {
              type: 'string',
              enum: ['pending', 'in_progress', 'completed'],
            },
            activeForm: { type: 'string' },
          },
          required: ['content', 'status', 'activeForm'],
        },
      },
    },
    required: ['items'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly todos: TodoWriteStateService) {}

  async call(input: TodoWriteInput, context: ToolContext): Promise<ToolResult<string>> {
    const sid = context.sessionId;
    if (!sid) {
      return {
        success: false,
        error: 'TodoWrite requires an agent session (sessionId missing).',
      };
    }
    try {
      const text = this.todos.getOrCreate(sid).update(input.items);
      return { success: true, data: text };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      return { success: false, error: msg };
    }
  }
}
