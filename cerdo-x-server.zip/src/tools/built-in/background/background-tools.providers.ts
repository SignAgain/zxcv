import { BackgroundRunTool } from './background-run.tool';
import { CheckBackgroundTool } from './check-background.tool';

export const BACKGROUND_TOOL_PROVIDERS = [BackgroundRunTool, CheckBackgroundTool] as const;
