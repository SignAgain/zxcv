import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';

const BackgroundRunInputSchema = z.object({
  command: z.string().min(1),
  /** 超时（秒）；缺省使用 BG_TIMEOUT_MS。 */
  timeout: z.coerce.number().int().positive().optional(),
});

type BackgroundRunInput = z.infer<typeof BackgroundRunInputSchema>;

@Injectable()
export class BackgroundRunTool implements AgentTool<BackgroundRunInput, string> {
  name = 'background_run';
  description = 'Run command in background.';
  inputSchema = BackgroundRunInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      command: { type: 'string' },
      timeout: { type: 'integer', description: 'Optional timeout in seconds' },
    },
    required: ['command'],
    additionalProperties: false,
  };
  isReadOnly = false;

  async call(input: BackgroundRunInput, context: ToolContext): Promise<ToolResult<string>> {
    if (!context.background) {
      return {
        success: false,
        error: 'Background tasks are not available in this execution context.',
      };
    }
    const sec =
      typeof input.timeout === 'number' && Number.isFinite(input.timeout)
        ? Math.trunc(input.timeout)
        : undefined;
    const timeoutMs = sec !== undefined ? sec * 1000 : undefined;
    return { success: true, data: context.background.run(input.command, timeoutMs) };
  }
}
