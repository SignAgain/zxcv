import { EditFileTool } from './edit-file.tool';
import { FileReadTool } from './file-read.tool';
import { WriteFileTool } from './write-file.tool';

export const FILE_TOOL_PROVIDERS = [FileReadTool, WriteFileTool, EditFileTool] as const;
