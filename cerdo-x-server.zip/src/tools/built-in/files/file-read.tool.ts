import { Injectable } from '@nestjs/common';
import { promises as fs } from 'node:fs';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { MAX_TOOL_CHARS } from '../../constants';
import { formatCaughtUnknown } from '../../utils/error-string';
import { resolvePathUnderWorkspace } from '../../utils/workspace-safe-path';

/** `read_file`：path + 可选 limit（按行截断，超出追加 `... (N more)`）。 */
const FileReadInputSchema = z.object({
  path: z.string().min(1),
  limit: z.coerce.number().int().positive().optional(),
  /** 从第几行开始读（1-based）；在 limit 之前应用。 */
  offset: z.coerce.number().int().positive().optional(),
});

type FileReadInput = z.infer<typeof FileReadInputSchema>;

@Injectable()
export class FileReadTool implements AgentTool<FileReadInput, string> {
  name = 'read_file';
  description = 'Read file contents.';
  inputSchema = FileReadInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      path: { type: 'string' },
      limit: { type: 'integer' },
      offset: { type: 'integer', description: 'Optional 1-based start line' },
    },
    required: ['path'],
    additionalProperties: false,
  };
  isReadOnly = true;

  async call(input: FileReadInput, context: ToolContext): Promise<ToolResult<string>> {
    try {
      const filePath = resolvePathUnderWorkspace(context.workspaceRoot, input.path);
      const raw = await fs.readFile(filePath, 'utf-8');
      let lines = raw.split(/\r?\n/);

      const start = input.offset ? input.offset - 1 : 0;
      lines = lines.slice(start);

      const lim = input.limit;
      if (typeof lim === 'number' && Number.isFinite(lim) && lim > 0 && lim < lines.length) {
        const rest = lines.length - lim;
        lines = [...lines.slice(0, lim), `... (${rest} more)`];
      }

      let out = lines.join('\n');
      if (out.length > MAX_TOOL_CHARS) {
        out = out.slice(0, MAX_TOOL_CHARS);
      }
      return { success: true, data: out };
    } catch (e: unknown) {
      return { success: false, error: formatCaughtUnknown(e) };
    }
  }
}
