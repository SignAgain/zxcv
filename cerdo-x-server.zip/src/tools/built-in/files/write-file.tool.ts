import { Injectable } from '@nestjs/common';
import { promises as fs } from 'node:fs';
import * as path from 'node:path';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { formatCaughtUnknown } from '../../utils/error-string';
import { resolvePathUnderWorkspace } from '../../utils/workspace-safe-path';

const WriteFileInputSchema = z.object({
  path: z.string().min(1),
  content: z.string(),
});

type WriteFileInput = z.infer<typeof WriteFileInputSchema>;

@Injectable()
export class WriteFileTool implements AgentTool<WriteFileInput, string> {
  name = 'write_file';
  description = 'Write content to file.';
  inputSchema = WriteFileInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      path: { type: 'string' },
      content: { type: 'string' },
    },
    required: ['path', 'content'],
    additionalProperties: false,
  };
  isReadOnly = false;

  async call(input: WriteFileInput, context: ToolContext): Promise<ToolResult<string>> {
    try {
      const fp = resolvePathUnderWorkspace(context.workspaceRoot, input.path);
      await fs.mkdir(path.dirname(fp), { recursive: true });
      await fs.writeFile(fp, input.content, 'utf8');
      return {
        success: true,
        data: `Wrote ${input.content.length} bytes to ${input.path}`,
      };
    } catch (e: unknown) {
      return { success: false, error: formatCaughtUnknown(e) };
    }
  }
}
