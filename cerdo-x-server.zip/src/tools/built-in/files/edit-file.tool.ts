import { Injectable } from '@nestjs/common';
import { promises as fs } from 'node:fs';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { formatCaughtUnknown } from '../../utils/error-string';
import { resolvePathUnderWorkspace } from '../../utils/workspace-safe-path';

const EditFileInputSchema = z.object({
  path: z.string().min(1),
  old_text: z.string(),
  new_text: z.string(),
});

type EditFileInput = z.infer<typeof EditFileInputSchema>;

@Injectable()
export class EditFileTool implements AgentTool<EditFileInput, string> {
  name = 'edit_file';
  description = 'Replace exact text in file.';
  inputSchema = EditFileInputSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      path: { type: 'string' },
      old_text: { type: 'string' },
      new_text: { type: 'string' },
    },
    required: ['path', 'old_text', 'new_text'],
  };
  isReadOnly = false;

  async call(input: EditFileInput, context: ToolContext): Promise<ToolResult<string>> {
    try {
      const fp = resolvePathUnderWorkspace(context.workspaceRoot, input.path);
      const content = await fs.readFile(fp, 'utf8');
      if (!content.includes(input.old_text)) {
        return { success: false, error: `Text not found in ${input.path}` };
      }
      await fs.writeFile(fp, content.replace(input.old_text, input.new_text), 'utf8');
      return { success: true, data: `Edited ${input.path}` };
    } catch (e: unknown) {
      return { success: false, error: formatCaughtUnknown(e) };
    }
  }
}
