import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { TaskService } from '../../../tasks/task.service';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';

function fromDispatch(text: string): ToolResult<string> {
  if (text.startsWith('Error:')) {
    return { success: false, error: text.slice('Error:'.length).trim() };
  }
  return { success: true, data: text };
}

const TaskCreateSchema = z.object({
  subject: z.string().min(1),
  description: z.string().optional(),
});

@Injectable()
export class TaskCreateTool implements AgentTool<z.infer<typeof TaskCreateSchema>, string> {
  name = 'task_create';
  description = 'Create a new task.';
  inputSchema = TaskCreateSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      subject: { type: 'string' },
      description: { type: 'string' },
    },
    required: ['subject'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly tasks: TaskService) {}

  async call(
    input: z.infer<typeof TaskCreateSchema>,
    _ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.tasks.dispatchTaskTool('task_create', input as Record<string, unknown>);
    return fromDispatch(text);
  }
}

const TaskUpdateSchema = z.object({
  task_id: z.coerce.number().int(),
  status: z.enum(['pending', 'in_progress', 'completed', 'deleted']).optional(),
  addBlockedBy: z.array(z.coerce.number().int()).optional(),
  removeBlockedBy: z.array(z.coerce.number().int()).optional(),
});

@Injectable()
export class TaskUpdateTool implements AgentTool<z.infer<typeof TaskUpdateSchema>, string> {
  name = 'task_update';
  description = "Update a task's status or dependencies.";
  inputSchema = TaskUpdateSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      task_id: { type: 'integer' },
      status: {
        type: 'string',
        enum: ['pending', 'in_progress', 'completed', 'deleted'],
      },
      addBlockedBy: { type: 'array', items: { type: 'integer' } },
      removeBlockedBy: { type: 'array', items: { type: 'integer' } },
    },
    required: ['task_id'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly tasks: TaskService) {}

  async call(
    input: z.infer<typeof TaskUpdateSchema>,
    _ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.tasks.dispatchTaskTool('task_update', input as Record<string, unknown>);
    return fromDispatch(text);
  }
}

const TaskListSchema = z.object({});

@Injectable()
export class TaskListTool implements AgentTool<Record<string, never>, string> {
  name = 'task_list';
  description = 'List all tasks with status summary.';
  inputSchema = TaskListSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {},
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(private readonly tasks: TaskService) {}

  async call(
    _input: Record<string, never>,
    _ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.tasks.dispatchTaskTool('task_list', {});
    return fromDispatch(text);
  }
}

const TaskGetSchema = z.object({
  task_id: z.coerce.number().int(),
});

@Injectable()
export class TaskGetTool implements AgentTool<z.infer<typeof TaskGetSchema>, string> {
  name = 'task_get';
  description = 'Get full details of a task by ID.';
  inputSchema = TaskGetSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { task_id: { type: 'integer' } },
    required: ['task_id'],
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(private readonly tasks: TaskService) {}

  async call(
    input: z.infer<typeof TaskGetSchema>,
    _ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.tasks.dispatchTaskTool('task_get', input as Record<string, unknown>);
    return fromDispatch(text);
  }
}

const ClaimTaskSchema = z.object({
  task_id: z.coerce.number().int(),
  owner: z.string().optional(),
});

@Injectable()
export class ClaimTaskTool implements AgentTool<z.infer<typeof ClaimTaskSchema>, string> {
  name = 'claim_task';
  description =
    'Claim a task by ID (sets owner and in_progress). Omit owner to default to lead. Mark completed with task_update when work is done.';
  inputSchema = ClaimTaskSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      task_id: { type: 'integer' },
      owner: { type: 'string', description: 'Claimant id; defaults to lead if omitted' },
    },
    required: ['task_id'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly tasks: TaskService) {}

  async call(
    input: z.infer<typeof ClaimTaskSchema>,
    _ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.tasks.dispatchTaskTool('claim_task', input as Record<string, unknown>);
    return fromDispatch(text);
  }
}
