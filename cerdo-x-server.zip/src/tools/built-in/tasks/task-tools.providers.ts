import {
  ClaimTaskTool,
  TaskCreateTool,
  TaskGetTool,
  TaskListTool,
  TaskUpdateTool,
} from './task-agent.tools';

export const TASK_TOOL_PROVIDERS = [
  TaskCreateTool,
  TaskUpdateTool,
  TaskListTool,
  TaskGetTool,
  ClaimTaskTool,
] as const;
