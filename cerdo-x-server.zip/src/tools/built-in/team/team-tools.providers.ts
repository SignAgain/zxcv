import {
  BroadcastTool,
  ForceTeammateOfflineTool,
  IdleTool,
  ListTeammatesTool,
  PlanApprovalTool,
  ReadInboxTool,
  SendMessageTool,
  ShutdownRequestTool,
  ShutdownResponseTool,
  SpawnTeammateTool,
} from './team-agent.tools';

export const TEAM_TOOL_PROVIDERS = [
  SpawnTeammateTool,
  ListTeammatesTool,
  SendMessageTool,
  ReadInboxTool,
  BroadcastTool,
  ShutdownRequestTool,
  ShutdownResponseTool,
  ForceTeammateOfflineTool,
  PlanApprovalTool,
  IdleTool,
] as const;
