import { Injectable } from '@nestjs/common';
import { z } from 'zod';
import { AgentTool, ToolContext, ToolResult } from '../../../types/tool';
import { TeamProtocolService } from '../../protocol/team-protocol.service';

const SpawnTeammateSchema = z.object({
  name: z.string().min(1),
  role: z.string().min(1),
  prompt: z.string(),
});

@Injectable()
export class SpawnTeammateTool implements AgentTool<z.infer<typeof SpawnTeammateSchema>, string> {
  name = 'spawn_teammate';
  description = 'Register a teammate (HTTP mode: no background LLM loop).';
  inputSchema = SpawnTeammateSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      name: { type: 'string' },
      role: { type: 'string' },
      prompt: { type: 'string' },
    },
    required: ['name', 'role', 'prompt'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly team: TeamProtocolService) {}

  async call(
    input: z.infer<typeof SpawnTeammateSchema>,
    ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.team.spawnTeammate(ctx.workspaceRoot, input.name, input.role, input.prompt);
    if (text.startsWith('Error:')) {
      return { success: false, error: text.slice('Error:'.length).trim() };
    }
    return { success: true, data: text };
  }
}

const EmptySchema = z.object({});

@Injectable()
export class ListTeammatesTool implements AgentTool<Record<string, never>, string> {
  name = 'list_teammates';
  description = 'List teammates.';
  inputSchema = EmptySchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {},
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(private readonly team: TeamProtocolService) {}

  async call(_input: Record<string, never>, ctx: ToolContext): Promise<ToolResult<string>> {
    const text = await this.team.listTeammates(ctx.workspaceRoot);
    return { success: true, data: text };
  }
}

const SendMessageSchema = z.object({
  to: z.string().min(1),
  content: z.string(),
  msg_type: z
    .enum([
      'message',
      'broadcast',
      'shutdown_request',
      'shutdown_response',
      'plan_approval_response',
    ])
    .optional(),
});

@Injectable()
export class SendMessageTool implements AgentTool<z.infer<typeof SendMessageSchema>, string> {
  name = 'send_message';
  description = 'Send a message to a teammate.';
  inputSchema = SendMessageSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      to: { type: 'string' },
      content: { type: 'string' },
      msg_type: {
        type: 'string',
        enum: [
          'message',
          'broadcast',
          'shutdown_request',
          'shutdown_response',
          'plan_approval_response',
        ],
      },
    },
    required: ['to', 'content'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly team: TeamProtocolService) {}

  async call(
    input: z.infer<typeof SendMessageSchema>,
    ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const mt = input.msg_type ?? 'message';
    const text = await this.team.send(ctx.workspaceRoot, 'lead', input.to, input.content, mt);
    if (text.startsWith('Error:')) {
      return { success: false, error: text.slice('Error:'.length).trim() };
    }
    return { success: true, data: text };
  }
}

@Injectable()
export class ReadInboxTool implements AgentTool<Record<string, never>, string> {
  name = 'read_inbox';
  description =
    "Read and drain the lead's inbox. QueryEngine also auto-drains before each LLM round; use this for an explicit poll mid-turn.";
  inputSchema = EmptySchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {},
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly team: TeamProtocolService) {}

  async call(_input: Record<string, never>, ctx: ToolContext): Promise<ToolResult<string>> {
    const text = await this.team.readLeadInbox(ctx.workspaceRoot);
    return { success: true, data: text };
  }
}

const BroadcastSchema = z.object({
  content: z.string(),
});

@Injectable()
export class BroadcastTool implements AgentTool<z.infer<typeof BroadcastSchema>, string> {
  name = 'broadcast';
  description = 'Send message to all teammates.';
  inputSchema = BroadcastSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { content: { type: 'string' } },
    required: ['content'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly team: TeamProtocolService) {}

  async call(
    input: z.infer<typeof BroadcastSchema>,
    ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const names = await this.team.memberNames(ctx.workspaceRoot);
    const text = await this.team.broadcast(ctx.workspaceRoot, 'lead', input.content, names);
    return { success: true, data: text };
  }
}

const ShutdownRequestSchema = z.object({
  teammate: z.string().min(1),
});

@Injectable()
export class ShutdownRequestTool implements AgentTool<z.infer<typeof ShutdownRequestSchema>, string> {
  name = 'shutdown_request';
  description = 'Request a teammate to shut down.';
  inputSchema = ShutdownRequestSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { teammate: { type: 'string' } },
    required: ['teammate'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly team: TeamProtocolService) {}

  async call(
    input: z.infer<typeof ShutdownRequestSchema>,
    ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.team.shutdownRequest(ctx.workspaceRoot, input.teammate);
    return { success: true, data: text };
  }
}

const ShutdownResponseSchema = z.object({
  request_id: z.string().min(1),
});

@Injectable()
export class ShutdownResponseTool implements AgentTool<z.infer<typeof ShutdownResponseSchema>, string> {
  name = 'shutdown_response';
  description =
    'Check the status of a shutdown request by request_id (pending / approved / rejected).';
  inputSchema = ShutdownResponseSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { request_id: { type: 'string' } },
    required: ['request_id'],
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(private readonly team: TeamProtocolService) {}

  async call(
    input: z.infer<typeof ShutdownResponseSchema>,
    ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = this.team.shutdownStatus(ctx.workspaceRoot, input.request_id);
    return { success: true, data: text };
  }
}

const ForceOfflineSchema = z.object({
  teammate: z.string().min(1),
});

@Injectable()
export class ForceTeammateOfflineTool implements AgentTool<z.infer<typeof ForceOfflineSchema>, string> {
  name = 'force_teammate_offline';
  description =
    'Immediately set teammate to shutdown in .team/config.json and stop their background loop in this process. Use when shutdown_request stays pending (no running loop, or stuck agent).';
  inputSchema = ForceOfflineSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: { teammate: { type: 'string' } },
    required: ['teammate'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly team: TeamProtocolService) {}

  async call(
    input: z.infer<typeof ForceOfflineSchema>,
    ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.team.forceTeammateOffline(ctx.workspaceRoot, input.teammate);
    if (text.startsWith('Error:')) {
      return { success: false, error: text.slice('Error:'.length).trim() };
    }
    return { success: true, data: text };
  }
}

const PlanApprovalSchema = z.object({
  request_id: z.string().min(1),
  approve: z.boolean(),
  feedback: z.string().optional(),
});

@Injectable()
export class PlanApprovalTool implements AgentTool<z.infer<typeof PlanApprovalSchema>, string> {
  name = 'plan_approval';
  description = 'Approve or reject a teammate plan.';
  inputSchema = PlanApprovalSchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {
      request_id: { type: 'string' },
      approve: { type: 'boolean' },
      feedback: { type: 'string' },
    },
    required: ['request_id', 'approve'],
    additionalProperties: false,
  };
  isReadOnly = false;

  constructor(private readonly team: TeamProtocolService) {}

  async call(
    input: z.infer<typeof PlanApprovalSchema>,
    ctx: ToolContext,
  ): Promise<ToolResult<string>> {
    const text = await this.team.planApproval(
      ctx.workspaceRoot,
      input.request_id,
      input.approve,
      input.feedback ?? '',
    );
    if (text.startsWith('Error:')) {
      return { success: false, error: text.slice('Error:'.length).trim() };
    }
    return { success: true, data: text };
  }
}

@Injectable()
export class IdleTool implements AgentTool<Record<string, never>, string> {
  name = 'idle';
  description = 'Enter idle state.';
  inputSchema = EmptySchema;
  inputJsonSchema: Record<string, unknown> = {
    type: 'object',
    properties: {},
    additionalProperties: false,
  };
  isReadOnly = true;

  constructor(private readonly team: TeamProtocolService) {}

  async call(_input: Record<string, never>, _ctx: ToolContext): Promise<ToolResult<string>> {
    return { success: true, data: this.team.idleLead() };
  }
}
