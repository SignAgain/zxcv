import { Injectable } from '@nestjs/common';
import { ContextCompactService } from '../context/context-compact.service';
import type { AgentMessage } from '../types/agent-message';
import { QueryParams, QueryResult } from '../types/query';
import { ToolContext } from '../types/tool';
import { CHAT_BUILTIN_TOOL_NAMES } from '../tools/registry/builtin-tool-names';
import { TeamProtocolService } from '../tools/protocol/team-protocol.service';
import { ToolRegistryService } from '../tools/registry/tool-registry.service';
import { LlmClient } from '../utils/llm-client';
import { mergeOpenAiToolsDistinct } from '../utils/openai-messages';

/**
 * QueryEngine 负责执行「LLM -> 工具 -> LLM」循环，直到得到终态响应或达到回合上限。
 * 大模型调用经 LlmClient.streamChat（SSE 汇总为单轮 assistant + tool_calls）。
 *
 * 每轮 streamChat 之前：
 * 1. 后台通知 drain → 若有则追加 `&lt;background-results&gt;...`
 * 2. lead 收件箱 drain → 若有则追加 `&lt;inbox&gt;...`
 * 3. `microCompact`；若粗估 token 超阈值则 `autoCompact`（保留 system）
 */
@Injectable()
export class QueryEngineService {
  constructor(
    private readonly llmClient: LlmClient,
    private readonly toolRegistry: ToolRegistryService,
    private readonly teamProtocol: TeamProtocolService,
    private readonly contextCompact: ContextCompactService,
  ) {}

  async run(params: QueryParams, context: ToolContext): Promise<QueryResult> {
    const messages = [...params.messages];
    const maxTurns = params.maxTurns ?? 6;

    for (let turn = 1; turn <= maxTurns; turn += 1) {
      const bgMsg = this.backgroundResultsUserMessageIfAny(context);
      if (bgMsg) {
        messages.push(bgMsg);
        params.hooks?.onMessage?.(bgMsg);
        params.onEvent?.({
          eventType: 'background.results',
          source: 'query_engine',
          payload: { turn, contentLength: bgMsg.content.length },
        });
      }

      const inboxMsg = await this.teamProtocol.leadInboxUserMessageIfAny(
        context.workspaceRoot,
      );
      if (inboxMsg) {
        messages.push(inboxMsg);
        params.hooks?.onMessage?.(inboxMsg);
        params.onEvent?.({
          eventType: 'team.inbox',
          source: 'query_engine',
          payload: {
            turn,
            contentLength: inboxMsg.content.length,
          },
        });
      }

      // const compactMeta = await this.contextCompact.applyRoundCompactIfNeeded(messages);
      // if (compactMeta.compacted) {
      //   params.onEvent?.({
      //     eventType: 'context.auto_compact',
      //     source: 'query_engine',
      //     payload: {
      //       turn,
      //       reason: 'token_threshold',
      //       tokensBefore: compactMeta.tokensBefore,
      //       tokensAfter: compactMeta.tokensAfter,
      //     },
      //   });
      // }

      // 每轮都把当前消息历史发送给模型，并流式上报 token 增量。
      const response = await this.llmClient.streamChat(
        {
          messages,
          tools: mergeOpenAiToolsDistinct(
            params.tools,
            this.toolRegistry.listOpenAITools([...CHAT_BUILTIN_TOOL_NAMES]),
          ),
          model: params.model,
          temperature: params.temperature,
          topP: params.topP,
          maxOutputTokens: params.maxOutputTokens,
          thinkingEnabled: params.thinkingEnabled,
          logMeta: {
            phase: 'query_engine',
            roundLabel: `turn_${turn}`,
          },
        },
        {
          onDelta: (text) => {
            params.onEvent?.({
              eventType: 'llm.delta',
              source: 'llm_client',
              payload: { text },
            });
          },
        },
      );

      const assistantMessage = response.message;
      messages.push(assistantMessage);
      params.hooks?.onMessage?.(assistantMessage);

      // 非流式整包返回：用一次 delta 推送整段文本，兼容仍监听 llm.delta 的前端。
      if (assistantMessage.content) {
        params.onEvent?.({
          eventType: 'llm.delta',
          source: 'llm_client',
          payload: { text: assistantMessage.content },
        });
      }

      if (!response.toolCalls.length) {
        params.hooks?.onTurnComplete?.(turn);
        return {
          messages,
          finalText: assistantMessage.content,
        };
      }

      for (const toolCall of response.toolCalls) {
        params.hooks?.onToolCall?.(toolCall.name, toolCall.input);
        params.onEvent?.({
          eventType: 'tool.call',
          source: 'query_engine',
          payload: {
            id: toolCall.id,
            name: toolCall.name,
            input: toolCall.input,
          },
        });

        const result = await this.toolRegistry.execute(toolCall, context);
        params.hooks?.onToolResult?.(toolCall.name, result);
        params.onEvent?.({
          eventType: 'tool.result',
          source: 'query_engine',
          payload: {
            id: toolCall.id,
            name: toolCall.name,
            result,
          },
        });

        messages.push({
          // 工具结果作为 tool role 消息写回历史，供下一轮模型消费。
          role: 'tool',
          toolCallId: toolCall.id,
          name: toolCall.name,
          content: JSON.stringify(result),
        });
      }

      params.hooks?.onTurnComplete?.(turn);
    }

    return {
      messages,
      finalText: 'Reached maxTurns without terminal response.',
    };
  }

  /** 后台任务完成通知，格式与主参考实现一致 */
  private backgroundResultsUserMessageIfAny(context: ToolContext): AgentMessage | null {
    const drain = context.background?.drainNotifications;
    if (!drain) {
      return null;
    }
    const notifs = drain();
    if (!notifs.length) {
      return null;
    }
    const txt = notifs
      .map((n) => `[bg:${n.task_id}] ${n.status}: ${n.result}`)
      .join('\n');
    return {
      role: 'user',
      content: `<background-results>\n${txt}\n</background-results>`,
    };
  }
}
