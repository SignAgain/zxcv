import {
  ArgumentsHost,
  CallHandler,
  Catch,
  ExceptionFilter,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
  NestInterceptor,
} from '@nestjs/common';
import { ApiProperty } from '@nestjs/swagger';
import { Request, Response } from 'express';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthFailureException } from './auth';

// ============================================================================
// 常量定义区
// ============================================================================
export const SUCCESS_CODE = '0000'; // 业务成功的状态码
export const CODE_AU0002 = 'AU0002'; // 获取用户信息失败（token 缺失或 UPM 校验失败）的状态码
export const MESSAGE_AU0002 = '获取用户信息失败，请稍后再试'; // 对应的错误提示信息
export const CODE_VALIDATION = 'VAL0001'; // 参数校验失败的状态码
export const CODE_INTERNAL = 'SYS0001'; // 未分类的服务器内部错误状态码

// ============================================================================
// 统一响应体数据结构定义
// 所有的接口返回数据都会被包装成这个结构，方便前端统一处理
// ============================================================================
export class AjaxResult<T = unknown> {
  @ApiProperty({ example: '0000', description: '0000 为成功，其他为错误' })
  code: string;
  @ApiProperty({ description: '响应类型，通常为 SUCCESS 或 ERROR' })
  type: string;
  @ApiProperty({ example: true, description: 'true 为成功，false 为失败' })
  success: boolean;
  @ApiProperty({ example: 'success', description: '提示信息' })
  message: string;
  @ApiProperty({ description: '方法血缘，记录是哪个 Controller 的哪个方法处理的请求' })
  tracing: string;
  @ApiProperty({ description: '全链路追踪 ID，用于日志排查' })
  traceId: string;
  @ApiProperty({ description: '实际的业务数据体' })
  data: T | null;
}

// ============================================================================
// 全局响应拦截器 (Interceptor)
// 作用：拦截所有 Controller 方法的正常返回结果，将其包装成统一的 AjaxResult 格式。
// 这样业务代码中只需要 return 实际的数据即可，不需要每次都手动拼装 code、message 等字段。
// ============================================================================
@Injectable()
export class AjaxResultInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest();

    // next.handle() 代表执行后续的 Controller 业务逻辑
    // pipe(map(...)) 用于对业务逻辑返回的数据进行二次加工
    return next.handle().pipe(
      map((data) => ({
        code: SUCCESS_CODE,
        type: 'SUCCESS',
        success: true,
        message: 'success',
        // 记录当前请求是由哪个类的哪个方法处理的
        tracing: `${context.getClass().name}#${context.getHandler().name}`,
        // traceId 已经在 main.ts 的全局中间件中初始化
        traceId: request.traceId,
        // 如果业务方法没有返回值(undefined)，则默认给 null
        data: data === undefined ? null : data,
      })),
    );
  }
}

// ============================================================================
// 全局异常过滤器 (Exception Filter)
// 作用：捕获应用中抛出的所有未处理异常（包括业务主动抛出的 HttpException 和未知的 Error）。
// 将这些异常统一转换为标准的 AjaxResult 格式返回给前端，防止将服务器内部的错误堆栈直接暴露给用户。
// ============================================================================
@Catch()
export class AjaxResultExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(AjaxResultExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();
    
    // traceId 已经在 main.ts 的全局中间件中初始化
    const traceId = request.traceId;

    // 默认的错误状态和信息
    let code = CODE_INTERNAL;
    let message = '服务器繁忙，请稍后再试';

    // 1. 处理自定义的鉴权失败异常
    if (exception instanceof AuthFailureException) {
      const body = exception.getResponse() as Record<string, unknown>;
      code = (body.code as string) ?? CODE_AU0002;
      message = (body.message as string) ?? MESSAGE_AU0002;
    } 
    // 2. 处理 NestJS 内置的 HTTP 异常（如 400 参数校验错误、404 找不到路由等）
    else if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const res = exception.getResponse() as Record<string, unknown> | string;
      
      // 如果是 400 错误，通常是 class-validator 校验失败，使用参数校验错误码
      code = status === HttpStatus.BAD_REQUEST ? CODE_VALIDATION : CODE_INTERNAL;
      
      if (typeof res === 'string') {
        message = res;
      } else if (typeof res === 'object' && res !== null) {
        code = (res.code as string) ?? code;
        // 如果是数组（通常是多个参数校验错误），则拼接成字符串
        message = Array.isArray(res.message) ? res.message.join('; ') : ((res.message as string) ?? message);
      }
    } 
    // 3. 处理其他未知的系统级 Error（如空指针、数据库连接失败等）
    else if (exception instanceof Error) {
      message = exception.message || message;
    }

    // 记录错误日志，方便后端排查问题
    this.logException(exception, request, code, message);

    // 统一返回 200 HTTP 状态码（即使是错误也返回 200，通过内部的 code 字段来标识业务错误）
    // 返回格式与正常请求保持一致，方便前端统一拦截处理
    response.status(HttpStatus.OK).json({
      code,
      type: 'ERROR',
      success: false,
      message,
      tracing: 'AjaxResultExceptionFilter',
      traceId,
      data: null,
    });
  }

  /**
   * 统一的异常日志记录方法
   * 区分了警告（客户端错误/鉴权失败）和错误（服务端异常，需打印堆栈）
   */
  private logException(exception: unknown, req: Request, code: string, msg: string): void {
    const base = `[${req.method} ${req.originalUrl || req.url}] code=${code} message=${msg}`;
    
    if (exception instanceof AuthFailureException) {
      this.logger.warn(`${base} (auth failure)`);
    } else if (exception instanceof HttpException) {
      const status = exception.getStatus();
      // 500 及以上的状态码视为服务端错误，打印堆栈
      if (status >= HttpStatus.INTERNAL_SERVER_ERROR) {
        this.logger.error(`${base} status=${status}`, exception.stack || exception.message);
      } else {
        // 400 等客户端错误只打印警告，不打印堆栈
        this.logger.warn(`${base} status=${status}`);
      }
    } else if (exception instanceof Error) {
      // 未知错误打印完整堆栈
      this.logger.error(`${base} name=${exception.name}`, exception.stack);
    } else {
      this.logger.error(`${base} exception=${String(exception)}`);
    }
  }
}
