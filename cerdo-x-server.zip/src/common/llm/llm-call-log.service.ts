import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';

/** 与 Chat Agent 调用链一致，便于检索与对账 */
export type LlmCallLogPayload = {
  phase: string;
  roundLabel: string;
  requestUrl: string;
  /** 精简请求（便于控制台一行摘要）；若缺省则 txt 仅用 requestFull */
  request?: Record<string, unknown>;
  /** 完整请求体（写入 txt，含 tools 全量定义） */
  requestFull?: Record<string, unknown>;
  /** 精简响应（控制台） */
  response?: Record<string, unknown>;
  /** 完整响应体（写入 txt） */
  responseFull?: Record<string, unknown>;
  error?: unknown;
  durationMs: number;
};

/**
 * 对上游 LLM（Chat Completions）的审计：
 * - 控制台：一行摘要
 * - 文件：按日期分子目录，同一天内所有调用追加写入同一 `llm-calls.txt`（避免每次请求单独建文件）
 */
@Injectable()
export class LlmCallLogService {
  private readonly logger = new Logger(LlmCallLogService.name);

  /** 串行化同一天文件的 append，避免并发请求下多段写入交错 */
  private txtAppendChain: Promise<void> = Promise.resolve();

  constructor(private readonly config: ConfigService) {}

  /**
   * 日志根目录：默认 `process.cwd()/logs/llm-calls`，可通过 LLM_CALL_LOG_DIR 覆盖（支持相对或绝对路径）。
   */
  private resolveLogRoot(): string {
    const raw = this.config.get<string>('LLM_CALL_LOG_DIR')?.trim();
    if (raw) {
      return path.isAbsolute(raw) ? raw : path.join(process.cwd(), raw);
    }
    return path.join(process.cwd(), 'logs', 'llm-calls');
  }

  private formatLocalDateYmd(d: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  private stringifyJson(value: unknown): string {
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return String(value);
    }
  }

  private formatError(err: unknown): string {
    if (err instanceof Error) {
      return `${err.name}: ${err.message}\n${err.stack ?? ''}`;
    }
    return this.stringifyJson(err);
  }

  private async buildTxtContent(payload: LlmCallLogPayload): Promise<string> {
    const lines: string[] = [];
    lines.push('=== LLM Chat Completions ===');
    lines.push(`time: ${new Date().toISOString()}`);
    lines.push(`phase: ${payload.phase}`);
    lines.push(`roundLabel: ${payload.roundLabel}`);
    lines.push(`durationMs: ${payload.durationMs}`);
    lines.push(`requestUrl: ${payload.requestUrl}`);
    lines.push('');
    lines.push('--- Request (full) ---');
    lines.push(
      this.stringifyJson(
        payload.requestFull ?? payload.request ?? {},
      ),
    );
    lines.push('');
    if (payload.error !== undefined) {
      lines.push('--- Error ---');
      lines.push(this.formatError(payload.error));
    } else {
      lines.push('--- Response (full) ---');
      lines.push(
        this.stringifyJson(
          payload.responseFull ?? payload.response ?? {},
        ),
      );
    }
    lines.push('');
    return lines.join('\n');
  }

  private async fileExists(filePath: string): Promise<boolean> {
    try {
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * 同一天写入同一文件；首条直接写，后续条目前加分隔线便于阅读。
   * 整段（含 buildTxtContent）挂在同一链上，避免 await 中间态导致并发交错。
   */
  private async appendTxtLog(payload: LlmCallLogPayload): Promise<string> {
    const root = this.resolveLogRoot();
    const dateDir = this.formatLocalDateYmd(new Date());
    const dir = path.join(root, dateDir);
    const filePath = path.join(dir, 'llm-calls.txt');

    const done = this.txtAppendChain.then(async () => {
      try {
        const content = await this.buildTxtContent(payload);
        await fs.mkdir(dir, { recursive: true });
        const exists = await this.fileExists(filePath);
        const separator = `\n\n${'='.repeat(80)}\n\n`;
        const toWrite = exists ? `${separator}${content}` : content;
        await fs.appendFile(filePath, toWrite, 'utf8');
      } catch (e: unknown) {
        this.logger.error(
          `LLM txt audit append failed: ${e instanceof Error ? e.message : String(e)}`,
        );
      }
    });
    this.txtAppendChain = done.catch(() => undefined);
    await done;
    return filePath;
  }

  async logChatCompletions(payload: LlmCallLogPayload): Promise<void> {
    const line = {
      phase: payload.phase,
      roundLabel: payload.roundLabel,
      requestUrl: payload.requestUrl,
      durationMs: payload.durationMs,
      requestKeys: payload.request ? Object.keys(payload.request) : [],
      hasError: payload.error !== undefined,
      hasResponse: Boolean(payload.response),
    };
    if (payload.error !== undefined) {
      this.logger.warn(
        `[${payload.phase}] ${payload.roundLabel} ${payload.durationMs}ms ${JSON.stringify(line)}`,
      );
    } else {
      this.logger.log(
        `[${payload.phase}] ${payload.roundLabel} ${payload.durationMs}ms ${JSON.stringify(line)}`,
      );
    }

    void this.appendTxtLog(payload)
      .catch((e: unknown) => {
        this.logger.error(
          `LLM txt audit write failed: ${e instanceof Error ? e.message : String(e)}`,
        );
      });
  }
}
