import { HttpService } from '@nestjs/axios';
import {
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
  SetMetadata,
  createParamDecorator,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import { createHash } from 'crypto';
import { Request } from 'express';
import { firstValueFrom } from 'rxjs';
import { CODE_AU0002, MESSAGE_AU0002, SUCCESS_CODE } from './ajax-result';

// ============================================================================
// 接口定义区
// 定义了从 UPM（统一权限管理系统）获取到的用户信息结构
// ============================================================================
export interface UpmUserInfo {
  userId: string;
  userName: string;
  userCode: string;
  email: string;
  mobile: string;
  orgId: string;
  orgName: string;
  [key: string]: unknown;
}

// ============================================================================
// 异常定义区
// 自定义鉴权失败异常，当 Token 缺失或无效时抛出此异常
// 会被 AjaxResultExceptionFilter 捕获并转换为统一的错误响应格式
// ============================================================================
export class AuthFailureException extends HttpException {
  constructor() {
    // 抛出 401 状态码，并附带特定的业务错误码和信息
    super({ code: CODE_AU0002, message: MESSAGE_AU0002 }, HttpStatus.UNAUTHORIZED);
  }
}

// ============================================================================
// 装饰器定义区
// 提供给 Controller 和路由方法使用的自定义装饰器
// ============================================================================

/**
 * @Public 装饰器
 * 用于标记某个 Controller 或方法不需要进行 Token 鉴权（如登录接口、健康检查接口）
 */
export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);

/**
 * @CurrentUser 装饰器
 * 用于在 Controller 方法参数中直接获取当前登录的用户信息
 * 例如：@CurrentUser() user: UpmUserInfo
 */
export const CurrentUser = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): UpmUserInfo | undefined => {
    const request = ctx.switchToHttp().getRequest<Request>();
    // request.user 是在 AuthGuard 鉴权通过后挂载上去的
    return request.user;
  },
);

// ============================================================================
// 鉴权服务 (AuthService)
// 负责与远端 UPM 系统交互，验证 Token 并获取用户信息
// ============================================================================
@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * 根据 Token 向 UPM 请求用户信息
   * @param token 客户端传来的鉴权 Token
   * @returns 验证通过后的用户信息
   */
  async loadUserByToken(token: string): Promise<UpmUserInfo> {
    // 1. 从环境变量获取 UPM 接口的配置信息
    const baseUrl = this.configService.get<string>('CERDO_UPM_BASE_URL')?.replace(/\/$/, '');
    const appId = this.configService.get<string>('CERDO_UPM_APP_ID')?.trim() ?? '';
    const appSecret = this.configService.get<string>('CERDO_UPM_APP_SECRET')?.trim() ?? '';

    if (!baseUrl || !appId || !appSecret) {
      this.logger.error('UPM configuration missing (baseUrl, appId, appSecret)');
      throw new AuthFailureException();
    }

    // 2. 生成请求 UPM 接口所需的签名 (Sign) 和时间戳
    const timeStamp = this.formatTimeStamp();
    const sign = this.buildSign(appId, timeStamp, appSecret);

    try {
      // 3. 发起 HTTP POST 请求到 UPM 获取 Profile
      const { data } = await firstValueFrom(
        this.httpService.post<Record<string, unknown>>(
          `${baseUrl}/upm/provider/auth/v1/profile`,
          { token }, // Token 放在请求体中
          { 
            headers: { source: appId, timeStamp, sign }, // 签名信息放在请求头中
            timeout: 10000 // 10秒超时
          },
        ),
      );

      // 4. 校验 UPM 返回的结果是否成功
      if (data?.code !== SUCCESS_CODE || data?.success === false || !data?.data) {
        throw new Error(`Invalid UPM response: ${JSON.stringify(data)}`);
      }
      
      // 5. 返回解析后的用户信息
      return data.data as UpmUserInfo;
    } catch (err) {
      this.logger.warn(`UPM profile failed: ${err instanceof Error ? err.message : String(err)}`);
      throw new AuthFailureException();
    }
  }

  /**
   * 生成 UPM 接口需要的时间戳格式：yyyyMMddHHmmss (东八区)
   */
  private formatTimeStamp(): string {
    const d = new Date();
    // 转换为东八区时间 (UTC+8)
    const utc = d.getTime() + d.getTimezoneOffset() * 60000;
    const nd = new Date(utc + 3600000 * 8);
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${nd.getFullYear()}${pad(nd.getMonth() + 1)}${pad(nd.getDate())}${pad(nd.getHours())}${pad(nd.getMinutes())}${pad(nd.getSeconds())}`;
  }

  /**
   * 生成 UPM 接口需要的 MD5 签名
   * 规则：将 appId、timeStamp、appSecret 拼接后进行 MD5 加密并转大写
   */
  private buildSign(appId: string, timeStamp: string, appSecret: string): string {
    // 注意：这里的 appSercert 是 UPM 接口的既定拼写，请勿修改为 appSecret
    const queryStr = `appId=${appId}&timeStamp=${timeStamp}&appSercert=${appSecret}`;
    return createHash('md5').update(queryStr, 'utf8').digest('hex').toUpperCase();
  }
}

// ============================================================================
// 全局鉴权守卫 (AuthGuard)
// 拦截所有进入系统的请求，校验其是否携带有效 Token，并提取用户信息
// ============================================================================
@Injectable()
export class AuthGuard implements CanActivate {
  private readonly logger = new Logger(AuthGuard.name);

  constructor(
    private readonly reflector: Reflector,
    private readonly configService: ConfigService,
    private readonly authService: AuthService,
  ) {}

  /**
   * 守卫的核心判断逻辑
   * 返回 true 表示放行，抛出异常或返回 false 表示拦截
   */
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    
    // 1. 检查当前路由或控制器上是否有 @Public 装饰器
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    // 2. 如果是公开接口，或者在白名单中，直接放行
    if (isPublic || this.isWhitelisted(request.path)) return true;

    // 3. 从请求头 (Header) 或 Cookie 中提取 Token
    const token = request.headers['token'] || request.cookies?.cerdo_token;
    const resolvedToken = typeof token === 'string' ? token.trim() : token?.[0]?.trim();

    // 4. 如果没有提取到 Token，直接拒绝访问
    if (!resolvedToken) {
      this.logger.warn(`Auth rejected: no token for ${request.path}`);
      throw new AuthFailureException();
    }

    // 5. 调用 AuthService 验证 Token，并将获取到的用户信息挂载到 request 对象上
    // 这样后续的 Controller 就可以通过 @CurrentUser() 装饰器获取到用户信息了
    request.user = await this.authService.loadUserByToken(resolvedToken);
    return true;
  }

  /**
   * 检查请求路径是否在免鉴权白名单中
   */
  private isWhitelisted(path: string): boolean {
    // 从环境变量获取白名单配置（逗号分隔的路径字符串）
    const raw = this.configService.get<string>('CERDO_APP_API_WHITE_NAME');
    // 默认的白名单路径：连通性测试接口和 Swagger 文档接口
    const list = ['/aifs/trump-web/api/ping', '/aifs/trump-web/api/health', '/api/docs'];
    
    if (raw?.trim()) {
      const parsed = raw.split(',').map((s) => s.trim()).filter(Boolean);
      list.push(...parsed); // 采用追加模式，避免覆盖默认的健康检查接口
    }
    
    // 判断当前请求路径是否完全匹配，或者是白名单路径的子路径
    return list.some((p) => path === p || path.startsWith(`${p}/`));
  }
}
