import { HttpModule } from '@nestjs/axios';
import { Global, Module } from '@nestjs/common';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { AjaxResultExceptionFilter, AjaxResultInterceptor } from './ajax-result';
import { AuthGuard, AuthService } from './auth';
import { LlmCallLogService } from './llm/llm-call-log.service';

/**
 * 通用模块 (CommonModule)
 * 这是一个全局模块 (@Global())，意味着它只需要在根模块 (AppModule) 中导入一次，
 * 其导出的服务 (exports) 就可以在整个应用中的任何模块里使用，而无需重复导入。
 *
 * 该模块主要负责注册应用级别的核心拦截器和守卫：
 * 1. APP_GUARD: 全局鉴权守卫，拦截所有请求进行 Token 校验
 * 2. APP_FILTER: 全局异常过滤器，捕获所有未处理的错误并格式化返回
 * 3. APP_INTERCEPTOR: 全局响应拦截器，将正常的返回数据包装成统一的 AjaxResult 格式
 * 4. LlmCallLogService: LLM 调用审计（控制台 + 文件），供 LlmClient 等注入使用
 */
@Global()
@Module({
  imports: [HttpModule], // 导入 HttpModule 以便 AuthService 可以发起网络请求
  providers: [
    AuthService,
    LlmCallLogService,
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_FILTER, useClass: AjaxResultExceptionFilter },
    { provide: APP_INTERCEPTOR, useClass: AjaxResultInterceptor },
  ],
  exports: [AuthService, HttpModule, LlmCallLogService],
})
export class CommonModule {}
