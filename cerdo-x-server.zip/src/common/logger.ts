import { Injectable, LoggerService } from '@nestjs/common';
import { AsyncLocalStorage } from 'async_hooks';
import * as winston from 'winston';
import 'winston-daily-rotate-file';

export const traceStorage = new AsyncLocalStorage<{ traceId: string }>();

// 自定义格式化：提取 traceId 和 context
const traceFormatter = winston.format((info) => {
  const store = traceStorage.getStore();
  info.traceIdStr = store?.traceId ? `[${store.traceId}] ` : '';
  info.contextStr = info.context ? `[${info.context}] ` : '';
  return info;
});

// 创建 Winston 日志实例
const winstonLogger = winston.createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  format: winston.format.combine(
    traceFormatter(),
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
    winston.format.printf(({ timestamp, level, message, traceIdStr, contextStr }) => {
      return `${timestamp} ${level.toUpperCase()} ${traceIdStr}${contextStr}${message}`;
    }),
  ),
  transports: [
    // 1. 控制台输出 (带颜色)
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize({ all: true }),
        winston.format.printf(({ timestamp, level, message, traceIdStr, contextStr }) => {
          return `${timestamp} ${level} ${traceIdStr}${contextStr}${message}`;
        }),
      ),
    }),
    // 2. 写入应用全量日志文件 (按天滚动)
    new winston.transports.DailyRotateFile({
      dirname: 'logs', // 日志文件夹
      filename: 'application-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true, // 压缩旧日志
      maxSize: '20m',      // 单个文件最大 20MB
      maxFiles: '14d',     // 保留 14 天
    }),
    // 3. 单独写入错误日志文件
    new winston.transports.DailyRotateFile({
      level: 'error',
      dirname: 'logs',
      filename: 'error-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '30d',     // 错误日志保留 30 天
    }),
  ],
});

/**
 * 自定义 NestJS 全局日志记录器
 * 代理所有 NestJS 的日志调用到 Winston
 */
@Injectable()
export class TraceLogger implements LoggerService {
  log(message: unknown, context?: string) {
    winstonLogger.info(String(message), { context });
  }

  error(message: unknown, trace?: string, context?: string) {
    winstonLogger.error(`${String(message)}${trace ? `\n${trace}` : ''}`, { context });
  }

  warn(message: unknown, context?: string) {
    winstonLogger.warn(String(message), { context });
  }

  debug?(message: unknown, context?: string) {
    winstonLogger.debug(String(message), { context });
  }

  verbose?(message: unknown, context?: string) {
    winstonLogger.verbose(String(message), { context });
  }
}
