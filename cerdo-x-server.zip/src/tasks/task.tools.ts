/**
 * task_* 工具的 OpenAI `tools` 定义；调度见 `TaskService.dispatchTaskTool`（详见 `API.md` §4.5）。
 */
export const TASK_TOOLS_OAI = [
  {
    type: 'function' as const,
    function: {
      name: 'task_create',
      description: 'Create a new task.',
      parameters: {
        type: 'object',
        properties: {
          subject: { type: 'string' },
          description: { type: 'string' },
        },
        required: ['subject'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'task_update',
      description: "Update a task's status or dependencies.",
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'integer' },
          status: {
            type: 'string',
            enum: ['pending', 'in_progress', 'completed', 'deleted'],
          },
          addBlockedBy: {
            type: 'array',
            items: { type: 'integer' },
          },
          removeBlockedBy: {
            type: 'array',
            items: { type: 'integer' },
          },
        },
        required: ['task_id'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'task_list',
      description: 'List all tasks with status summary.',
      parameters: {
        type: 'object',
        properties: {},
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'task_get',
      description: 'Get full details of a task by ID.',
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'integer' },
        },
        required: ['task_id'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'claim_task',
      description:
        'Claim a task by ID (sets owner and in_progress). Omit owner to default to lead. Mark completed with task_update when done.',
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'integer' },
          owner: { type: 'string', description: 'Claimant id; defaults to lead if omitted' },
        },
        required: ['task_id'],
      },
    },
  },
] as const;

export type TaskToolName =
  | 'task_create'
  | 'task_update'
  | 'task_list'
  | 'task_get'
  | 'claim_task';
