import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { TaskService } from './task.service';
import type { TaskStatus } from './task.types';

@Controller('api/tasks')
export class TaskController {
  constructor(private readonly tasks: TaskService) {}

  @Post()
  async create(@Body() body: { subject: string; description?: string }) {
    if (!body?.subject || typeof body.subject !== 'string') {
      throw new BadRequestException('subject is required');
    }
    const subject = body.subject.trim();
    if (!subject) {
      throw new BadRequestException('subject must not be empty');
    }
    const desc =
      body.description === undefined || body.description === null
        ? ''
        : String(body.description);
    return this.tasks.create(subject, desc);
  }

  @Get()
  async list(@Query('format') format?: string) {
    const list = await this.tasks.listAll();
    if (format === 'text') {
      return {
        format: 'text' as const,
        summary: this.tasks.formatSummary(list),
      };
    }
    return { tasks: list };
  }

  @Get(':id')
  async getOne(@Param('id', ParseIntPipe) id: number) {
    return this.tasks.get(id);
  }

  @Patch(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body()
    body: {
      status?: TaskStatus;
      addBlockedBy?: number[];
      removeBlockedBy?: number[];
    },
  ) {
    return this.tasks.update(id, {
      status: body?.status,
      addBlockedBy: body?.addBlockedBy,
      removeBlockedBy: body?.removeBlockedBy,
    });
  }
}
