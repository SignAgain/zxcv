/** 任务板持久化字段 */
export type TaskStatus = 'pending' | 'in_progress' | 'completed';

export interface Task {
  id: number;
  subject: string;
  description: string;
  status: TaskStatus;
  /** 依赖的上游任务 id；某任务 completed 后从其它任务的该列表中移除对应 id */
  blockedBy: number[];
  owner: string;
}
