import { Module } from '@nestjs/common';
import { TaskController } from './task.controller';
import { TaskService } from './task.service';

/** 导出 `TaskService` 与 `TASK_TOOLS_OAI` */
export { TASK_TOOLS_OAI } from './task.tools';

@Module({
  controllers: [TaskController],
  providers: [TaskService],
  exports: [TaskService],
})
export class TaskModule {}
