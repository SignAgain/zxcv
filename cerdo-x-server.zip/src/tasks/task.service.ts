/**
 * 持久化任务板（`.tasks/task_<id>.json`）；工具入口见 `dispatchTaskTool`。
 */
import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs/promises';
import * as path from 'path';
import type { Task, TaskStatus } from './task.types';
import type { TaskToolName } from './task.tools';

const VALID_STATUSES: TaskStatus[] = ['pending', 'in_progress', 'completed'];

@Injectable()
export class TaskService {
  private readonly tasksDir: string;
  private nextId: number;

  constructor(private readonly config: ConfigService) {
    const explicit = this.config.get<string>('TASKS_DIR')?.trim();
    const sub = this.config.get<string>('SUBAGENT_WORKDIR')?.trim();
    if (explicit) {
      this.tasksDir = path.isAbsolute(explicit)
        ? explicit
        : path.join(process.cwd(), explicit);
    } else if (sub) {
      const base = path.isAbsolute(sub) ? sub : path.join(process.cwd(), sub);
      this.tasksDir = path.join(base, '.tasks');
    } else {
      this.tasksDir = path.join(process.cwd(), '.tasks');
    }
    this.nextId = 0;
  }

  private async ensureDir(): Promise<void> {
    await fs.mkdir(this.tasksDir, { recursive: true });
  }

  private async maxId(): Promise<number> {
    let files: string[];
    try {
      files = await fs.readdir(this.tasksDir);
    } catch {
      return 0;
    }
    const ids = files
      .filter((f) => /^task_\d+\.json$/.test(f))
      .map((f) => Number.parseInt(f.slice('task_'.length, -'.json'.length), 10))
      .filter((n) => Number.isFinite(n));
    return ids.length ? Math.max(...ids) : 0;
  }

  async onModuleInit(): Promise<void> {
    await this.ensureDir();
    this.nextId = (await this.maxId()) + 1;
  }

  private taskPath(id: number): string {
    return path.join(this.tasksDir, `task_${id}.json`);
  }

  private async load(taskId: number): Promise<Task> {
    const p = this.taskPath(taskId);
    try {
      const raw = await fs.readFile(p, 'utf8');
      return JSON.parse(raw) as Task;
    } catch {
      throw new NotFoundException(`Task ${taskId} not found`);
    }
  }

  private async save(task: Task): Promise<void> {
    await this.ensureDir();
    await fs.writeFile(
      this.taskPath(task.id),
      JSON.stringify(task, null, 2),
      'utf8',
    );
  }

  private assertStatus(s: string): asserts s is TaskStatus {
    if (!VALID_STATUSES.includes(s as TaskStatus)) {
      throw new BadRequestException(`Invalid status: ${s}`);
    }
  }

  /** `in_progress` / `completed` 前：所有 `blockedBy` 指向的任务须已为 `completed` */
  private async assertBlockedDependenciesCompleted(task: Task): Promise<void> {
    for (const depId of task.blockedBy ?? []) {
      if (depId === task.id) {
        throw new BadRequestException(
          `Task ${task.id} cannot depend on itself`,
        );
      }
      let dep: Task;
      try {
        dep = await this.load(depId);
      } catch (e) {
        if (e instanceof NotFoundException) {
          throw new BadRequestException(
            `Blocked dependency task ${depId} does not exist`,
          );
        }
        throw e;
      }
      if (dep.status !== 'completed') {
        throw new BadRequestException(
          `Task ${task.id} is blocked by task ${depId} (status: ${dep.status})`,
        );
      }
    }
  }

  /** 任务完成后：从其它任务的 `blockedBy` 中移除该 id */
  private async clearDependency(completedId: number): Promise<void> {
    let files: string[];
    try {
      files = await fs.readdir(this.tasksDir);
    } catch {
      return;
    }
    for (const name of files) {
      if (!/^task_\d+\.json$/.test(name)) continue;
      const id = Number.parseInt(
        name.slice('task_'.length, -'.json'.length),
        10,
      );
      if (id === completedId) continue;
      let task: Task;
      try {
        task = await this.load(id);
      } catch {
        continue;
      }
      const blocked = task.blockedBy ?? [];
      if (!blocked.includes(completedId)) continue;
      task.blockedBy = blocked.filter((x) => x !== completedId);
      await this.save(task);
    }
  }

  async create(subject: string, description = ''): Promise<Task> {
    const task: Task = {
      id: this.nextId,
      subject,
      description,
      status: 'pending',
      blockedBy: [],
      owner: '',
    };
    await this.save(task);
    this.nextId += 1;
    return task;
  }

  async get(taskId: number): Promise<Task> {
    return this.load(taskId);
  }

  /**
   * 认领：设置 owner 与 `in_progress`。
   * 已被他人认领则失败。
   */
  async claim(taskId: number, owner: string): Promise<Task> {
    const task = await this.load(taskId);
    const existing = (task.owner ?? '').trim();
    if (existing && existing !== owner.trim()) {
      throw new BadRequestException(
        `Task ${taskId} has already been claimed by ${existing}`,
      );
    }
    if (task.status !== 'pending') {
      throw new BadRequestException(
        `Task ${taskId} cannot be claimed because its status is '${task.status}'`,
      );
    }
    task.owner = owner;
    task.status = 'in_progress';
    await this.assertBlockedDependenciesCompleted(task);
    await this.save(task);
    return task;
  }

  /** 未认领：pending、无 owner、无阻塞依赖 */
  async listUnclaimedTasks(): Promise<Task[]> {
    const all = await this.listAll();
    return all.filter(
      (t) =>
        t.status === 'pending' &&
        !(t.owner && String(t.owner).trim()) &&
        !t.blockedBy?.length,
    );
  }

  /** 从其它任务的 `blockedBy` 中移除对 `taskId` 的引用（删除或归档前调用） */
  private async stripDependencyReferences(taskId: number): Promise<void> {
    let files: string[];
    try {
      files = await fs.readdir(this.tasksDir);
    } catch {
      return;
    }
    for (const name of files) {
      if (!/^task_\d+\.json$/.test(name)) continue;
      const id = Number.parseInt(
        name.slice('task_'.length, -'.json'.length),
        10,
      );
      if (id === taskId) continue;
      let task: Task;
      try {
        task = await this.load(id);
      } catch {
        continue;
      }
      const blocked = task.blockedBy ?? [];
      if (!blocked.includes(taskId)) continue;
      task.blockedBy = blocked.filter((x) => x !== taskId);
      await this.save(task);
    }
  }

  /** `status === "deleted"`：删文件并清理依赖引用 */
  async deleteTask(taskId: number): Promise<string> {
    await this.load(taskId);
    await this.stripDependencyReferences(taskId);
    await fs.unlink(this.taskPath(taskId));
    return `Task ${taskId} deleted`;
  }

  async update(
    taskId: number,
    opts: {
      status?: TaskStatus;
      addBlockedBy?: number[];
      removeBlockedBy?: number[];
    },
  ): Promise<Task> {
    const task = await this.load(taskId);
    if (opts.status !== undefined) {
      this.assertStatus(opts.status);
      task.status = opts.status;
      if (opts.status === 'completed') {
        await this.clearDependency(taskId);
      }
    }
    if (opts.addBlockedBy?.length) {
      task.blockedBy = [
        ...new Set([...(task.blockedBy ?? []), ...opts.addBlockedBy]),
      ];
    }
    if (opts.removeBlockedBy?.length) {
      const remove = new Set(opts.removeBlockedBy);
      task.blockedBy = (task.blockedBy ?? []).filter((x) => !remove.has(x));
    }
    if (task.status === 'in_progress' || task.status === 'completed') {
      await this.assertBlockedDependenciesCompleted(task);
    }
    await this.save(task);
    return task;
  }

  async listAll(): Promise<Task[]> {
    await this.ensureDir();
    let files: string[];
    try {
      files = await fs.readdir(this.tasksDir);
    } catch {
      return [];
    }
    const jsonFiles = files
      .filter((f) => /^task_\d+\.json$/.test(f))
      .sort(
        (a, b) =>
          Number.parseInt(a.slice('task_'.length, -'.json'.length), 10) -
          Number.parseInt(b.slice('task_'.length, -'.json'.length), 10),
      );
    const tasks: Task[] = [];
    for (const f of jsonFiles) {
      const raw = await fs.readFile(path.join(this.tasksDir, f), 'utf8');
      tasks.push(JSON.parse(raw) as Task);
    }
    return tasks;
  }

  /** 任务列表可读摘要（多行文本） */
  formatSummary(tasks: Task[]): string {
    if (!tasks.length) return 'No tasks.';
    const marker: Record<TaskStatus, string> = {
      pending: '[ ]',
      in_progress: '[>]',
      completed: '[x]',
    };
    const lines: string[] = [];
    for (const t of tasks) {
      const m = marker[t.status] ?? '[?]';
      const blocked = t.blockedBy?.length
        ? ` (blocked by: [${t.blockedBy.join(', ')}])`
        : '';
      lines.push(`${m} #${t.id}: ${t.subject}${blocked}`);
    }
    return lines.join('\n');
  }

  /**
   * task_* 工具统一入口；返回字符串供 tool 消息使用（详见 `API.md` §4.5）。
   * 成功时：create/get/update 为 JSON；list 为 `formatSummary` 文本。
   */
  async dispatchTaskTool(
    name: TaskToolName,
    input: Record<string, unknown>,
  ): Promise<string> {
    try {
      switch (name) {
        case 'task_create': {
          const subject = input.subject;
          if (typeof subject !== 'string' || !subject.trim()) {
            throw new Error('subject is required');
          }
          const d = input.description;
          const desc =
            d === undefined || d === null
              ? ''
              : typeof d === 'string'
                ? d
                : JSON.stringify(d);
          const task = await this.create(subject.trim(), desc);
          return JSON.stringify(task, null, 2);
        }
        case 'task_get': {
          const raw = input.task_id;
          const taskId =
            typeof raw === 'number' ? raw : Number.parseInt(String(raw), 10);
          if (!Number.isFinite(taskId)) {
            throw new Error('task_id is required');
          }
          const task = await this.get(taskId);
          return JSON.stringify(task, null, 2);
        }
        case 'task_update': {
          const raw = input.task_id;
          const taskId =
            typeof raw === 'number' ? raw : Number.parseInt(String(raw), 10);
          if (!Number.isFinite(taskId)) {
            throw new Error('task_id is required');
          }
          const status = input.status;
          if (typeof status === 'string' && status === 'deleted') {
            return await this.deleteTask(taskId);
          }
          const addBlockedBy = asIntArray(input.addBlockedBy);
          const removeBlockedBy = asIntArray(input.removeBlockedBy);
          const nextStatus: TaskStatus | undefined =
            typeof status === 'string' ? (status as TaskStatus) : undefined;
          const task = await this.update(taskId, {
            status: nextStatus,
            addBlockedBy,
            removeBlockedBy,
          });
          return JSON.stringify(task, null, 2);
        }
        case 'claim_task': {
          const raw = input.task_id;
          const taskId =
            typeof raw === 'number' ? raw : Number.parseInt(String(raw), 10);
          if (!Number.isFinite(taskId)) {
            throw new Error('task_id is required');
          }
          const ownerRaw = input.owner;
          const owner =
            typeof ownerRaw === 'string' && ownerRaw.trim()
              ? ownerRaw.trim()
              : 'lead';
          const task = await this.claim(taskId, owner);
          return `Claimed task #${taskId} for ${task.owner}`;
        }
        case 'task_list':
          return this.formatSummary(await this.listAll());
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      return `Error: ${msg}`;
    }
  }
}

function asIntArray(v: unknown): number[] | undefined {
  if (v === undefined || v === null) return undefined;
  if (!Array.isArray(v)) return undefined;
  const out: number[] = [];
  for (const x of v) {
    const n = typeof x === 'number' ? x : Number.parseInt(String(x), 10);
    if (!Number.isFinite(n)) return undefined;
    out.push(n);
  }
  return out;
}
