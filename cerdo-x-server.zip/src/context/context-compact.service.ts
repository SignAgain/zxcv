import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { promises as fs } from 'node:fs';
import * as path from 'node:path';
import { AgentMessage } from '../types/agent-message';
import { LlmClient } from '../utils/llm-client';

/** micro 压缩时保留最近几条完整 tool 结果（运行时可用 `AGENT_KEEP_RECENT_TOOL_RESULTS` 覆盖） */
export const DEFAULT_KEEP_RECENT_TOOL_RESULTS = 6;
/** @deprecated 请使用 `DEFAULT_KEEP_RECENT_TOOL_RESULTS` 或配置项 */
export const KEEP_RECENT_TOOL_RESULTS = DEFAULT_KEEP_RECENT_TOOL_RESULTS;
/** 折叠旧 `bash` 结果时保留的尾部字符数（0=仅占位符，与旧行为一致；可用 `AGENT_BASH_FOLD_TAIL_CHARS` 覆盖） */
export const DEFAULT_BASH_FOLD_TAIL_CHARS = 1200;
/** 粗估 token 超过此默认值则自动 `autoCompact`（可用 `AGENT_CONTEXT_TOKEN_THRESHOLD` 覆盖） */
export const DEFAULT_CONTEXT_TOKEN_THRESHOLD = 50_000;
const SUMMARY_TAIL_CHARS = 80_000;
const MAX_TOKENS_SUMMARY = 2000;

const PRESERVE_RESULT_TOOLS = new Set(['read_file', 'task_list']);

/** 对话压缩：Layer1 旧 tool 结果占位；Layer2 落盘 transcript + LLM 摘要。 */
@Injectable()
export class ContextCompactService {
  private readonly logger = new Logger(ContextCompactService.name);

  constructor(
    private readonly config: ConfigService,
    private readonly llm: LlmClient,
  ) {}

  private workspaceRoot(): string {
    return this.config.get<string>('AGENT_WORKSPACE_ROOT') || process.cwd();
  }

  /** 可用 `AGENT_KEEP_RECENT_TOOL_RESULTS` 覆盖，至少为 1 */
  keepRecentToolResults(): number {
    const raw = this.config.get<string | number>('AGENT_KEEP_RECENT_TOOL_RESULTS');
    if (typeof raw === 'number' && Number.isFinite(raw) && raw >= 1) {
      return Math.floor(raw);
    }
    if (typeof raw === 'string' && raw.trim()) {
      const n = Number.parseInt(raw, 10);
      if (Number.isFinite(n) && n >= 1) return n;
    }
    return DEFAULT_KEEP_RECENT_TOOL_RESULTS;
  }

  /**
   * 折叠旧 bash 时保留的尾部长度；0 表示仅占位 `[Previous: used bash]`。
   * 可用 `AGENT_BASH_FOLD_TAIL_CHARS` 覆盖。
   */
  bashFoldTailChars(): number {
    const raw = this.config.get<string | number>('AGENT_BASH_FOLD_TAIL_CHARS');
    if (typeof raw === 'number' && Number.isFinite(raw) && raw >= 0) {
      return Math.floor(raw);
    }
    if (typeof raw === 'string' && raw.trim()) {
      const n = Number.parseInt(raw, 10);
      if (Number.isFinite(n) && n >= 0) return n;
    }
    return DEFAULT_BASH_FOLD_TAIL_CHARS;
  }

  /** 可用 `AGENT_CONTEXT_TOKEN_THRESHOLD` 覆盖 */
  thresholdTokens(): number {
    const raw = this.config.get<string | number>('AGENT_CONTEXT_TOKEN_THRESHOLD');
    if (typeof raw === 'number' && Number.isFinite(raw) && raw > 0) {
      return Math.floor(raw);
    }
    if (typeof raw === 'string' && raw.trim()) {
      const n = Number.parseInt(raw, 10);
      if (Number.isFinite(n) && n > 0) return n;
    }
    return DEFAULT_CONTEXT_TOKEN_THRESHOLD;
  }

  estimateTokens(messages: AgentMessage[]): number {
    return Math.floor(JSON.stringify(messages).length / 4);
  }

  /**
   * Layer 1：较早的 tool 结果压缩（保留最近 N 条完整结果；read_file / task_list 始终保留原文）。
   * 对 `bash`：默认保留尾部若干字符，避免模型只看到 `[Previous: used bash]` 而重复跑命令。
   */
  microCompactInPlace(messages: AgentMessage[]): void {
    const keepRecent = this.keepRecentToolResults();
    const toolIndices: number[] = [];
    for (let i = 0; i < messages.length; i++) {
      if (messages[i].role === 'tool') toolIndices.push(i);
    }
    if (toolIndices.length <= keepRecent) return;

    const toolNameMap = new Map<string, string>();
    for (const m of messages) {
      if (m.role !== 'assistant' || !m.toolCalls?.length) continue;
      for (const tc of m.toolCalls) {
        if (tc.id) toolNameMap.set(tc.id, tc.name ?? 'unknown');
      }
    }

    const toClear = toolIndices.slice(0, -keepRecent);
    for (const idx of toClear) {
      const msg = messages[idx];
      if (msg.role !== 'tool') continue;
      const content = msg.content ?? '';
      if (content.length <= 100) continue;
      const toolId = msg.toolCallId ?? '';
      const toolName = toolNameMap.get(toolId) ?? 'unknown';
      if (PRESERVE_RESULT_TOOLS.has(toolName)) continue;
      msg.content = this.foldCompactedToolContent(toolName, content);
    }
  }

  /** 被 micro 折叠的非保留类 tool 正文 */
  private foldCompactedToolContent(toolName: string, content: string): string {
    const tailLimit = this.bashFoldTailChars();
    if (toolName === 'bash' && tailLimit > 0 && content.length > tailLimit) {
      const tail = content.slice(-tailLimit);
      return (
        `[Previous bash output truncated; last ${tailLimit} chars:]\n` + tail
      );
    }
    return `[Previous: used ${toolName}]`;
  }

  /** Layer 2：完整 transcript 落盘，尾部摘要，用单条 user 消息替换。 */
  async autoCompact(messages: AgentMessage[]): Promise<AgentMessage[]> {
    const root = path.resolve(this.workspaceRoot());
    const dir = path.join(root, '.transcripts');
    await fs.mkdir(dir, { recursive: true });
    const transcriptPath = path.join(
      dir,
      `transcript_${Math.floor(Date.now() / 1000)}.jsonl`,
    );
    const lines = messages.map((m) => JSON.stringify(m));
    await fs.writeFile(transcriptPath, `${lines.join('\n')}\n`, 'utf8');

    const conversationText = JSON.stringify(messages);
    const tail =
      conversationText.length > SUMMARY_TAIL_CHARS
        ? conversationText.slice(-SUMMARY_TAIL_CHARS)
        : conversationText;

    const model = this.config.get<string>('LLM_MODEL') ?? 'kimi-k2.5';
    const res = await this.llm.streamChat(
      {
        messages: [
          {
            role: 'user',
            content:
              'Summarize this conversation for continuity. Include: ' +
              '1) What was accomplished, 2) Current state, 3) Key decisions made. ' +
              'Be concise but preserve critical details.\n\n' +
              tail,
          },
        ],
        tools: [],
        model,
        maxOutputTokens: MAX_TOKENS_SUMMARY,
        thinkingEnabled: false,
        logMeta: {
          phase: 'context.auto_compact',
          roundLabel: 'summary',
        },
      },
      {},
    );

    const summary =
      res.message.content?.trim() ?? '(no summary text)';
    return [
      {
        role: 'user',
        content: `[Conversation compressed. Transcript: ${transcriptPath}]\n\n${summary}`,
      },
    ];
  }

  /**
   * QueryEngine 每轮 `streamChat` 前：先 microCompact，超阈值则 autoCompact 并保留首条 system。
   * `compress` 工具标记后由 `applyManualCompressRequest` 处理（优先 autoCompact，失败则仅 micro）。
   */
  async applyRoundCompactIfNeeded(messages: AgentMessage[]): Promise<{
    compacted: boolean;
    tokensBefore: number;
    tokensAfter: number;
  }> {
    this.microCompactInPlace(messages);
    const tokensBefore = this.estimateTokens(messages);
    const limit = this.thresholdTokens();
    if (tokensBefore <= limit) {
      return { compacted: false, tokensBefore, tokensAfter: tokensBefore };
    }

    const systemMsg = messages.find((m) => m.role === 'system');
    const systemContent = systemMsg?.content ?? '';

    try {
      const snapshot = messages.map((m) => ({ ...m }));
      const replaced = await this.autoCompact(snapshot);
      messages.length = 0;
      if (systemContent) {
        messages.push({ role: 'system', content: systemContent });
      }
      messages.push(...replaced);
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : String(e);
      this.logger.warn(
        `autoCompact (threshold) failed, keeping micro-compacted messages only: ${err}`,
      );
    }

    return {
      compacted: true,
      tokensBefore,
      tokensAfter: this.estimateTokens(messages),
    };
  }

  async applyManualCompressRequest(messages: AgentMessage[]): Promise<AgentMessage[]> {
    const copy = messages.map((m) => ({ ...m }));
    try {
      return await this.autoCompact(copy);
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : String(e);
      this.logger.warn(`autoCompact failed, falling back to microCompact: ${err}`);
      this.microCompactInPlace(copy);
      return copy;
    }
  }
}
