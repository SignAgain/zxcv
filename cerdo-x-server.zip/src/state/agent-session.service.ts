import { Injectable, NotFoundException } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { Subject } from 'rxjs';
import { AgentMessage } from '../types/agent-message';
import { StreamClientEvent } from '../types/stream-client-event';

interface AgentSession {
  id: string;
  messages: AgentMessage[];
  sequenceNum: number;
  stream$: Subject<StreamClientEvent>;
  createdAt: string;
}

/**
 * 会话内存状态服务：
 * - 管理 session 生命周期
 * - 保存消息历史
 * - 为 SSE 提供按会话隔离的事件通道
 */
@Injectable()
export class AgentSessionService {
  private readonly sessions = new Map<string, AgentSession>();

  createSession(): AgentSession {
    const id = randomUUID();
    const session: AgentSession = {
      id,
      messages: [],
      sequenceNum: 0,
      stream$: new Subject<StreamClientEvent>(),
      createdAt: new Date().toISOString(),
    };
    this.sessions.set(id, session);
    return session;
  }

  getSession(sessionId: string): AgentSession {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new NotFoundException(`Session not found: ${sessionId}`);
    }
    return session;
  }

  getMessages(sessionId: string): AgentMessage[] {
    return [...this.getSession(sessionId).messages];
  }

  setMessages(sessionId: string, messages: AgentMessage[]): void {
    const session = this.getSession(sessionId);
    session.messages = [...messages];
  }

  stream(sessionId: string): Subject<StreamClientEvent> {
    return this.getSession(sessionId).stream$;
  }

  publish(
    sessionId: string,
    eventType: string,
    source: string,
    payload: Record<string, unknown>,
  ): StreamClientEvent {
    const session = this.getSession(sessionId);
    // 序号在单个会话内单调递增，便于客户端按序消费事件。
    session.sequenceNum += 1;

    const event: StreamClientEvent = {
      event_id: randomUUID(),
      sequence_num: session.sequenceNum,
      event_type: eventType,
      source,
      payload,
      created_at: new Date().toISOString(),
    };

    session.stream$.next(event);
    return event;
  }
}
