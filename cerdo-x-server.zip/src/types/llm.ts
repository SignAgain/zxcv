import { AgentMessage, ToolCall } from './agent-message';
import { OpenAIFunctionTool } from './tool';

export interface LlmStreamCallbacks {
  onDelta?: (text: string) => void;
}

export interface LlmChatRequest {
  messages: AgentMessage[];
  tools: OpenAIFunctionTool[];
  model?: string;
  temperature?: number;
  topP?: number;
  maxOutputTokens?: number;
  thinkingEnabled?: boolean;
  /** 写入 `logs/llm-calls` 时的 phase / roundLabel，便于区分 QueryEngine 轮次与子调用 */
  logMeta?: {
    phase?: string;
    roundLabel?: string;
  };
}

export interface LlmChatResponse {
  message: AgentMessage;
  toolCalls: ToolCall[];
}
