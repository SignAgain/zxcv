import { AgentMessage } from './agent-message';
import { OpenAIFunctionTool } from './tool';

export interface QueryEvent {
  eventType: string;
  source: string;
  payload: Record<string, unknown>;
}

export interface QueryLifecycleHooks {
  onMessage?: (message: AgentMessage) => void;
  onToolCall?: (toolName: string, input: Record<string, unknown>) => void;
  onToolResult?: (toolName: string, result: unknown) => void;
  onTurnComplete?: (turn: number) => void;
}

export interface QueryParams {
  messages: AgentMessage[];
  tools: OpenAIFunctionTool[];
  maxTurns?: number;
  model?: string;
  temperature?: number;
  topP?: number;
  maxOutputTokens?: number;
  thinkingEnabled?: boolean;
  hooks?: QueryLifecycleHooks;
  onEvent?: (event: QueryEvent) => void;
}

export interface QueryResult {
  messages: AgentMessage[];
  finalText: string;
}
