import { AgentMessage } from './agent-message';
import { QueryResult } from './query';

export interface AgentRuntimeConfig {
  model?: string;
  maxTurns?: number;
  temperature?: number;
  topP?: number;
  maxOutputTokens?: number;
  thinkingEnabled?: boolean;
}

export interface AgentRuntimeHooks {
  beforeQuery?: (prompt: string) => Promise<void>;
  afterQuery?: (result: QueryResult) => Promise<void>;
  onError?: (error: Error) => Promise<void>;
}

export interface RuntimeExecuteInput {
  prompt: string;
  history: AgentMessage[];
  /** 与会话绑定，供 TodoWrite / compress 等工具使用 */
  sessionId?: string;
  onEvent?: (eventType: string, source: string, payload: Record<string, unknown>) => void;
}
