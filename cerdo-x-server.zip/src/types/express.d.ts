import type { UpmUserInfo } from '../common/auth';

declare global {
  namespace Express {
    interface Request {
      user?: UpmUserInfo;
      traceId?: string;
    }
  }
}

export {};
