export interface StreamClientEvent {
  event_id: string;
  sequence_num: number;
  event_type: string;
  source: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export const StreamEventType = {
  SessionCreated: 'session.created',
  RunStarted: 'run.started',
  LlmDelta: 'llm.delta',
  ToolCall: 'tool.call',
  ToolResult: 'tool.result',
  RunCompleted: 'run.completed',
  RunFailed: 'run.failed',
  Heartbeat: 'session.heartbeat',
} as const;

export const StreamSource = {
  SessionService: 'session_service',
  Runtime: 'agent_runtime',
  QueryEngine: 'query_engine',
  LlmClient: 'llm_client',
  ToolRegistry: 'tool_registry',
} as const;
