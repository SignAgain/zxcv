import { ZodTypeAny } from 'zod';

/** 与 `tools/infra/background/background-manager` 中完成通知一致，供注入与事件使用 */
export type BackgroundNotification = {
  task_id: string;
  status: string;
  command: string;
  result: string;
};

/**
 * Chat Agent 注入的后台 shell 能力；AgentRuntime 注入后 `background_*` 工具与 QueryEngine 共用同一 BackgroundManager。
 */
export interface BackgroundShellContext {
  /** `timeout`：毫秒（对应工具侧「秒」参数，由调用方换算）。 */
  run(command: string, timeoutMs?: number): string;
  check(taskId?: string): string;
  /** 取出并清空已完成任务的通知队列 */
  drainNotifications(): BackgroundNotification[];
}

export interface ToolContext {
  workspaceRoot: string;
  /** 与 Agent 会话绑定；未通过 HTTP 会话调用时可能为空 */
  sessionId?: string;
  background?: BackgroundShellContext;
}

export interface ToolResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface AgentTool<Input = unknown, Output = unknown> {
  name: string;
  description: string;
  inputSchema: ZodTypeAny;
  inputJsonSchema: Record<string, unknown>;
  isReadOnly: boolean;
  call(input: Input, context: ToolContext): Promise<ToolResult<Output>>;
}

export interface OpenAIFunctionTool {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
}
