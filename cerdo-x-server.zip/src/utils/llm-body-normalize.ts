/**
 * 与上游 chat/completions 请求体中的数值字段约定一致（与 LlmClient 原逻辑对齐）。
 */
export function normalizeLlmTemperature(temperature?: number): number {
  if (typeof temperature !== 'number' || Number.isNaN(temperature)) {
    return 1.0;
  }
  return Math.max(0, Math.min(2, temperature));
}

export function normalizeLlmTopP(topP?: number): number {
  if (typeof topP !== 'number' || Number.isNaN(topP)) {
    return 0.95;
  }
  return Math.max(0, Math.min(1, topP));
}

export function normalizeLlmMaxOutputTokens(maxOutputTokens?: number): number {
  if (typeof maxOutputTokens !== 'number' || Number.isNaN(maxOutputTokens)) {
    return 1024;
  }
  return Math.max(1, Math.floor(maxOutputTokens));
}

/** kimi Instant：通过 extra_body 关闭 thinking */
export function buildLlmThinkingExtraBody(
  thinkingEnabled?: boolean,
): Record<string, unknown> {
  if (thinkingEnabled === false) {
    return {
      extra_body: {
        chat_template_kwargs: {
          thinking: false,
        },
      },
    };
  }
  return {};
}
