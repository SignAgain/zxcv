import { AgentMessage, ToolCall } from '../types/agent-message';
import { OpenAIFunctionTool } from '../types/tool';

/**
 * 单条 AgentMessage 转为 OpenAI chat/completions 的 message 对象。
 */
export function agentMessageToOpenAiRecord(
  message: AgentMessage,
): Record<string, unknown> | null {
  if (!message || !message.role) {
    return null;
  }

  const normalizedContent = typeof message.content === 'string' ? message.content : '';

  if (message.role === 'assistant') {
    const toolCalls = message.toolCalls?.length
      ? message.toolCalls.map((toolCall) => ({
          id: toolCall.id,
          type: 'function',
          function: {
            name: toolCall.name,
            arguments: JSON.stringify(toolCall.input ?? {}),
          },
        }))
      : undefined;

    return {
      role: 'assistant',
      content: normalizedContent,
      ...(toolCalls ? { tool_calls: toolCalls } : {}),
    };
  }

  if (message.role === 'tool') {
    if (!message.toolCallId) {
      return null;
    }
    return {
      role: 'tool',
      content: normalizedContent,
      tool_call_id: message.toolCallId,
    };
  }

  return {
    role: message.role,
    content: normalizedContent,
  };
}

export function sanitizeAgentMessagesForOpenAi(
  messages: AgentMessage[],
): Array<Record<string, unknown>> {
  const normalized = messages
    .map((msg) => agentMessageToOpenAiRecord(msg))
    .filter((msg): msg is Record<string, unknown> => Boolean(msg));

  if (!normalized.length) {
    return [{ role: 'user', content: '' }];
  }
  return normalized;
}

export function sanitizeOpenAiTools(
  tools: OpenAIFunctionTool[] | undefined,
): OpenAIFunctionTool[] | undefined {
  if (!tools?.length) {
    return undefined;
  }
  return tools.filter((item) => Boolean(item?.function?.name));
}

/**
 * 按 function.name 去重合并多路 tools；先出现的优先（Agent 白名单优先于内置补全列表）。
 */
export function mergeOpenAiToolsDistinct(
  ...groups: OpenAIFunctionTool[][]
): OpenAIFunctionTool[] {
  const seen = new Set<string>();
  const out: OpenAIFunctionTool[] = [];
  for (const group of groups) {
    if (!group?.length) continue;
    for (const t of group) {
      const name = t?.function?.name;
      if (!name || seen.has(name)) continue;
      seen.add(name);
      out.push(t);
    }
  }
  return out;
}

/** 解析 function.arguments 字符串，与 LlmClient.safeParseArguments 行为一致 */
export function safeParseToolArgumentsJson(raw: string): Record<string, unknown> {
  if (!raw.trim()) {
    return {};
  }

  try {
    const parsed = JSON.parse(raw) as unknown;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
    return { value: parsed };
  } catch {
    return { raw };
  }
}

export function parseOpenAiToolCallsToToolCalls(
  raw: Array<{
    id: string;
    type?: string;
    function?: { name?: string; arguments?: string };
  }>,
): ToolCall[] {
  return raw
    .filter((tc) => !tc.type || tc.type === 'function')
    .map((tc) => ({
      id: tc.id,
      name: tc.function?.name ?? '',
      input: safeParseToolArgumentsJson(tc.function?.arguments ?? ''),
    }));
}
