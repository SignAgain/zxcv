import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { LlmCallLogService } from '../common/llm/llm-call-log.service';
import { ToolCall } from '../types/agent-message';
import { LlmChatRequest, LlmChatResponse, LlmStreamCallbacks } from '../types/llm';
import {
  buildLlmThinkingExtraBody,
  normalizeLlmMaxOutputTokens,
  normalizeLlmTemperature,
  normalizeLlmTopP,
} from './llm-body-normalize';
import { safeParseToolArgumentsJson, sanitizeAgentMessagesForOpenAi, sanitizeOpenAiTools } from './openai-messages';

interface OpenAIToolCallDelta {
  index: number;
  id?: string;
  function?: {
    name?: string;
    arguments?: string;
  };
}

/**
 * OpenAI 兼容协议客户端：
 * - 请求 chat/completions(stream=true)
 * - 解析上游 SSE 增量
 * - 汇总 assistant 文本与 tool_calls
 */
@Injectable()
export class LlmClient {
  constructor(
    private readonly configService: ConfigService,
    private readonly llmCallLog: LlmCallLogService,
  ) {}

  async streamChat(request: LlmChatRequest, callbacks: LlmStreamCallbacks = {}): Promise<LlmChatResponse> {
    const baseUrl = (this.configService.get<string>('LLM_BASE_URL') || 'https://aigw.fsfund.com/v1').replace(/\/$/, '');
    const apiKey = this.configService.get<string>('LLM_API_KEY') || '';
    const model = request.model || this.configService.get<string>('LLM_MODEL') || 'kimi-k2.5';
    const requestUrl = `${baseUrl}/chat/completions`;
    const start = Date.now();
    const phase = request.logMeta?.phase ?? 'llm.streamChat';
    const roundLabel = request.logMeta?.roundLabel ?? '';

    const emitAudit = (opts: {
      requestFull: Record<string, unknown>;
      responseFull?: Record<string, unknown>;
      error?: unknown;
    }): void => {
      void this.llmCallLog.logChatCompletions({
        phase,
        roundLabel,
        requestUrl,
        request: opts.requestFull,
        requestFull: opts.requestFull,
        responseFull: opts.responseFull,
        response: opts.responseFull,
        error: opts.error,
        durationMs: Date.now() - start,
      });
    };

    if (!apiKey) {
      const err = new Error('LLM_API_KEY is not configured');
      emitAudit({ requestFull: { note: 'skipped_fetch_no_api_key' }, error: err });
      throw err;
    }

    const bodyPrimary = this.buildChatCompletionsBody({ model, request, disableTools: false });
    let response = await this.requestChatCompletions({
      baseUrl,
      apiKey,
      model,
      request,
      disableTools: false,
    });

    // 某些 OpenAI 兼容网关在处理 tools 时会触发服务端 panic（500），
    // 命中已知 panic 关键字后自动降级为「无 tools」重试一次，尽量保证对话可继续。
    if (!response.ok && this.shouldRetryWithoutTools(response.status)) {
      const errText = await response.text();
      if (this.isUpstreamPanic(errText)) {
        const bodyFallback = this.buildChatCompletionsBody({ model, request, disableTools: true });
        const retryResponse = await this.requestChatCompletions({
          baseUrl,
          apiKey,
          model,
          request,
          disableTools: true,
        });
        if (!retryResponse.ok) {
          const retryErrText = await retryResponse.text();
          emitAudit({
            requestFull: {
              primary: bodyPrimary,
              fallbackWithoutTools: bodyFallback,
              primaryError: errText,
              fallbackError: retryErrText,
            },
            error: new Error(`LLM request failed: ${retryResponse.status} ${retryErrText}`),
          });
          throw new Error(`LLM request failed: ${retryResponse.status} ${retryErrText}`);
        }
        try {
          const result = await this.consumeStreamResponse(retryResponse, callbacks);
          emitAudit({
            requestFull: {
              primaryFailed: bodyPrimary,
              upstreamPanic: errText,
              successfulRequest: bodyFallback,
              retriedWithoutTools: true,
            },
            responseFull: {
              message: result.message,
              toolCalls: result.toolCalls,
            },
          });
          return result;
        } catch (e: unknown) {
          emitAudit({
            requestFull: {
              primaryFailed: bodyPrimary,
              upstreamPanic: errText,
              successfulRequest: bodyFallback,
              retriedWithoutTools: true,
            },
            error: e,
          });
          throw e;
        }
      }
      emitAudit({
        requestFull: bodyPrimary,
        error: new Error(`LLM request failed: ${response.status} ${errText}`),
      });
      throw new Error(`LLM request failed: ${response.status} ${errText}`);
    }

    if (!response.ok) {
      const errText = await response.text();
      emitAudit({
        requestFull: bodyPrimary,
        error: new Error(`LLM request failed: ${response.status} ${errText}`),
      });
      throw new Error(`LLM request failed: ${response.status} ${errText}`);
    }

    try {
      const result = await this.consumeStreamResponse(response, callbacks);
      emitAudit({
        requestFull: bodyPrimary,
        responseFull: {
          message: result.message,
          toolCalls: result.toolCalls,
        },
      });
      return result;
    } catch (e: unknown) {
      emitAudit({ requestFull: bodyPrimary, error: e });
      throw e;
    }
  }

  private async consumeStreamResponse(response: Response, callbacks: LlmStreamCallbacks): Promise<LlmChatResponse> {

    if (!response.body) {
      throw new Error('LLM response body is empty');
    }

    const decoder = new TextDecoder();
    const reader = response.body.getReader();
    let buffer = '';
    let content = '';
    const toolCallMap = new Map<number, { id: string; name: string; arguments: string }>();
    const consumeDataLine = (rawLine: string) => {
      const line = rawLine.trim();
      if (!line.startsWith('data:')) return;

      const data = line.replace(/^data:\s*/, '');
      if (!data || data === '[DONE]') {
        return;
      }

      // 逐帧解析 delta，兼容 content 与 tool_calls 同时增量返回。
      const chunk = JSON.parse(data) as {
        choices?: Array<{
          delta?: {
            content?: string;
            tool_calls?: OpenAIToolCallDelta[];
          };
        }>;
      };

      const delta = chunk.choices?.[0]?.delta;
      if (!delta) return;

      if (delta.content) {
        content += delta.content;
        callbacks.onDelta?.(delta.content);
      }

      if (delta.tool_calls?.length) {
        for (const item of delta.tool_calls) {
          // 按 index 聚合 tool_calls，直到参数片段拼接完整。
          const existing = toolCallMap.get(item.index) || {
            id: item.id || `tool_call_${item.index}`,
            name: '',
            arguments: '',
          };

          if (item.id) existing.id = item.id;
          if (item.function?.name) existing.name = item.function.name;
          if (item.function?.arguments) existing.arguments += item.function.arguments;

          toolCallMap.set(item.index, existing);
        }
      }
    };

    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        // 兼容尾包没有换行的场景，避免最后一个 chunk 丢失。
        if (buffer.trim()) {
          consumeDataLine(buffer);
        }
        break;
      }

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() ?? '';

      for (const rawLine of lines) {
        consumeDataLine(rawLine);
      }
    }

    const toolCalls: ToolCall[] = Array.from(toolCallMap.values()).map((item) => ({
      id: item.id,
      name: item.name,
      input: safeParseToolArgumentsJson(item.arguments),
    }));

    return {
      message: {
        role: 'assistant',
        content,
        toolCalls,
      },
      toolCalls,
    };
  }

  /** 与发往上游的 POST body 一致（用于审计文件） */
  private buildChatCompletionsBody(input: {
    model: string;
    request: LlmChatRequest;
    disableTools: boolean;
  }): Record<string, unknown> {
    const sanitizedMessages = sanitizeAgentMessagesForOpenAi(input.request.messages);
    const tools = input.disableTools ? undefined : sanitizeOpenAiTools(input.request.tools);
    return {
      model: input.model,
      messages: sanitizedMessages,
      ...(tools ? { tools } : {}),
      stream: true,
      temperature: normalizeLlmTemperature(input.request.temperature),
      top_p: normalizeLlmTopP(input.request.topP),
      max_tokens: normalizeLlmMaxOutputTokens(input.request.maxOutputTokens),
      ...buildLlmThinkingExtraBody(input.request.thinkingEnabled),
    };
  }

  private async requestChatCompletions(input: {
    baseUrl: string;
    apiKey: string;
    model: string;
    request: LlmChatRequest;
    disableTools: boolean;
  }): Promise<Response> {
    const body = this.buildChatCompletionsBody({
      model: input.model,
      request: input.request,
      disableTools: input.disableTools,
    });

    return fetch(`${input.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${input.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
  }

  private shouldRetryWithoutTools(status: number): boolean {
    // 仅对 5xx 做降级重试，4xx 视为请求侧错误不重试。
    return status >= 500;
  }

  private isUpstreamPanic(errText: string): boolean {
    // new-api 的 panic 文案存在多种大小写/措辞，统一正则识别。
    return /new_api_panic|panic detected|nil pointer|invalid memory address/i.test(errText);
  }
}
