import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
// cookie-parser 为 CommonJS 导出，ESM 默认 import 编译后会出现 default 非函数
// eslint-disable-next-line @typescript-eslint/no-require-imports -- CJS 互操作
import cookieParser = require('cookie-parser');
import { randomUUID } from 'crypto';
import { NextFunction, Request, Response } from 'express';
import { AppModule } from './app.module';
import { TraceLogger, traceStorage } from './common/logger';

/**
 * 应用程序的入口函数
 * NestJS 应用通常由一个 bootstrap (引导) 函数来启动
 */
async function bootstrap() {
  // 1. 创建 NestJS 应用实例
  // 传入根模块 AppModule，它是整个应用的起点
  // bufferLogs: true 表示在自定义日志器就绪前，先缓存应用启动时的日志，避免丢失
  const app = await NestFactory.create(AppModule, {
    bufferLogs: true,
  });
  
  // 2. 替换默认的日志器为自定义的 TraceLogger
  // 这样应用的所有日志都会经过我们自定义的逻辑（比如自动带上 traceId）
  app.useLogger(new TraceLogger());
  
  // 判断当前是否为生产环境
  const isProduction = process.env.NODE_ENV === 'production';

  // 3. 注册全局中间件：处理全链路追踪 ID (traceId)
  // 中间件会在每个请求到达具体的路由之前执行
  app.use((req: Request, _res: Response, next: NextFunction) => {
    // 尝试从请求头中获取调用方传来的 traceId
    const h = req.headers['x-trace-id'];
    const fromHeader = Array.isArray(h) ? h[0] : h;
    
    // 如果请求头没有传，则生成一个新的 UUID 作为 traceId
    const traceId = fromHeader?.trim() || randomUUID();
    
    // 将 traceId 挂载到 request 对象上，方便后续在控制器或服务中直接使用
    req.traceId = traceId;
    
    // 使用 AsyncLocalStorage (类似 Java 的 ThreadLocal) 存储 traceId
    // 这样在当前请求的整个异步执行链路中，任何地方（比如日志打印时）都能直接获取到这个 traceId，无需层层传递
    traceStorage.run({ traceId }, () => {
      // 调用 next() 将请求传递给下一个中间件或路由处理器
      next();
    });
  });
  
  // 4. 注册全局中间件：解析 Cookie
  // 使得我们可以通过 req.cookies 方便地读取客户端发来的 Cookie
  app.use(cookieParser());

  // 5. 设置全局路由前缀
  // 所有接口的 URL 都会自动加上这个前缀，例如：http://localhost:3000/aifs/trump-web/api/xxx
  app.setGlobalPrefix('/aifs/trump-web/api');

  // 6. 跨域资源共享 (CORS) 配置
  // 开发环境下允许跨域请求，方便前端本地开发调试
  if (!isProduction) {
    app.enableCors();
  }

  // 7. 注册全局管道 (Pipe)：用于请求参数的自动验证和转换
  app.useGlobalPipes(
    new ValidationPipe({
      // whitelist: true 会自动剔除客户端传来的、但在 DTO (数据传输对象) 类中未定义的字段，防止恶意注入
      whitelist: true,
      // transform: true 会自动将客户端传来的普通对象转换为我们定义的 DTO 类的实例，并尝试进行类型转换（如字符串转数字）
      transform: true,
    }),
  );

  // 8. 配置 Swagger 接口文档 (仅在非生产环境开启)
  if (!isProduction) {
    // 使用 DocumentBuilder 构建 Swagger 的基本信息（标题、描述、版本等）
    const swaggerConfig = new DocumentBuilder()
      .setTitle('trump-fullstack API')
      .setDescription('Trump Fullstack NestJS Backend API')
      .setVersion('1.0')
      .build();
      
    // 根据配置生成文档数据
    const document = SwaggerModule.createDocument(app, swaggerConfig);
    
    // 将 Swagger UI 挂载到指定的路由路径下（访问 http://localhost:3000/api/docs 即可查看接口文档）
    SwaggerModule.setup('api/docs', app, document);
  }

  // 9. 启动 HTTP 服务器
  // 优先使用环境变量中配置的端口，如果没有则默认使用 3000 端口
  const port = process.env.PORT || 3000;
  await app.listen(port);
  console.log(`Server is running on port ${port}`);
}

// 执行引导函数，启动应用
bootstrap();
