import { Module } from '@nestjs/common';
import { AgentController } from './agent.controller';
import { PlanAgent } from './built-in/plan-agent';
import { ContextCompactService } from '../context/context-compact.service';
import { QueryEngineService } from '../engine/query-engine.service';
import { AgentRuntimeService } from '../runtime/agent-runtime.service';
import { AgentSessionService } from '../state/agent-session.service';
import { ToolsModule } from '../tools/tools.module';
import { LlmClient } from '../utils/llm-client';

/**
 * Agent 领域模块
 * 负责聚合运行时、引擎、会话和工具相关的 provider，并暴露给其他模块复用。
 */
@Module({
  imports: [ToolsModule],
  controllers: [AgentController],
  providers: [
    LlmClient,
    PlanAgent,
    ContextCompactService,
    AgentSessionService,
    QueryEngineService,
    AgentRuntimeService,
  ],
  exports: [AgentRuntimeService, AgentSessionService, ToolsModule],
})
export class AgentModule {}
