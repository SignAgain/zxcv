/**
 * 方案 A：不启动 HTTP、不调用 LLM，直接集成冒烟 task / background / team 工具链。
 *
 * 运行（仓库根目录）：
 *   npx ts-node scripts/smoke-tools.ts
 *
 * 环境：可设 TASKS_DIR（本脚本默认写入临时目录）；工作区为临时目录。
 */
import 'reflect-metadata';
import { equal, fail, ok } from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { TaskModule } from '../src/tasks/task.module';
import { TaskService } from '../src/tasks/task.service';
import { BackgroundRunTool } from '../src/tools/built-in/background/background-run.tool';
import { CheckBackgroundTool } from '../src/tools/built-in/background/check-background.tool';
import { BACKGROUND_TOOL_PROVIDERS } from '../src/tools/built-in/background/background-tools.providers';
import { TEAM_TOOL_PROVIDERS } from '../src/tools/built-in/team/team-tools.providers';
import { INFRA_BACKGROUND_PROVIDERS } from '../src/tools/infra/background/infra-background.providers';
import { WorkspaceBackgroundService } from '../src/tools/infra/background/workspace-background.service';
import { PROTOCOL_PROVIDERS } from '../src/tools/protocol/protocol.providers';
import {
  ListTeammatesTool,
  SendMessageTool,
  SpawnTeammateTool,
} from '../src/tools/built-in/team/team-agent.tools';
import type { ToolContext } from '../src/types/tool';

function parseBgTaskId(data: string): string | null {
  const m = /Background task ([a-f0-9]+) started:/.exec(data);
  return m ? m[1]! : null;
}

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: [path.join(__dirname, '..', '.env')],
    }),
    TaskModule,
  ],
  providers: [
    ...INFRA_BACKGROUND_PROVIDERS,
    ...PROTOCOL_PROVIDERS,
    ...BACKGROUND_TOOL_PROVIDERS,
    ...TEAM_TOOL_PROVIDERS,
  ],
})
class SmokeToolsModule {}

async function smokeTask(taskService: TaskService): Promise<void> {
  const created = await taskService.dispatchTaskTool('task_create', {
    subject: 'smoke: integration task',
    description: 'from scripts/smoke-tools.ts',
  });
  ok(!created.startsWith('Error:'), created);
  const task = JSON.parse(created) as { id: number };
  ok(Number.isFinite(task.id));

  const listed = await taskService.dispatchTaskTool('task_list', {});
  ok(listed.includes(`#${task.id}`), listed);

  const got = await taskService.dispatchTaskTool('task_get', { task_id: task.id });
  ok(!got.startsWith('Error:'), got);
  ok(got.includes('smoke: integration task'), got);

  const claimed = await taskService.dispatchTaskTool('claim_task', {
    task_id: task.id,
    owner: 'smoke-runner',
  });
  ok(!claimed.startsWith('Error:'), claimed);
}

async function smokeBackground(
  workspaceRoot: string,
  bgSvc: WorkspaceBackgroundService,
  runTool: BackgroundRunTool,
  checkTool: CheckBackgroundTool,
): Promise<void> {
  const ctx: ToolContext = {
    workspaceRoot,
    background: bgSvc.createShellContext(workspaceRoot),
  };
  const started = await runTool.call({ command: 'echo smoke-bg-ok' }, ctx);
  equal(started.success, true, started.error ?? String(started.data));
  const taskId = parseBgTaskId(String(started.data ?? ''));
  ok(taskId, `expected task id in: ${started.data}`);

  const deadline = Date.now() + 8000;
  let last = '';
  while (Date.now() < deadline) {
    const chk = await checkTool.call({ task_id: taskId }, ctx);
    equal(chk.success, true, chk.error);
    last = String(chk.data ?? '');
    if (last.includes('completed') || last.includes('[completed]')) {
      ok(last.includes('smoke-bg-ok'), last);
      return;
    }
    await delay(40);
  }
  fail(`background task did not complete in time, last: ${last}`);
}

async function smokeTeam(
  workspaceRoot: string,
  teammate: string,
  ctx: ToolContext,
  tools: {
    spawn: SpawnTeammateTool;
    list: ListTeammatesTool;
    send: SendMessageTool;
  },
): Promise<void> {
  const sp = await tools.spawn.call(
    {
      name: teammate,
      role: 'smoke',
      prompt: 'noop',
    },
    ctx,
  );
  equal(sp.success, true, sp.error);

  const li = await tools.list.call({}, ctx);
  equal(li.success, true, li.error);
  ok(String(li.data).includes(teammate), String(li.data));

  const msg = 'smoke-team-ping';
  const se = await tools.send.call({ to: teammate, content: msg }, ctx);
  equal(se.success, true, se.error);

  const inboxPath = path.join(workspaceRoot, '.team', 'inbox', `${teammate}.jsonl`);
  const raw = await fs.readFile(inboxPath, 'utf8');
  ok(raw.includes(msg), raw);
}

async function main(): Promise<void> {
  const runId = randomBytes(4).toString('hex');
  const base = path.join(__dirname, '..', '.tmp-smoke', runId);
  const tasksDir = path.join(base, 'tasks');
  const workspaceRoot = path.join(base, 'workspace');
  process.env.TASKS_DIR = tasksDir;

  await fs.mkdir(workspaceRoot, { recursive: true });

  const app = await NestFactory.createApplicationContext(SmokeToolsModule, {
    logger: false,
  });

  try {
    const taskService = app.get(TaskService);
    const bgSvc = app.get(WorkspaceBackgroundService);
    const runTool = app.get(BackgroundRunTool);
    const checkTool = app.get(CheckBackgroundTool);
    const ctx: ToolContext = {
      workspaceRoot,
      background: bgSvc.createShellContext(workspaceRoot),
    };

    await smokeTask(taskService);
    await smokeBackground(workspaceRoot, bgSvc, runTool, checkTool);
    await smokeTeam(workspaceRoot, `smoke_${runId}`, ctx, {
      spawn: app.get(SpawnTeammateTool),
      list: app.get(ListTeammatesTool),
      send: app.get(SendMessageTool),
    });

    console.log('smoke-tools: OK (task + background + team)');
  } finally {
    await app.close();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
